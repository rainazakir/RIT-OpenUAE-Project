/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ 
/*     */ class FilePrims
/*     */   extends Primitives
/*     */ {
/*     */   String readtext;
/*     */   int textoffset;
/*  18 */   static String[] primlist = { "filetostring", "1", "resourcetostring", "1", "load", "1", "stringtofile", "2", "file?", "1", "setread", "1", "readline", "0", "eot?", "0", "lineback", "0", "filenamefrompath", "1", "dirnamefrompath", "1", "dir", "1" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  33 */   public String[] primlist() { return primlist; }
/*     */   
/*     */   public Object dispatch(int paramInt, Object[] paramArrayOfObject, LContext paramLContext) {
/*  36 */     switch (paramInt) {
/*  37 */     case 0:  return prim_filetostring(paramArrayOfObject[0], paramLContext);
/*  38 */     case 1:  return prim_resourcetostring(paramArrayOfObject[0], paramLContext);
/*  39 */     case 2:  return prim_load(paramArrayOfObject[0], paramLContext);
/*  40 */     case 3:  return prim_stringtofile(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  41 */     case 4:  return prim_filep(paramArrayOfObject[0], paramLContext);
/*  42 */     case 5:  return prim_setread(paramArrayOfObject[0], paramLContext);
/*  43 */     case 6:  return prim_readline(paramLContext);
/*  44 */     case 7:  return prim_eot(paramLContext);
/*  45 */     case 8:  return prim_lineback(paramLContext);
/*  46 */     case 9:  return prim_filenamefrompath(paramArrayOfObject[0], paramLContext);
/*  47 */     case 10:  return prim_dirnamefrompath(paramArrayOfObject[0], paramLContext);
/*  48 */     case 11:  return prim_dir(paramArrayOfObject[0], paramLContext);
/*     */     }
/*  50 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_filetostring(Object paramObject, LContext paramLContext) {
/*  54 */     String str = Logo.prs(paramObject);
/*  55 */     return fileToString(str, paramLContext);
/*     */   }
/*     */   
/*     */   Object prim_resourcetostring(Object paramObject, LContext paramLContext) {
/*  59 */     String str = Logo.prs(paramObject);
/*  60 */     return resourceToString(str, paramLContext);
/*     */   }
/*     */   
/*     */   Object prim_load(Object paramObject, LContext paramLContext) {
/*  64 */     String str1 = Logo.prs(paramObject);
/*  65 */     String str2 = System.getProperty("file.separator");
/*  66 */     String str3 = resourceToString(str1 + ".logo", paramLContext);
/*     */     
/*     */ 
/*  69 */     Logo.readAllFunctions(str3, paramLContext);
/*  70 */     return null;
/*     */   }
/*     */   
/*     */   String resourceToString(String paramString, LContext paramLContext) {
/*  74 */     InputStream localInputStream = FilePrims.class.getResourceAsStream(paramString);
/*  75 */     BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localInputStream));
/*  76 */     StringWriter localStringWriter = new StringWriter();
/*  77 */     PrintWriter localPrintWriter = new PrintWriter(new BufferedWriter(localStringWriter), true);
/*     */     try {
/*     */       String str1;
/*  80 */       while ((str1 = localBufferedReader.readLine()) != null) localPrintWriter.println(str1);
/*  81 */       return localStringWriter.toString();
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/*  85 */       Logo.error("Can't open file " + paramString, paramLContext); }
/*  86 */     return null;
/*     */   }
/*     */   
/*     */   String fileToString(String paramString, LContext paramLContext) {
/*  90 */     byte[] arrayOfByte = null;Object localObject = null;
/*     */     try {
/*  92 */       File localFile = new File(paramString);
/*  93 */       int i = (int)localFile.length();
/*  94 */       FileInputStream localFileInputStream = new FileInputStream(localFile);
/*  95 */       DataInputStream localDataInputStream = new DataInputStream(localFileInputStream);
/*  96 */       arrayOfByte = new byte[i];
/*  97 */       localDataInputStream.readFully(arrayOfByte);
/*  98 */       localFileInputStream.close();
/*     */     }
/*     */     catch (IOException localIOException) {
/* 101 */       Logo.error("Can't open file " + paramString, paramLContext); }
/* 102 */     return new String(arrayOfByte);
/*     */   }
/*     */   
/*     */   Object prim_stringtofile(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 106 */     String str1 = Logo.prs(paramObject1);
/* 107 */     String str2 = Logo.prs(paramObject2);
/*     */     try {
/* 109 */       FileWriter localFileWriter = new FileWriter(str1);
/* 110 */       localFileWriter.write(str2, 0, str2.length());
/* 111 */       localFileWriter.close();
/*     */     }
/*     */     catch (IOException localIOException) {
/* 114 */       Logo.error("Can't write file " + str1, paramLContext); }
/* 115 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_filep(Object paramObject, LContext paramLContext) {
/* 119 */     String str = Logo.prs(paramObject);
/* 120 */     return new Boolean(new File(str).exists());
/*     */   }
/*     */   
/*     */   Object prim_setread(Object paramObject, LContext paramLContext) {
/* 124 */     this.readtext = Logo.prs(paramObject);
/* 125 */     this.textoffset = 0;
/* 126 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_readline(LContext paramLContext) {
/* 130 */     String str = "";
/* 131 */     int i = this.readtext.indexOf("\n", this.textoffset);
/* 132 */     if (i == -1) {
/* 133 */       if (this.textoffset < this.readtext.length()) {
/* 134 */         str = this.readtext.substring(this.textoffset, this.readtext.length());
/* 135 */         this.textoffset = this.readtext.length();
/*     */       }
/* 137 */     } else { str = this.readtext.substring(this.textoffset, i);
/* 138 */       this.textoffset = (i + 1); }
/* 139 */     if (str.length() == 0) return str;
/* 140 */     if (str.charAt(str.length() - 1) == '\r') str = str.substring(0, str.length() - 1);
/* 141 */     return str;
/*     */   }
/*     */   
/*     */   Object prim_eot(LContext paramLContext) {
/* 145 */     return new Boolean(this.textoffset >= this.readtext.length());
/*     */   }
/*     */   
/*     */   Object prim_lineback(LContext paramLContext) {
/* 149 */     int i = this.readtext.lastIndexOf("\n", this.textoffset - 2);
/* 150 */     if (i < 0) this.textoffset = 0; else
/* 151 */       this.textoffset = (i + 1);
/* 152 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_filenamefrompath(Object paramObject, LContext paramLContext) {
/* 156 */     return new File(Logo.prs(paramObject)).getName();
/*     */   }
/*     */   
/*     */   Object prim_dirnamefrompath(Object paramObject, LContext paramLContext) {
/* 160 */     File localFile = new File(Logo.prs(paramObject));
/* 161 */     if (localFile.isDirectory()) return localFile.getPath();
/* 162 */     return localFile.getParent();
/*     */   }
/*     */   
/*     */   Object prim_dir(Object paramObject, LContext paramLContext) {
/* 166 */     String[] arrayOfString = new File(Logo.prs(paramObject)).list();
/* 167 */     if (arrayOfString == null) return new Object[0];
/* 168 */     return arrayOfString;
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\FilePrims.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */