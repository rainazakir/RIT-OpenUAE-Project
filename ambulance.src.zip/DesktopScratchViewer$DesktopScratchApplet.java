/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DesktopScratchViewer$DesktopScratchApplet
/*     */   extends ScratchApplet
/*     */ {
/*     */   private String[] param;
/*     */   
/*     */   public DesktopScratchViewer$DesktopScratchApplet(String[] params)
/*     */   {
/* 135 */     this.param = params;
/*     */   }
/*     */   
/*     */   public String getParameter(String name)
/*     */   {
/* 140 */     for (int i = 0; i < this.param.length; i += 2) {
/* 141 */       if (this.param[i].equals(name)) {
/* 142 */         return this.param[(i + 1)];
/*     */       }
/*     */     }
/* 145 */     return null;
/*     */   }
/*     */   
/*     */   public URL getCodeBase()
/*     */   {
/*     */     try {
/* 151 */       return new URL(DesktopScratchViewer.class.getResource("project.dat").toExternalForm().replace("project.dat", ""));
/*     */     } catch (MalformedURLException ex) {
/* 153 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\DesktopScratchViewer$DesktopScratchApplet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */