/*    */ import java.net.URL;
/*    */ import javax.swing.JApplet;
/*    */ 
/*    */ public class ScratchApplet extends JApplet
/*    */ {
/*    */   LContext lc;
/*    */   
/*    */   public static void setSensorValue(int paramInt1, int paramInt2)
/*    */   {
/* 10 */     if ((paramInt1 < 0) || (paramInt1 > 15)) return;
/* 11 */     PlayerPrims.sensorValues[paramInt1] = paramInt2;
/*    */   }
/*    */   
/*    */   public static int getSensorValue(int paramInt) {
/* 15 */     if ((paramInt < 0) || (paramInt > 15)) return 0;
/* 16 */     return PlayerPrims.sensorValues[paramInt];
/*    */   }
/*    */   
/*    */   public void init() {
/* 20 */     String str1 = getCodeBase().toString();
/* 21 */     String str2 = getParameter("project");
/* 22 */     String str3 = str2 != null ? (str3 = str1 + str2) : null;
/* 23 */     String str4 = getParameter("autostart");
/*    */     
/* 25 */     boolean bool = true;
/* 26 */     if (str4 != null) {
/* 27 */       if (str4.equalsIgnoreCase("false")) bool = false;
/* 28 */       if (str4.equalsIgnoreCase("no")) bool = false;
/*    */     }
/*    */     try
/*    */     {
/* 32 */       Thread.sleep(50L); } catch (InterruptedException localInterruptedException) {}
/* 33 */     this.lc = PlayerPrims.startup(str1, str3, getContentPane(), bool);
/* 34 */     this.lc.tyo = System.out;
/*    */   }
/*    */   
/* 37 */   public void destroy() { PlayerPrims.shutdown(this.lc); }
/*    */ }


/* Location:              T:\p1\ambulance.jar!\ScratchApplet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */