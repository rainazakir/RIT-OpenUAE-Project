/*     */ class MathPrims extends Primitives
/*     */ {
/*   3 */   static String[] primlist = { "sum", "i2", "remainder", "2", "difference", "2", "diff", "2", "product", "i2", "quotient", "2", "greater?", "2", "less?", "2", "int", "1", "minus", "1", "round", "1", "sqrt", "1", "sin", "1", "cos", "1", "tan", "1", "abs", "1", "power", "2", "arctan", "1", "pi", "0", "exp", "1", "arctan2", "2", "ln", "1", "logand", "2", "logior", "2", "logxor", "2", "lsh", "2", "and", "i2", "or", "i2", "not", "1", "random", "1", "min", "i2", "max", "i2", "number?", "1", "+", "-2", "-", "-2", "*", "-3", "/", "-3", "<", "-1", ">", "-1", "=", "-1", "equal?", "i2", "%", "-3", "rand", "0", "strequ", "2", "arcsin", "1", "arccos", "1", "strcmp", "2" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final double degtor = 57.29577951308232D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] primlist()
/*     */   {
/*  53 */     return primlist;
/*     */   }
/*     */   
/*     */   public Object dispatch(int paramInt, Object[] paramArrayOfObject, LContext paramLContext) {
/*  57 */     switch (paramInt) {
/*  58 */     case 0:  return prim_sum(paramArrayOfObject, paramLContext);
/*  59 */     case 1:  return prim_remainder(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  60 */     case 2: case 3:  return prim_diff(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  61 */     case 4:  return prim_product(paramArrayOfObject, paramLContext);
/*  62 */     case 5:  return prim_quotient(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  63 */     case 6:  return prim_greaterp(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  64 */     case 7:  return prim_lessp(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  65 */     case 8:  return prim_int(paramArrayOfObject[0], paramLContext);
/*  66 */     case 9:  return prim_minus(paramArrayOfObject[0], paramLContext);
/*  67 */     case 10:  return prim_round(paramArrayOfObject[0], paramLContext);
/*  68 */     case 11:  return prim_sqrt(paramArrayOfObject[0], paramLContext);
/*  69 */     case 12:  return prim_sin(paramArrayOfObject[0], paramLContext);
/*  70 */     case 13:  return prim_cos(paramArrayOfObject[0], paramLContext);
/*  71 */     case 14:  return prim_tan(paramArrayOfObject[0], paramLContext);
/*  72 */     case 15:  return prim_abs(paramArrayOfObject[0], paramLContext);
/*  73 */     case 16:  return prim_power(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  74 */     case 17:  return prim_arctan(paramArrayOfObject[0], paramLContext);
/*  75 */     case 18:  return prim_pi(paramLContext);
/*  76 */     case 19:  return prim_exp(paramArrayOfObject[0], paramLContext);
/*  77 */     case 20:  return prim_arctan2(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  78 */     case 21:  return prim_ln(paramArrayOfObject[0], paramLContext);
/*  79 */     case 22:  return prim_logand(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  80 */     case 23:  return prim_logior(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  81 */     case 24:  return prim_logxor(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  82 */     case 25:  return prim_lsh(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  83 */     case 26:  return prim_and(paramArrayOfObject, paramLContext);
/*  84 */     case 27:  return prim_or(paramArrayOfObject, paramLContext);
/*  85 */     case 28:  return prim_not(paramArrayOfObject[0], paramLContext);
/*  86 */     case 29:  return prim_random(paramArrayOfObject[0], paramLContext);
/*  87 */     case 30:  return prim_min(paramArrayOfObject, paramLContext);
/*  88 */     case 31:  return prim_max(paramArrayOfObject, paramLContext);
/*  89 */     case 32:  return prim_numberp(paramArrayOfObject[0], paramLContext);
/*  90 */     case 33:  return prim_sum(paramArrayOfObject, paramLContext);
/*  91 */     case 34:  return prim_diff(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  92 */     case 35:  return prim_product(paramArrayOfObject, paramLContext);
/*  93 */     case 36:  return prim_quotient(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  94 */     case 37:  return prim_lessp(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  95 */     case 38:  return prim_greaterp(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  96 */     case 39:  return prim_equalp(paramArrayOfObject, paramLContext);
/*  97 */     case 40:  return prim_equalp(paramArrayOfObject, paramLContext);
/*  98 */     case 41:  return prim_remainder(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  99 */     case 42:  return new Double(Math.random());
/* 100 */     case 43:  return prim_strequ(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/* 101 */     case 44:  return prim_arcsin(paramArrayOfObject[0], paramLContext);
/* 102 */     case 45:  return prim_arccos(paramArrayOfObject[0], paramLContext);
/* 103 */     case 46:  return prim_strcmp(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_sum(Object[] paramArrayOfObject, LContext paramLContext) {
/* 109 */     double d = 0.0D;
/* 110 */     for (int i = 0; i < paramArrayOfObject.length; i++) d += Logo.aDouble(paramArrayOfObject[i], paramLContext);
/* 111 */     return new Double(d);
/*     */   }
/*     */   
/*     */   Object prim_remainder(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 115 */     return new Double(Logo.aDouble(paramObject1, paramLContext) % Logo.aDouble(paramObject2, paramLContext));
/*     */   }
/*     */   
/*     */   Object prim_diff(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 119 */     return new Double(Logo.aDouble(paramObject1, paramLContext) - Logo.aDouble(paramObject2, paramLContext));
/*     */   }
/*     */   
/*     */   Object prim_product(Object[] paramArrayOfObject, LContext paramLContext) {
/* 123 */     double d = 1.0D;
/* 124 */     for (int i = 0; i < paramArrayOfObject.length; i++) d *= Logo.aDouble(paramArrayOfObject[i], paramLContext);
/* 125 */     return new Double(d);
/*     */   }
/*     */   
/*     */   Object prim_quotient(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 129 */     return new Double(Logo.aDouble(paramObject1, paramLContext) / Logo.aDouble(paramObject2, paramLContext));
/*     */   }
/*     */   
/* 132 */   Object prim_greaterp(Object paramObject1, Object paramObject2, LContext paramLContext) { return new Boolean(Logo.aDouble(paramObject1, paramLContext) > Logo.aDouble(paramObject2, paramLContext)); }
/*     */   
/*     */   Object prim_lessp(Object paramObject1, Object paramObject2, LContext paramLContext)
/*     */   {
/* 136 */     return new Boolean(Logo.aDouble(paramObject1, paramLContext) < Logo.aDouble(paramObject2, paramLContext));
/*     */   }
/*     */   
/*     */   Object prim_int(Object paramObject, LContext paramLContext) {
/* 140 */     return new Double(new Double(Logo.aDouble(paramObject, paramLContext)).intValue());
/*     */   }
/*     */   
/*     */   Object prim_minus(Object paramObject, LContext paramLContext) {
/* 144 */     return new Double(0.0D - Logo.aDouble(paramObject, paramLContext));
/*     */   }
/*     */   
/*     */   Object prim_round(Object paramObject, LContext paramLContext) {
/* 148 */     return new Double(Math.round(Logo.aDouble(paramObject, paramLContext)));
/*     */   }
/*     */   
/*     */   Object prim_sqrt(Object paramObject, LContext paramLContext) {
/* 152 */     return new Double(Math.sqrt(Logo.aDouble(paramObject, paramLContext)));
/*     */   }
/*     */   
/*     */   Object prim_sin(Object paramObject, LContext paramLContext) {
/* 156 */     return new Double(Math.sin(Logo.aDouble(paramObject, paramLContext) / 57.29577951308232D));
/*     */   }
/*     */   
/*     */   Object prim_cos(Object paramObject, LContext paramLContext) {
/* 160 */     return new Double(Math.cos(Logo.aDouble(paramObject, paramLContext) / 57.29577951308232D));
/*     */   }
/*     */   
/*     */   Object prim_tan(Object paramObject, LContext paramLContext) {
/* 164 */     return new Double(Math.tan(Logo.aDouble(paramObject, paramLContext) / 57.29577951308232D));
/*     */   }
/*     */   
/*     */   Object prim_abs(Object paramObject, LContext paramLContext) {
/* 168 */     return new Double(Math.abs(Logo.aDouble(paramObject, paramLContext)));
/*     */   }
/*     */   
/*     */   Object prim_power(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 172 */     return new Double(Math.pow(Logo.aDouble(paramObject1, paramLContext), Logo.aDouble(paramObject2, paramLContext)));
/*     */   }
/*     */   
/*     */   Object prim_arcsin(Object paramObject, LContext paramLContext) {
/* 176 */     return new Double(57.29577951308232D * Math.asin(Logo.aDouble(paramObject, paramLContext)));
/*     */   }
/*     */   
/*     */   Object prim_arccos(Object paramObject, LContext paramLContext) {
/* 180 */     return new Double(57.29577951308232D * Math.acos(Logo.aDouble(paramObject, paramLContext)));
/*     */   }
/*     */   
/*     */   Object prim_arctan(Object paramObject, LContext paramLContext) {
/* 184 */     return new Double(57.29577951308232D * Math.atan(Logo.aDouble(paramObject, paramLContext)));
/*     */   }
/*     */   
/*     */   Object prim_pi(LContext paramLContext) {
/* 188 */     return new Double(3.141592653589793D);
/*     */   }
/*     */   
/*     */   Object prim_exp(Object paramObject, LContext paramLContext) {
/* 192 */     return new Double(Math.exp(Logo.aDouble(paramObject, paramLContext)));
/*     */   }
/*     */   
/*     */   Object prim_arctan2(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 196 */     return new Double(57.29577951308232D * Math.atan2(Logo.aDouble(paramObject1, paramLContext), Logo.aDouble(paramObject2, paramLContext)));
/*     */   }
/*     */   
/*     */   Object prim_ln(Object paramObject, LContext paramLContext) {
/* 200 */     return new Double(Math.log(Logo.aDouble(paramObject, paramLContext)));
/*     */   }
/*     */   
/*     */   Object prim_logand(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 204 */     return new Double(Logo.anInt(paramObject1, paramLContext) & Logo.anInt(paramObject2, paramLContext));
/*     */   }
/*     */   
/*     */   Object prim_logior(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 208 */     return new Double(Logo.anInt(paramObject1, paramLContext) | Logo.anInt(paramObject2, paramLContext));
/*     */   }
/*     */   
/*     */   Object prim_logxor(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 212 */     return new Double(Logo.anInt(paramObject1, paramLContext) ^ Logo.anInt(paramObject2, paramLContext));
/*     */   }
/*     */   
/*     */   Object prim_lsh(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 216 */     int i = Logo.anInt(paramObject2, paramLContext);int j = Logo.anInt(paramObject1, paramLContext);
/* 217 */     return i > 0 ? new Double(j << i) : new Double(j >> -i);
/*     */   }
/*     */   
/*     */   Object prim_and(Object[] paramArrayOfObject, LContext paramLContext) {
/* 221 */     boolean bool = true;
/* 222 */     for (int i = 0; i < paramArrayOfObject.length; i++) bool &= Logo.aBoolean(paramArrayOfObject[i], paramLContext);
/* 223 */     return new Boolean(bool);
/*     */   }
/*     */   
/*     */   Object prim_or(Object[] paramArrayOfObject, LContext paramLContext) {
/* 227 */     boolean bool = false;
/* 228 */     for (int i = 0; i < paramArrayOfObject.length; i++) bool |= Logo.aBoolean(paramArrayOfObject[i], paramLContext);
/* 229 */     return new Boolean(bool);
/*     */   }
/*     */   
/*     */   Object prim_not(Object paramObject, LContext paramLContext) {
/* 233 */     return new Boolean(!Logo.aBoolean(paramObject, paramLContext));
/*     */   }
/*     */   
/*     */   Object prim_random(Object paramObject, LContext paramLContext) {
/* 237 */     return new Double(Math.floor(Math.random() * Logo.anInt(paramObject, paramLContext)));
/*     */   }
/*     */   
/*     */   Object prim_min(Object[] paramArrayOfObject, LContext paramLContext) {
/* 241 */     if (paramArrayOfObject.length == 0) Logo.error("Min needs at least one input", paramLContext);
/* 242 */     double d = Logo.aDouble(paramArrayOfObject[0], paramLContext);
/* 243 */     for (int i = 1; i < paramArrayOfObject.length; i++) d = Math.min(d, Logo.aDouble(paramArrayOfObject[i], paramLContext));
/* 244 */     return new Double(d);
/*     */   }
/*     */   
/*     */   Object prim_max(Object[] paramArrayOfObject, LContext paramLContext) {
/* 248 */     if (paramArrayOfObject.length == 0) Logo.error("Max needs at least one input", paramLContext);
/* 249 */     double d = Logo.aDouble(paramArrayOfObject[0], paramLContext);
/* 250 */     for (int i = 1; i < paramArrayOfObject.length; i++) d = Math.max(d, Logo.aDouble(paramArrayOfObject[i], paramLContext));
/* 251 */     return new Double(d);
/*     */   }
/*     */   
/*     */   Object prim_numberp(Object paramObject, LContext paramLContext) {
/* 255 */     return new Boolean(paramObject instanceof Number);
/*     */   }
/*     */   
/*     */ 
/*     */   Object prim_equalp(Object[] paramArrayOfObject, LContext paramLContext)
/*     */   {
/* 261 */     if (paramArrayOfObject.length == 0) Logo.error("Equal needs at least one input", paramLContext);
/* 262 */     Object localObject = paramArrayOfObject[0];
/* 263 */     for (int i = 1; i < paramArrayOfObject.length; i++) {
/* 264 */       if ((localObject != paramArrayOfObject[i]) && 
/* 265 */         (!Logo.prs(localObject).equals(Logo.prs(paramArrayOfObject[i])))) return new Boolean(false);
/*     */     }
/* 267 */     return new Boolean(true);
/*     */   }
/*     */   
/*     */   Object prim_strequ(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 271 */     String str1 = convertToString(paramObject1);
/* 272 */     String str2 = convertToString(paramObject2);
/* 273 */     if ((str1 == null) || (str2 == null)) return new Boolean(false);
/* 274 */     return new Boolean(str1.equalsIgnoreCase(str2));
/*     */   }
/*     */   
/*     */   Object prim_strcmp(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 278 */     String str1 = convertToString(paramObject1);
/* 279 */     String str2 = convertToString(paramObject2);
/* 280 */     if ((str1 == null) || (str2 == null)) return new Boolean(false);
/* 281 */     return new Double(str1.compareToIgnoreCase(str2));
/*     */   }
/*     */   
/*     */   String convertToString(Object paramObject) {
/* 285 */     if ((paramObject instanceof String)) return (String)paramObject;
/* 286 */     if ((paramObject instanceof Symbol)) return ((Symbol)paramObject).pname;
/* 287 */     if ((paramObject instanceof QuotedSymbol)) return ((QuotedSymbol)paramObject).sym.pname;
/* 288 */     return null;
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\MathPrims.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */