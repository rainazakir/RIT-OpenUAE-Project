/*     */ import java.awt.Color;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpritePrims
/*     */   extends Primitives
/*     */ {
/*  32 */   static final String[] primlist = { "who", "0", "talkto", "1", "xpos", "0", "ypos", "0", "setx", "1", "sety", "1", "%left", "0", "%top", "0", "%right", "0", "%bottom", "0", "%setleft", "1", "%settop", "1", "%w", "0", "%h", "0", "costume", "0", "setcostume", "3", "%scale", "0", "setscale", "1", "heading", "0", "setheading", "1", "rotationstyle", "0", "setrotationstyle", "1", "show", "0", "hide", "0", "changed", "0", "containsPoint?", "2", "alpha", "0", "setalpha", "1", "color", "0", "setcolor", "1", "brightness", "0", "setbrightness", "1", "fisheye", "0", "setfisheye", "1", "whirl", "0", "setwhirl", "1", "mosaic", "0", "setmosaic", "1", "pixelate", "0", "setpixelate", "1", "beep", "0", "startSound", "1", "isSoundPlaying?", "1", "stopSound", "1", "stopAllSounds", "0", "setPenDown", "1", "setPenColor", "1", "penSize", "0", "setPenSize", "1", "penHue", "0", "setPenHue", "1", "penShade", "0", "setPenShade", "1", "clearPenTrails", "0", "stampCostume", "0", "newcolor", "3", "touchingSprite?", "1", "touchingColor?", "1", "colorTouchingColor?", "2", "isShowing", "1", "talkbubble", "1", "thinkbubble", "1", "updateBubble", "0", "watcher?", "1", "setWatcherXY", "3", "setWatcherColorAndLabel", "3", "setWatcherSliderMinMax", "3", "setWatcherMode", "2", "setWatcherText", "2", "isDraggable", "0", "setDraggable", "1", "showWatcher", "1", "hideWatcher", "1", "listContents", "1", "hasKey", "2", "listWatcher?", "1", "newListWatcher", "0", "setListWatcherXY", "3", "setListWatcherWidthHeight", "3", "setListWatcherLabel", "2", "setListWatcherList", "2", "highlightListWatcherIndex", "2", "clearListWatcherHighlights", "1", "askbubble", "1", "showAskPrompt", "1", "hideAskPrompt", "0", "askPromptShowing?", "0", "lastAnswer", "0", "isVisible", "1", "newVarWatcher", "1", "watcherX", "1", "watcherY", "1" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */   public String[] primlist() { return primlist; }
/*     */   
/*     */   public Object dispatch(int paramInt, Object[] paramArrayOfObject, LContext paramLContext) {
/* 130 */     Sprite localSprite = paramLContext.who;
/*     */     
/* 132 */     switch (paramInt) {
/* 133 */     case 0:  return localSprite == null ? new Object[0] : localSprite;
/* 134 */     case 1:  paramLContext.who = ((paramArrayOfObject[0] instanceof Sprite) ? (Sprite)paramArrayOfObject[0] : null);return null;
/* 135 */     case 2:  return new Double(localSprite == null ? 0.0D : localSprite.x);
/* 136 */     case 3:  return new Double(localSprite == null ? 0.0D : localSprite.y);
/* 137 */     case 4:  localSprite.x = Logo.aDouble(paramArrayOfObject[0], paramLContext);return null;
/* 138 */     case 5:  localSprite.y = Logo.aDouble(paramArrayOfObject[0], paramLContext);return null;
/* 139 */     case 6:  return new Double(localSprite.screenX());
/* 140 */     case 7:  return new Double(localSprite.screenY());
/* 141 */     case 8:  return new Double(localSprite.screenX() + localSprite.outImage().getWidth(null));
/* 142 */     case 9:  return new Double(localSprite.screenY() + localSprite.outImage().getHeight(null));
/* 143 */     case 10:  localSprite.setscreenX(Logo.aDouble(paramArrayOfObject[0], paramLContext));return null;
/* 144 */     case 11:  localSprite.setscreenY(Logo.aDouble(paramArrayOfObject[0], paramLContext));return null;
/* 145 */     case 12:  return new Double(localSprite.outImage().getWidth(null));
/* 146 */     case 13:  return new Double(localSprite.outImage().getHeight(null));
/* 147 */     case 14:  return localSprite.costume;
/* 148 */     case 15:  localSprite.setcostume(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);localSprite.costumeChanged();return null;
/* 149 */     case 16:  return new Double(localSprite.scale);
/* 150 */     case 17:  localSprite.setscale(paramArrayOfObject[0], paramLContext);return null;
/* 151 */     case 18:  return prim_heading(paramLContext);
/* 152 */     case 19:  localSprite.rotationDegrees = (Logo.aDouble(paramArrayOfObject[0], paramLContext) % 360.0D);localSprite.costumeChanged();return null;
/* 153 */     case 20:  return new Double(localSprite.rotationstyle);
/* 154 */     case 21:  localSprite.rotationstyle = Logo.anInt(paramArrayOfObject[0], paramLContext);localSprite.costumeChanged();return null;
/* 155 */     case 22:  localSprite.show();return null;
/* 156 */     case 23:  localSprite.hide();return null;
/* 157 */     case 24:  localSprite.inval();return null;
/* 158 */     case 25:  return prim_containsPoint(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/* 159 */     case 26:  return new Double(localSprite.alpha);
/* 160 */     case 27:  localSprite.setalpha(paramArrayOfObject[0], paramLContext);return null;
/* 161 */     case 28:  return new Double(localSprite.color);
/* 162 */     case 29:  localSprite.color = Logo.aDouble(paramArrayOfObject[0], paramLContext);localSprite.filterChanged = true;return null;
/* 163 */     case 30:  return new Double(localSprite.brightness);
/* 164 */     case 31:  localSprite.brightness = Logo.aDouble(paramArrayOfObject[0], paramLContext);localSprite.filterChanged = true;return null;
/* 165 */     case 32:  return new Double(localSprite.fisheye);
/* 166 */     case 33:  localSprite.fisheye = Logo.aDouble(paramArrayOfObject[0], paramLContext);localSprite.filterChanged = true;return null;
/* 167 */     case 34:  return new Double(localSprite.whirl);
/* 168 */     case 35:  localSprite.whirl = Logo.aDouble(paramArrayOfObject[0], paramLContext);localSprite.filterChanged = true;return null;
/* 169 */     case 36:  return new Double(localSprite.mosaic);
/* 170 */     case 37:  localSprite.mosaic = Logo.aDouble(paramArrayOfObject[0], paramLContext);localSprite.filterChanged = true;return null;
/* 171 */     case 38:  return new Double(localSprite.pixelate);
/* 172 */     case 39:  localSprite.pixelate = Logo.aDouble(paramArrayOfObject[0], paramLContext);localSprite.filterChanged = true;return null;
/* 173 */     case 40:  Toolkit.getDefaultToolkit().beep();return null;
/* 174 */     case 41:  return SoundPlayer.startSound(paramArrayOfObject[0], localSprite, paramLContext);
/* 175 */     case 42:  return new Boolean(SoundPlayer.isSoundPlaying(paramArrayOfObject[0]));
/* 176 */     case 43:  SoundPlayer.stopSound(paramArrayOfObject[0]);return null;
/* 177 */     case 44:  SoundPlayer.stopSoundsForApplet(paramLContext);return null;
/* 178 */     case 45:  localSprite.setPenDown(Logo.aBoolean(paramArrayOfObject[0], paramLContext));return null;
/* 179 */     case 46:  if ((paramArrayOfObject[0] instanceof Color)) localSprite.setPenColor((Color)paramArrayOfObject[0]); return null;
/* 180 */     case 47:  return new Double(localSprite.penSize);
/* 181 */     case 48:  localSprite.penSize = Logo.anInt(paramArrayOfObject[0], paramLContext);return null;
/* 182 */     case 49:  return new Double(localSprite.penHue);
/* 183 */     case 50:  localSprite.setPenHue(Logo.aDouble(paramArrayOfObject[0], paramLContext));return null;
/* 184 */     case 51:  return new Double(localSprite.penShade);
/* 185 */     case 52:  localSprite.setPenShade(Logo.aDouble(paramArrayOfObject[0], paramLContext));return null;
/* 186 */     case 53:  paramLContext.canvas.clearPenTrails();return null;
/* 187 */     case 54:  paramLContext.canvas.stampCostume(localSprite);return null;
/* 188 */     case 55:  return prim_newcolor(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);
/* 189 */     case 56:  return new Boolean(localSprite.touchingSprite(paramArrayOfObject[0], paramLContext));
/* 190 */     case 57:  return new Boolean(localSprite.touchingColor(paramArrayOfObject[0], paramLContext));
/* 191 */     case 58:  return new Boolean(localSprite.colorTouchingColor(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext));
/* 192 */     case 59:  return new Boolean(((paramArrayOfObject[0] instanceof Sprite)) && (((Sprite)paramArrayOfObject[0]).isShowing()));
/* 193 */     case 60:  localSprite.talkbubble(paramArrayOfObject[0], false, true, paramLContext);return null;
/* 194 */     case 61:  localSprite.talkbubble(paramArrayOfObject[0], false, false, paramLContext);return null;
/* 195 */     case 62:  localSprite.updateBubble();return null;
/* 196 */     case 63:  return new Boolean(paramArrayOfObject[0] instanceof Watcher);
/* 197 */     case 64:  prim_setWatcherXY(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);return null;
/* 198 */     case 65:  prim_setWatcherColorAndLabel(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);return null;
/* 199 */     case 66:  prim_setWatcherSliderMinMax(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);return null;
/* 200 */     case 67:  prim_setWatcherMode(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);return null;
/* 201 */     case 68:  prim_setWatcherText(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);return null;
/* 202 */     case 69:  return new Boolean(localSprite.isDraggable);
/* 203 */     case 70:  localSprite.isDraggable = Logo.aBoolean(paramArrayOfObject[0], paramLContext);return null;
/* 204 */     case 71:  ((Watcher)paramArrayOfObject[0]).show();return null;
/* 205 */     case 72:  ((Watcher)paramArrayOfObject[0]).hide();return null;
/* 206 */     case 73:  return prim_listContents(paramArrayOfObject[0], paramLContext);
/* 207 */     case 74:  return prim_hasKey(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/* 208 */     case 75:  return new Boolean(paramArrayOfObject[0] instanceof ListWatcher);
/* 209 */     case 76:  return prim_newListWatcher(paramLContext);
/* 210 */     case 77:  prim_setListWatcherXY(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);return null;
/* 211 */     case 78:  prim_setListWatcherWidthHeight(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);return null;
/* 212 */     case 79:  prim_setListWatcherLabel(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);return null;
/* 213 */     case 80:  prim_setListWatcherList(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);return null;
/* 214 */     case 81:  prim_highlightListWatcherIndex(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);return null;
/* 215 */     case 82:  prim_clearListWatcherHighlights(paramArrayOfObject[0], paramLContext);return null;
/* 216 */     case 83:  localSprite.talkbubble(paramArrayOfObject[0], true, true, paramLContext);return null;
/* 217 */     case 84:  paramLContext.canvas.showAskPrompt(Logo.aString(paramArrayOfObject[0], paramLContext));return null;
/* 218 */     case 85:  paramLContext.canvas.hideAskPrompt();return null;
/* 219 */     case 86:  return new Boolean(paramLContext.canvas.askPromptShowing());
/* 220 */     case 87:  return paramLContext.canvas.lastAnswer;
/* 221 */     case 88:  return new Boolean(((paramArrayOfObject[0] instanceof Sprite)) && (((Sprite)paramArrayOfObject[0]).isVisible()));
/* 222 */     case 89:  return prim_newVarWatcher(paramArrayOfObject[0], paramLContext);
/* 223 */     case 90:  return prim_watcherX(paramArrayOfObject[0], paramLContext);
/* 224 */     case 91:  return prim_watcherY(paramArrayOfObject[0], paramLContext);
/*     */     }
/* 226 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_heading(LContext paramLContext) {
/* 230 */     double d = paramLContext.who.rotationDegrees % 360.0D;
/* 231 */     if (d > 180.0D) d -= 360.0D;
/* 232 */     return new Double(d);
/*     */   }
/*     */   
/*     */   Object prim_containsPoint(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 236 */     if (paramLContext.who == null) return new Boolean(false);
/* 237 */     int i = Logo.anInt(paramObject1, paramLContext) + 241;
/* 238 */     int j = 206 - Logo.anInt(paramObject2, paramLContext);
/* 239 */     return new Boolean(paramLContext.who.containsPoint(i, j));
/*     */   }
/*     */   
/*     */   Color prim_newcolor(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 243 */     int i = Logo.anInt(paramObject1, paramLContext);
/* 244 */     int j = Logo.anInt(paramObject2, paramLContext);
/* 245 */     int k = Logo.anInt(paramObject3, paramLContext);
/* 246 */     return new Color(i, j, k);
/*     */   }
/*     */   
/*     */   void prim_setWatcherXY(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 250 */     if (!(paramObject1 instanceof Watcher)) return;
/* 251 */     Watcher localWatcher = (Watcher)paramObject1;
/* 252 */     localWatcher.inval();
/* 253 */     localWatcher.box.x = Logo.anInt(paramObject2, paramLContext);
/* 254 */     localWatcher.box.y = Logo.anInt(paramObject3, paramLContext);
/* 255 */     localWatcher.inval();
/*     */   }
/*     */   
/*     */   void prim_setWatcherColorAndLabel(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 259 */     if (!(paramObject1 instanceof Watcher)) return;
/* 260 */     Watcher localWatcher = (Watcher)paramObject1;
/* 261 */     localWatcher.inval();
/* 262 */     localWatcher.readout.color = ((Color)paramObject2);
/* 263 */     localWatcher.label = ((String)paramObject3);
/* 264 */     localWatcher.inval();
/*     */   }
/*     */   
/*     */   void prim_setWatcherSliderMinMax(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 268 */     if (!(paramObject1 instanceof Watcher)) return;
/* 269 */     Watcher localWatcher = (Watcher)paramObject1;
/* 270 */     localWatcher.sliderMin = Logo.aDouble(paramObject2, paramLContext);
/* 271 */     localWatcher.sliderMax = Logo.aDouble(paramObject3, paramLContext);
/* 272 */     localWatcher.isDiscrete = ((Math.round(localWatcher.sliderMin) == localWatcher.sliderMin) && (Math.round(localWatcher.sliderMax) == localWatcher.sliderMax));
/*     */   }
/*     */   
/*     */ 
/*     */   void prim_setWatcherMode(Object paramObject1, Object paramObject2, LContext paramLContext)
/*     */   {
/* 278 */     if (!(paramObject1 instanceof Watcher)) return;
/* 279 */     Watcher localWatcher = (Watcher)paramObject1;
/* 280 */     int i = Logo.anInt(paramObject2, paramLContext);
/* 281 */     localWatcher.inval();
/* 282 */     localWatcher.mode = Math.max(0, Math.min(i, 3));
/* 283 */     localWatcher.inval();
/*     */   }
/*     */   
/*     */   void prim_setWatcherText(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 287 */     if (!(paramObject1 instanceof Watcher)) return;
/* 288 */     Watcher localWatcher = (Watcher)paramObject1;
/* 289 */     String str = Logo.prs(paramObject2);
/* 290 */     if ((paramObject2 instanceof Double)) {
/* 291 */       double d1 = ((Double)paramObject2).doubleValue();
/* 292 */       double d2 = Math.abs(d1);
/* 293 */       DecimalFormat localDecimalFormat = new DecimalFormat("0.#");
/* 294 */       if (d2 < 1.0D) localDecimalFormat = new DecimalFormat("0.######");
/* 295 */       if ((d2 < 1.0E-5D) || (d2 >= 1000000.0D)) localDecimalFormat = new DecimalFormat("0.###E0");
/* 296 */       if (d2 == 0.0D) localDecimalFormat = new DecimalFormat("0.#");
/* 297 */       str = localDecimalFormat.format(d1);
/*     */     }
/* 299 */     if (str.equals(localWatcher.readout.contents)) return;
/* 300 */     localWatcher.inval();
/* 301 */     localWatcher.readout.contents = str;
/* 302 */     localWatcher.inval();
/*     */   }
/*     */   
/*     */   Object prim_listContents(Object paramObject, LContext paramLContext) {
/* 306 */     if (!(paramObject instanceof Object[])) {
/* 307 */       Logo.error("argument must be a list", paramLContext);
/* 308 */       return "";
/*     */     }
/* 310 */     Object[] arrayOfObject = (Object[])paramObject;
/* 311 */     if (arrayOfObject.length == 0) return "";
/* 312 */     StringBuffer localStringBuffer = new StringBuffer(1000);
/*     */     
/*     */ 
/* 315 */     int i = 0;
/* 316 */     Object localObject; for (int j = 0; j < arrayOfObject.length; j++) {
/* 317 */       localObject = arrayOfObject[j];
/* 318 */       if (!(localObject instanceof String)) localObject = Logo.prs(localObject);
/* 319 */       if (((String)localObject).length() > 1) { i = 1;
/*     */       }
/*     */     }
/* 322 */     for (j = 0; j < arrayOfObject.length; j++) {
/* 323 */       localObject = arrayOfObject[j];
/* 324 */       if (!(localObject instanceof String)) localObject = Logo.prs(localObject);
/* 325 */       localStringBuffer.append(localObject);
/* 326 */       if (i != 0) localStringBuffer.append(" ");
/*     */     }
/* 328 */     if (i != 0) localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
/* 329 */     return localStringBuffer.toString();
/*     */   }
/*     */   
/*     */   Object prim_hasKey(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 333 */     Hashtable localHashtable = (Hashtable)paramLContext.props.get(paramObject1);
/* 334 */     if (localHashtable == null) return new Boolean(false);
/* 335 */     return new Boolean(localHashtable.containsKey(paramObject2));
/*     */   }
/*     */   
/*     */   Object prim_newListWatcher(LContext paramLContext) {
/* 339 */     ListWatcher localListWatcher = new ListWatcher(paramLContext);
/* 340 */     Object[] arrayOfObject = new Object[paramLContext.canvas.sprites.length + 1];
/* 341 */     for (int i = 0; i < paramLContext.canvas.sprites.length; i++) {
/* 342 */       arrayOfObject[i] = paramLContext.canvas.sprites[i];
/*     */     }
/* 344 */     arrayOfObject[(arrayOfObject.length - 1)] = localListWatcher;
/* 345 */     paramLContext.canvas.sprites = arrayOfObject;
/* 346 */     return localListWatcher;
/*     */   }
/*     */   
/*     */   void prim_setListWatcherXY(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 350 */     if (!(paramObject1 instanceof ListWatcher)) return;
/* 351 */     ListWatcher localListWatcher = (ListWatcher)paramObject1;
/* 352 */     localListWatcher.inval();
/* 353 */     localListWatcher.box.x = Logo.anInt(paramObject2, paramLContext);
/* 354 */     localListWatcher.box.y = Logo.anInt(paramObject3, paramLContext);
/* 355 */     localListWatcher.inval();
/*     */   }
/*     */   
/*     */   void prim_setListWatcherWidthHeight(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 359 */     if (!(paramObject1 instanceof ListWatcher)) return;
/* 360 */     ListWatcher localListWatcher = (ListWatcher)paramObject1;
/* 361 */     localListWatcher.inval();
/* 362 */     localListWatcher.box.w = Logo.anInt(paramObject2, paramLContext);
/* 363 */     localListWatcher.box.h = Logo.anInt(paramObject3, paramLContext);
/* 364 */     localListWatcher.scrollBarHeight = (localListWatcher.box.h - 23 - 20);
/* 365 */     localListWatcher.pane.w = localListWatcher.box.w;
/* 366 */     localListWatcher.inval();
/*     */   }
/*     */   
/*     */   void prim_setListWatcherLabel(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 370 */     if (!(paramObject1 instanceof ListWatcher)) return;
/* 371 */     ListWatcher localListWatcher = (ListWatcher)paramObject1;
/* 372 */     localListWatcher.inval();
/* 373 */     localListWatcher.listTitle = Logo.aString(paramObject2, paramLContext);
/* 374 */     localListWatcher.inval();
/*     */   }
/*     */   
/*     */   void prim_setListWatcherList(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 378 */     if (!(paramObject1 instanceof ListWatcher)) return;
/* 379 */     if (!(paramObject2 instanceof Object[])) return;
/* 380 */     ListWatcher localListWatcher = (ListWatcher)paramObject1;
/* 381 */     localListWatcher.setList((Object[])paramObject2);
/* 382 */     localListWatcher.inval();
/*     */   }
/*     */   
/*     */   void prim_highlightListWatcherIndex(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 386 */     if (!(paramObject1 instanceof ListWatcher)) return;
/* 387 */     ListWatcher localListWatcher = (ListWatcher)paramObject1;
/* 388 */     localListWatcher.highlightIndex(Logo.anInt(paramObject2, paramLContext));
/* 389 */     localListWatcher.inval();
/*     */   }
/*     */   
/*     */   void prim_clearListWatcherHighlights(Object paramObject, LContext paramLContext) {
/* 393 */     if (!(paramObject instanceof ListWatcher)) return;
/* 394 */     ListWatcher localListWatcher = (ListWatcher)paramObject;
/* 395 */     localListWatcher.clearHighlights();
/* 396 */     localListWatcher.inval();
/*     */   }
/*     */   
/*     */   Watcher prim_newVarWatcher(Object paramObject, LContext paramLContext) {
/* 400 */     return new Watcher(paramLContext);
/*     */   }
/*     */   
/*     */   Object prim_watcherX(Object paramObject, LContext paramLContext) {
/* 404 */     if ((paramObject instanceof Watcher)) return new Double(((Watcher)paramObject).box.x);
/* 405 */     if ((paramObject instanceof ListWatcher)) return new Double(((ListWatcher)paramObject).box.x);
/* 406 */     return new Double(0.0D);
/*     */   }
/*     */   
/*     */   Object prim_watcherY(Object paramObject, LContext paramLContext) {
/* 410 */     if ((paramObject instanceof Watcher)) return new Double(((Watcher)paramObject).box.y);
/* 411 */     if ((paramObject instanceof ListWatcher)) return new Double(((ListWatcher)paramObject).box.y);
/* 412 */     return new Double(0.0D);
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\SpritePrims.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */