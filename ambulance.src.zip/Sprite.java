/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Color;
/*     */ import java.awt.Composite;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Double;
/*     */ import java.awt.geom.Rectangle2D.Float;
/*     */ import java.awt.image.AffineTransformOp;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Sprite
/*     */   implements Drawable
/*     */ {
/*     */   static final int originX = 241;
/*     */   static final int originY = 206;
/*     */   PlayerCanvas canvas;
/*     */   BufferedImage costume;
/*     */   BufferedImage rotatedCostume;
/*     */   BufferedImage filteredCostume;
/*     */   BufferedImage tempImage;
/*     */   double x;
/*     */   double y;
/* 433 */   boolean isShowing = true;
/* 434 */   boolean isDraggable = false;
/* 435 */   double alpha = 1.0D;
/* 436 */   double scale = 1.0D;
/* 437 */   double rotationDegrees = 90.0D;
/*     */   int rotationstyle;
/*     */   int rotationX;
/*     */   int rotationY;
/*     */   int offsetX;
/*     */   int offsetY;
/*     */   Bubble bubble;
/* 444 */   boolean penDown; int lastPenX; int lastPenY; Color penColor = new Color(0, 0, 255);
/* 445 */   int penSize = 1;
/*     */   
/*     */   double penHue;
/*     */   
/*     */   double penShade;
/* 450 */   boolean filterChanged = false;
/*     */   double color;
/*     */   double brightness;
/*     */   double fisheye;
/*     */   double whirl;
/*     */   double mosaic;
/*     */   double pixelate;
/* 457 */   ImageFilter imageFilter = new ImageFilter();
/*     */   
/*     */   Sprite(LContext paramLContext) {
/* 460 */     setPenColor(this.penColor);
/* 461 */     if (paramLContext != null) this.canvas = paramLContext.canvas;
/*     */   }
/*     */   
/* 464 */   int screenX() { return 241 + (int)(this.x - this.offsetX); }
/* 465 */   int screenY() { return 206 + (int)(-this.y - this.offsetY); }
/* 466 */   void setscreenX(double paramDouble) { this.x = (paramDouble + this.offsetX - 241.0D); }
/* 467 */   void setscreenY(double paramDouble) { this.y = (-(paramDouble + this.offsetY - 206.0D)); }
/*     */   
/*     */   public void mouseDown(int paramInt1, int paramInt2) {}
/*     */   
/*     */   void setStageOffset()
/*     */   {
/* 473 */     this.x = (this.y = 0.0D);
/* 474 */     this.offsetX = (this.costume.getWidth(null) / 2);
/* 475 */     this.offsetY = (this.costume.getHeight(null) / 2);
/*     */   }
/*     */   
/*     */   public void dragTo(int paramInt1, int paramInt2) {
/* 479 */     inval();
/* 480 */     setscreenX(paramInt1);
/* 481 */     setscreenY(paramInt2);
/* 482 */     updateBubble();
/* 483 */     inval();
/*     */   }
/*     */   
/*     */   boolean containsPoint(int paramInt1, int paramInt2) {
/* 487 */     BufferedImage localBufferedImage = outImage();
/* 488 */     int i = screenX();
/* 489 */     int j = screenY();
/* 490 */     int k = localBufferedImage.getWidth(null);
/* 491 */     int m = localBufferedImage.getHeight(null);
/* 492 */     if ((paramInt1 < i) || (paramInt1 >= i + k) || (paramInt2 < j) || (paramInt2 >= j + m))
/* 493 */       return false;
/* 494 */     int n = localBufferedImage.getRGB(paramInt1 - i, paramInt2 - j);
/* 495 */     return (n & 0xFF000000) != 0;
/*     */   }
/*     */   
/*     */   boolean touchingSprite(Object paramObject, LContext paramLContext) {
/* 499 */     if (!(paramObject instanceof Sprite)) {
/* 500 */       Logo.error("argument must be a Sprite", paramLContext);
/* 501 */       return false;
/*     */     }
/* 503 */     Sprite localSprite = (Sprite)paramObject;
/* 504 */     Rectangle localRectangle = rect().intersection(localSprite.rect());
/* 505 */     if ((localRectangle.width <= 0) || (localRectangle.height <= 0)) { return false;
/*     */     }
/* 507 */     BufferedImage localBufferedImage1 = outImage();
/* 508 */     BufferedImage localBufferedImage2 = localSprite.outImage();
/*     */     
/* 510 */     int i = localRectangle.x - screenX();
/* 511 */     int j = localRectangle.y - screenY();
/* 512 */     int k = localRectangle.x - localSprite.screenX();
/* 513 */     int m = localRectangle.y - localSprite.screenY();
/* 514 */     for (int n = j; n < j + localRectangle.height; n++) {
/* 515 */       int i1 = k;
/* 516 */       for (int i2 = i; i2 < i + localRectangle.width; i2++) {
/* 517 */         int i3 = localBufferedImage1.getRGB(i2, n);
/* 518 */         int i4 = localBufferedImage2.getRGB(i1, m);
/* 519 */         if (((i3 & 0xFF000000) != 0) && ((i4 & 0xFF000000) != 0)) return true;
/* 520 */         i1++;
/*     */       }
/* 522 */       m++;
/*     */     }
/* 524 */     return false;
/*     */   }
/*     */   
/*     */   boolean touchingColor(Object paramObject, LContext paramLContext) {
/* 528 */     if (!(paramObject instanceof Color)) {
/* 529 */       Logo.error("argument of touchingColor? must be a Color", paramLContext);
/* 530 */       return false;
/*     */     }
/* 532 */     int i = ((Color)paramObject).getRGB() | 0xFF000000;
/* 533 */     Rectangle localRectangle = rect();
/* 534 */     BufferedImage localBufferedImage1 = outImage();
/* 535 */     BufferedImage localBufferedImage2 = paramLContext.canvas.drawAreaWithoutSprite(localRectangle, this);
/*     */     
/* 537 */     for (int j = 0; j < localRectangle.height; j++) {
/* 538 */       for (int k = 0; k < localRectangle.width; k++) {
/* 539 */         if (((localBufferedImage1.getRGB(k, j) & 0xFF000000) != 0) && 
/* 540 */           (colorsMatch(localBufferedImage2.getRGB(k, j), i))) {
/* 541 */           localBufferedImage2.flush();
/* 542 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 547 */     localBufferedImage2.flush();
/* 548 */     return false;
/*     */   }
/*     */   
/*     */   boolean colorTouchingColor(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 552 */     if ((!(paramObject1 instanceof Color)) || (!(paramObject2 instanceof Color))) {
/* 553 */       Logo.error("the arguments of colorTouchingColor? must be Colors", paramLContext);
/* 554 */       return false;
/*     */     }
/* 556 */     int i = ((Color)paramObject1).getRGB() | 0xFF000000;
/* 557 */     int j = ((Color)paramObject2).getRGB() | 0xFF000000;
/* 558 */     Rectangle localRectangle = rect();
/* 559 */     BufferedImage localBufferedImage1 = outImage();
/* 560 */     BufferedImage localBufferedImage2 = paramLContext.canvas.drawAreaWithoutSprite(localRectangle, this);
/*     */     
/* 562 */     for (int k = 0; k < localRectangle.height; k++) {
/* 563 */       for (int m = 0; m < localRectangle.width; m++) {
/* 564 */         if ((colorsMatch(localBufferedImage1.getRGB(m, k), i)) && (colorsMatch(localBufferedImage2.getRGB(m, k), j))) {
/* 565 */           localBufferedImage2.flush();
/* 566 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 570 */     localBufferedImage2.flush();
/* 571 */     return false;
/*     */   }
/*     */   
/*     */   boolean colorsMatch(int paramInt1, int paramInt2) {
/* 575 */     if ((paramInt1 & 0xFF000000) != (paramInt2 & 0xFF000000)) return false;
/* 576 */     if ((paramInt1 >> 16 & 0xF8) != (paramInt2 >> 16 & 0xF8)) return false;
/* 577 */     if ((paramInt1 >> 8 & 0xF8) != (paramInt2 >> 8 & 0xF8)) return false;
/* 578 */     if (((paramInt1 & 0xFFFF00) == 0) && ((paramInt2 & 0xFFFF00) == 0) && 
/* 579 */       ((paramInt1 & 0xFF) <= 8) && ((paramInt2 & 0xFF) <= 8)) { return true;
/*     */     }
/* 581 */     if ((paramInt1 & 0xF8) != (paramInt2 & 0xF8)) return false;
/* 582 */     return true;
/*     */   }
/*     */   
/*     */   void setalpha(Object paramObject, LContext paramLContext) {
/* 586 */     double d = Logo.aDouble(paramObject, paramLContext);
/* 587 */     if (d < 0.0D) d = -d;
/* 588 */     if (d > 1.0D) d = 1.0D;
/* 589 */     this.alpha = d;
/* 590 */     inval();
/*     */   }
/*     */   
/*     */   void setcostume(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 594 */     if (!(paramObject1 instanceof BufferedImage)) return;
/* 595 */     this.rotationX = Logo.anInt(paramObject2, paramLContext);
/* 596 */     this.rotationY = Logo.anInt(paramObject3, paramLContext);
/* 597 */     if (this.costume != null) inval();
/* 598 */     this.costume = ((BufferedImage)paramObject1);
/* 599 */     rotateAndScale();
/* 600 */     inval();
/*     */   }
/*     */   
/*     */   void costumeChanged() {
/* 604 */     inval();
/* 605 */     rotateAndScale();
/* 606 */     inval();
/*     */   }
/*     */   
/*     */   void setscale(Object paramObject, LContext paramLContext) {
/* 610 */     double d1 = Logo.aDouble(paramObject, paramLContext);
/* 611 */     double d2 = Math.min(this.costume.getWidth(null), 10);
/* 612 */     double d3 = Math.min(this.costume.getHeight(null), 10);
/* 613 */     double d4 = Math.max(d2 / 480.0D, d3 / 360.0D);
/* 614 */     double d5 = Math.min(480.0D / this.costume.getWidth(null), 360.0D / this.costume.getHeight(null));
/* 615 */     this.scale = Math.min(Math.max(d1, d4), d5);
/* 616 */     costumeChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void rotateAndScale()
/*     */   {
/* 623 */     this.filterChanged = true;
/* 624 */     double d1 = this.rotationstyle == 0 ? this.rotationDegrees : 90.0D;
/*     */     
/* 626 */     if ((this.rotatedCostume != null) && (this.rotatedCostume != this.costume)) this.rotatedCostume.flush();
/* 627 */     if ((this.scale == 1.0D) && (this.rotationDegrees == 90.0D)) {
/* 628 */       this.rotatedCostume = this.costume;
/* 629 */       this.offsetX = this.rotationX;
/* 630 */       this.offsetY = this.rotationY;
/* 631 */       return;
/*     */     }
/*     */     
/* 634 */     int i = this.costume.getWidth(null);
/* 635 */     int j = this.costume.getHeight(null);
/*     */     
/* 637 */     double d2 = Math.toRadians(d1 - 90.0D);
/* 638 */     AffineTransform localAffineTransform = AffineTransform.getRotateInstance(d2, i / 2, j / 2);
/* 639 */     localAffineTransform.scale(this.scale, this.scale);
/* 640 */     AffineTransformOp localAffineTransformOp = new AffineTransformOp(localAffineTransform, 2);
/*     */     
/* 642 */     Rectangle2D.Float localFloat = (Rectangle2D.Float)localAffineTransformOp.getBounds2D(this.costume);
/* 643 */     float f1 = -localFloat.x;
/* 644 */     float f2 = -localFloat.y;
/* 645 */     localAffineTransform = AffineTransform.getRotateInstance(d2, i / 2 + f1, j / 2 + f2);
/* 646 */     localAffineTransform.translate(f1, f2);
/* 647 */     localAffineTransform.scale(this.scale, this.scale);
/* 648 */     localAffineTransformOp = new AffineTransformOp(localAffineTransform, 2);
/* 649 */     this.rotatedCostume = localAffineTransformOp.filter(this.costume, null);
/*     */     
/*     */ 
/* 652 */     localAffineTransform = AffineTransform.getRotateInstance(d2, 0.0D, 0.0D);
/* 653 */     localAffineTransform.scale(this.scale, this.scale);
/* 654 */     Point2D localPoint2D = localAffineTransform.transform(new Point2D.Double(this.rotationX - i / 2, this.rotationY - j / 2), null);
/*     */     
/* 656 */     this.offsetX = ((int)(localPoint2D.getX() + this.rotatedCostume.getWidth(null) / 2));
/* 657 */     this.offsetY = ((int)(localPoint2D.getY() + this.rotatedCostume.getHeight(null) / 2));
/*     */     
/* 659 */     if (this.rotationstyle == 1) {
/* 660 */       double d3 = this.rotationDegrees < 0.0D ? this.rotationDegrees + 360.0D : this.rotationDegrees;
/* 661 */       if (d3 <= 180.0D) { return;
/*     */       }
/* 663 */       int k = this.rotatedCostume.getWidth(null);
/* 664 */       localAffineTransform = AffineTransform.getScaleInstance(-1.0D, 1.0D);
/* 665 */       localAffineTransform.translate(-k, 0.0D);
/* 666 */       localAffineTransformOp = new AffineTransformOp(localAffineTransform, 2);
/* 667 */       this.rotatedCostume = localAffineTransformOp.filter(this.rotatedCostume, null);
/*     */       
/* 669 */       this.offsetX = ((int)(k / 2 - this.scale * (this.rotationX - i / 2)));
/* 670 */       this.offsetY = ((int)(this.scale * this.rotationY));
/*     */     }
/*     */   }
/*     */   
/* 674 */   void show() { this.isShowing = true;inval(); }
/* 675 */   void hide() { this.isShowing = false;inval(); }
/* 676 */   public boolean isShowing() { return this.isShowing; }
/* 677 */   public boolean isVisible() { return (this.isShowing) && (this.alpha > 0.0D); }
/*     */   
/*     */   public Rectangle rect() {
/* 680 */     BufferedImage localBufferedImage = outImage();
/* 681 */     if (localBufferedImage == null) {
/* 682 */       return new Rectangle(screenX(), screenY(), 600, 600);
/*     */     }
/* 684 */     return new Rectangle(screenX(), screenY(), localBufferedImage.getWidth(null), localBufferedImage.getHeight(null));
/*     */   }
/*     */   
/*     */   public Rectangle fullRect() {
/* 688 */     Rectangle localRectangle = rect();
/* 689 */     if (this.bubble != null) localRectangle = localRectangle.union(this.bubble.rect());
/* 690 */     return localRectangle;
/*     */   }
/*     */   
/* 693 */   void inval() { this.canvas.inval(fullRect()); }
/*     */   
/*     */   public void paint(Graphics paramGraphics) {
/* 696 */     Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
/* 697 */     if (this.filterChanged) applyFilters();
/* 698 */     if (this.alpha != 1.0D) {
/* 699 */       Composite localComposite = localGraphics2D.getComposite();
/* 700 */       localGraphics2D.setComposite(AlphaComposite.getInstance(3, (float)this.alpha));
/* 701 */       localGraphics2D.drawImage(outImage(), screenX(), screenY(), null);
/* 702 */       localGraphics2D.setComposite(localComposite);
/*     */     } else {
/* 704 */       localGraphics2D.drawImage(outImage(), screenX(), screenY(), null);
/*     */     }
/*     */   }
/*     */   
/*     */   public void paintBubble(Graphics paramGraphics) {
/* 709 */     if (this.bubble != null) this.bubble.paint(paramGraphics);
/*     */   }
/*     */   
/*     */   void talkbubble(Object paramObject, boolean paramBoolean1, boolean paramBoolean2, LContext paramLContext) {
/* 713 */     String str = (paramObject instanceof String) ? (String)paramObject : Logo.prs(paramObject);
/* 714 */     inval();
/* 715 */     this.bubble = null;
/* 716 */     if (str.length() == 0) return;
/* 717 */     this.bubble = new Bubble();
/* 718 */     if (paramBoolean1) this.bubble.beAskBubble();
/* 719 */     if (!paramBoolean2) this.bubble.beThinkBubble(true);
/* 720 */     this.bubble.setContents(str);
/* 721 */     if ((this.rotationDegrees >= 0.0D) && (this.rotationDegrees <= 180.0D)) this.bubble.pointLeft = true;
/* 722 */     updateBubble();
/*     */   }
/*     */   
/*     */   void updateBubble() {
/* 726 */     int i = 3;
/* 727 */     int j = 482 - i;
/* 728 */     if (this.bubble == null) return;
/* 729 */     inval();
/*     */     
/*     */ 
/* 732 */     Rectangle localRectangle = rect();
/* 733 */     boolean bool = this.bubble.pointLeft;
/* 734 */     int[] arrayOfInt = bubbleInsets();
/* 735 */     if ((bool) && (localRectangle.x + localRectangle.width - arrayOfInt[1] + this.bubble.w + i > j)) bool = false;
/* 736 */     if ((!bool) && (localRectangle.x + arrayOfInt[0] - this.bubble.w - i < 0)) { bool = true;
/*     */     }
/* 738 */     if (bool) {
/* 739 */       this.bubble.pointLeft = true;
/* 740 */       this.bubble.x = (localRectangle.x + localRectangle.width - arrayOfInt[1] + i);
/*     */     } else {
/* 742 */       this.bubble.pointLeft = false;
/* 743 */       this.bubble.x = (localRectangle.x + arrayOfInt[0] - this.bubble.w - i);
/*     */     }
/*     */     
/*     */ 
/* 747 */     if (this.bubble.x + this.bubble.w > j) this.bubble.x = (j - this.bubble.w);
/* 748 */     if (this.bubble.x < i) this.bubble.x = i;
/* 749 */     this.bubble.y = Math.max(localRectangle.y - this.bubble.h - 12, 25 + i);
/* 750 */     if (this.bubble.y + this.bubble.h > 387) {
/* 751 */       this.bubble.y = (387 - this.bubble.h);
/*     */     }
/* 753 */     inval();
/*     */   }
/*     */   
/*     */   int[] bubbleInsets() {
/* 757 */     BufferedImage localBufferedImage = outImage();
/* 758 */     int i = localBufferedImage.getWidth();
/* 759 */     int j = localBufferedImage.getHeight();
/* 760 */     int k = i;
/* 761 */     int m = i;
/* 762 */     int n = -1;
/*     */     
/* 764 */     for (int i1 = 0; i1 < j; i1++) {
/* 765 */       int i2 = 0;
/*     */       
/* 767 */       for (int i4 = 0; i4 < Math.max(k, m); i4++) {
/* 768 */         int i3 = localBufferedImage.getRGB(i4, i1) & 0xFF000000;
/* 769 */         if ((i3 != 0) && (i4 < k)) { k = i4;i2 = 1; }
/* 770 */         i3 = localBufferedImage.getRGB(i - i4 - 1, i1) & 0xFF000000;
/* 771 */         if ((i3 != 0) && (i4 < m)) { m = i4;i2 = 1;
/*     */         } }
/* 773 */       if (n < 0) {
/* 774 */         if (i2 != 0) n = i1;
/*     */       } else
/* 776 */         if (i1 >= n + 10)
/*     */           break;
/*     */     }
/* 779 */     int[] arrayOfInt = new int[2];
/* 780 */     arrayOfInt[0] = k;
/* 781 */     arrayOfInt[1] = m;
/* 782 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   void setPenDown(boolean paramBoolean) {
/* 786 */     if (paramBoolean == this.penDown) return;
/* 787 */     if (paramBoolean) this.lastPenX = (this.lastPenY = -1000000);
/* 788 */     this.canvas.updatePenTrailForSprite(this);
/* 789 */     this.penDown = paramBoolean;
/*     */   }
/*     */   
/*     */   void setPenColor(Color paramColor) {
/* 793 */     float[] arrayOfFloat = Color.RGBtoHSB(paramColor.getRed(), paramColor.getGreen(), paramColor.getBlue(), null);
/* 794 */     this.penColor = paramColor;
/* 795 */     this.penHue = (200.0D * arrayOfFloat[0]);
/* 796 */     float f1 = arrayOfFloat[1];
/* 797 */     float f2 = arrayOfFloat[2];
/* 798 */     if (f2 == 1.0D) {
/* 799 */       this.penShade = (50.0D + 50.0D * (1.0D - f1));
/*     */     } else {
/* 801 */       this.penShade = (50.0D * f2);
/*     */     }
/*     */   }
/*     */   
/*     */   void setPenHue(double paramDouble) {
/* 806 */     this.penHue = (paramDouble % 200.0D);
/* 807 */     if (this.penHue < 0.0D) this.penHue = (200.0D + this.penHue);
/* 808 */     setPenShade(this.penShade);
/*     */   }
/*     */   
/*     */   void setPenShade(double paramDouble) {
/* 812 */     this.penShade = (paramDouble % 200.0D);
/* 813 */     if (this.penShade < 0.0D) this.penShade = (200.0D + this.penShade);
/* 814 */     float f1 = (float)(this.penShade > 100.0D ? 200.0D - this.penShade : this.penShade);
/* 815 */     float f2; if (f1 <= 50.0D) {
/* 816 */       f2 = (f1 + 10.0F) / 60.0F;
/* 817 */       this.penColor = new Color(Color.HSBtoRGB((float)(this.penHue / 200.0D), 1.0F, f2));
/*     */     } else {
/* 819 */       f2 = (100.0F - f1 + 10.0F) / 60.0F;
/* 820 */       this.penColor = new Color(Color.HSBtoRGB((float)(this.penHue / 200.0D), f2, 1.0F));
/*     */     }
/*     */   }
/*     */   
/*     */   BufferedImage outImage() {
/* 825 */     if (this.filteredCostume != null) return this.filteredCostume;
/* 826 */     if (this.rotatedCostume != null) return this.rotatedCostume;
/* 827 */     return this.costume;
/*     */   }
/*     */   
/*     */   void applyFilters() {
/* 831 */     if (!filtersActive()) {
/* 832 */       this.filteredCostume = null;
/* 833 */       this.filterChanged = false;
/* 834 */       return;
/*     */     }
/* 836 */     this.imageFilter.setSourceImage(this.rotatedCostume != null ? this.rotatedCostume : this.costume);
/* 837 */     if (this.color != 0.0D) this.imageFilter.applyHueShift((int)this.color);
/* 838 */     if (this.brightness != 0.0D) this.imageFilter.applyBrightnessShift((int)this.brightness);
/* 839 */     if (this.whirl != 0.0D) this.imageFilter.applyWhirl(this.whirl);
/* 840 */     if (this.fisheye != 0.0D) this.imageFilter.applyFisheye(this.fisheye);
/* 841 */     if (Math.abs(this.pixelate) >= 5.0D) this.imageFilter.applyPixelate(this.pixelate);
/* 842 */     if (Math.abs(this.mosaic) >= 5.0D) this.imageFilter.applyMosaic(this.mosaic);
/* 843 */     this.filteredCostume = this.imageFilter.filteredImage;
/* 844 */     this.filterChanged = false;
/*     */   }
/*     */   
/*     */   boolean filtersActive() {
/* 848 */     if ((this.color != 0.0D) || (this.brightness != 0.0D) || (this.fisheye != 0.0D) || (this.whirl != 0.0D) || (Math.abs(this.mosaic) >= 5.0D) || (Math.abs(this.pixelate) >= 5.0D))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 854 */       return true;
/*     */     }
/* 856 */     return false;
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\Sprite.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */