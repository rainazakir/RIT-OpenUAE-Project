/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.MediaTracker;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Skin
/*     */ {
/*     */   static boolean skinInitialized;
/*     */   static BufferedImage askBubbleFrame;
/*     */   static BufferedImage askPointerL;
/*     */   static BufferedImage askPointerR;
/*     */   static BufferedImage bubbleFrame;
/*     */   static BufferedImage goButton;
/*     */   static BufferedImage goButtonOver;
/*     */   static BufferedImage promptCheckButton;
/*     */   static BufferedImage sliderKnob;
/*     */   static BufferedImage sliderSlot;
/*     */   static BufferedImage stopButton;
/*     */   static BufferedImage stopButtonOver;
/*     */   static BufferedImage talkPointerL;
/*     */   static BufferedImage talkPointerR;
/*     */   static BufferedImage thinkPointerL;
/*     */   static BufferedImage thinkPointerR;
/*     */   static BufferedImage watcherOuterFrame;
/*     */   static BufferedImage listWatcherOuterFrame;
/*     */   static BufferedImage listWatcherOuterFrameError;
/*     */   static BufferedImage vScrollFrame;
/*     */   static BufferedImage vScrollSlider;
/*     */   
/*     */   static synchronized void readSkin(Component paramComponent)
/*     */   {
/* 424 */     if (skinInitialized) return;
/* 425 */     askBubbleFrame = readImage("askBubbleFrame.gif", paramComponent);
/* 426 */     askPointerL = readImage("askBubblePointer.gif", paramComponent);
/* 427 */     askPointerR = flipImage(askPointerL);
/* 428 */     bubbleFrame = readImage("talkBubbleFrame.gif", paramComponent);
/* 429 */     goButton = readImage("goButton.gif", paramComponent);
/* 430 */     goButtonOver = readImage("goButtonOver.gif", paramComponent);
/* 431 */     promptCheckButton = readImage("promptCheckButton.png", paramComponent);
/* 432 */     sliderKnob = readImage("sliderKnob.gif", paramComponent);
/* 433 */     sliderSlot = readImage("sliderSlot.gif", paramComponent);
/* 434 */     stopButton = readImage("stopButton.gif", paramComponent);
/* 435 */     stopButtonOver = readImage("stopButtonOver.gif", paramComponent);
/* 436 */     talkPointerL = readImage("talkBubbleTalkPointer.gif", paramComponent);
/* 437 */     talkPointerR = flipImage(talkPointerL);
/* 438 */     thinkPointerL = readImage("talkBubbleThinkPointer.gif", paramComponent);
/* 439 */     thinkPointerR = flipImage(thinkPointerL);
/* 440 */     watcherOuterFrame = readImage("watcherOuterFrame.png", paramComponent);
/* 441 */     listWatcherOuterFrame = readImage("listWacherOuterFrame.png", paramComponent);
/* 442 */     listWatcherOuterFrameError = readImage("listWacherOuterFrameError.png", paramComponent);
/* 443 */     vScrollFrame = readImage("vScrollFrame.png", paramComponent);
/* 444 */     vScrollSlider = readImage("vScrollSlider.png", paramComponent);
/* 445 */     skinInitialized = true;
/*     */   }
/*     */   
/*     */   static BufferedImage readImage(String paramString, Component paramComponent) {
/* 449 */     Toolkit localToolkit = Toolkit.getDefaultToolkit();
/* 450 */     Image localImage = localToolkit.createImage(paramComponent.getClass().getResource("skin/" + paramString));
/* 451 */     MediaTracker localMediaTracker = new MediaTracker(paramComponent);
/* 452 */     localMediaTracker.addImage(localImage, 0);
/*     */     try {
/* 454 */       localMediaTracker.waitForID(0);
/*     */     }
/*     */     catch (InterruptedException localInterruptedException) {}
/*     */     
/* 458 */     int i = localImage.getWidth(null);
/* 459 */     int j = localImage.getHeight(null);
/* 460 */     BufferedImage localBufferedImage = new BufferedImage(i, j, 2);
/* 461 */     Graphics localGraphics = localBufferedImage.getGraphics();
/* 462 */     localGraphics.drawImage(localImage, 0, 0, i, j, null);
/* 463 */     localGraphics.dispose();
/* 464 */     return localBufferedImage;
/*     */   }
/*     */   
/*     */   static BufferedImage flipImage(BufferedImage paramBufferedImage) {
/* 468 */     int i = paramBufferedImage.getWidth(null);
/* 469 */     int j = paramBufferedImage.getHeight(null);
/* 470 */     BufferedImage localBufferedImage = new BufferedImage(i, j, 2);
/* 471 */     Graphics localGraphics = localBufferedImage.getGraphics();
/* 472 */     localGraphics.drawImage(paramBufferedImage, i, 0, 0, j, 0, 0, i, j, null);
/* 473 */     localGraphics.dispose();
/* 474 */     return localBufferedImage;
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\Skin.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */