/*     */ class WordListPrims extends Primitives
/*     */ {
/*   3 */   static String[] primlist = { "first", "1", "last", "1", "word", "i2", "butfirst", "1", "bf", "1", "butlast", "1", "bl", "1", "fput", "2", "lput", "2", "item", "2", "nth", "2", "empty?", "1", "count", "1", "word?", "1", "list?", "1", "member?", "2", "itempos", "2", "setitem", "3", "setnth", "3", "removeitem", "2", "removeitempos", "2", "sentence", "2", "se", "i2", "list", "i2", "makelist", "1", "copylist", "1", "parse", "1", "char", "1", "ascii", "1", "reverse", "1", "substring", "3", "ucase", "1", "insert", "3" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] primlist()
/*     */   {
/*  37 */     return primlist;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object dispatch(int paramInt, Object[] paramArrayOfObject, LContext paramLContext)
/*     */   {
/*  45 */     switch (paramInt) {
/*  46 */     case 0:  return prim_first(paramArrayOfObject[0], paramLContext);
/*  47 */     case 1:  return prim_last(paramArrayOfObject[0], paramLContext);
/*  48 */     case 2:  return prim_word(paramArrayOfObject, paramLContext);
/*  49 */     case 3: case 4:  return prim_butfirst(paramArrayOfObject[0], paramLContext);
/*  50 */     case 5: case 6:  return prim_butlast(paramArrayOfObject[0], paramLContext);
/*  51 */     case 7:  return prim_fput(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  52 */     case 8:  return prim_lput(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  53 */     case 9:  return prim_item(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  54 */     case 10:  return prim_nth(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  55 */     case 11:  return prim_emptyp(paramArrayOfObject[0], paramLContext);
/*  56 */     case 12:  return prim_count(paramArrayOfObject[0], paramLContext);
/*  57 */     case 13:  return prim_wordp(paramArrayOfObject[0], paramLContext);
/*  58 */     case 14:  return prim_listp(paramArrayOfObject[0], paramLContext);
/*  59 */     case 15:  return prim_memberp(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  60 */     case 16:  return prim_itempos(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  61 */     case 17:  return prim_setitem(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);
/*  62 */     case 18:  return prim_setnth(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);
/*  63 */     case 19:  return prim_removeitem(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  64 */     case 20:  return prim_removeitempos(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  65 */     case 21: case 22:  return prim_sentence(paramArrayOfObject, paramLContext);
/*  66 */     case 23:  return prim_list(paramArrayOfObject, paramLContext);
/*  67 */     case 24:  return prim_makelist(paramArrayOfObject[0], paramLContext);
/*  68 */     case 25:  return prim_copylist(paramArrayOfObject[0], paramLContext);
/*  69 */     case 26:  return prim_parse(paramArrayOfObject[0], paramLContext);
/*  70 */     case 27:  return prim_char(paramArrayOfObject[0], paramLContext);
/*  71 */     case 28:  return prim_ascii(paramArrayOfObject[0], paramLContext);
/*  72 */     case 29:  return prim_reverse(paramArrayOfObject[0], paramLContext);
/*  73 */     case 30:  return prim_substring(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);
/*  74 */     case 31:  return prim_ucase(paramArrayOfObject[0], paramLContext);
/*  75 */     case 32:  return prim_insert(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);
/*     */     }
/*  77 */     return null;
/*     */   }
/*     */   
/*     */   Object copyList(Object[] paramArrayOfObject, int paramInt1, int paramInt2) {
/*  81 */     Object[] arrayOfObject = new Object[paramInt2];
/*  82 */     for (int i = 0; i < paramInt2; i++) arrayOfObject[i] = paramArrayOfObject[(paramInt1++)];
/*  83 */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   Object addToList(Object[] paramArrayOfObject, Object paramObject) {
/*  87 */     if (!(paramObject instanceof Object[])) return lput(paramObject, paramArrayOfObject);
/*  88 */     Object[] arrayOfObject1 = (Object[])paramObject;Object[] arrayOfObject2 = new Object[paramArrayOfObject.length + arrayOfObject1.length];
/*  89 */     for (int i = 0; i < paramArrayOfObject.length; i++) arrayOfObject2[i] = paramArrayOfObject[i];
/*  90 */     for (i = 0; i < arrayOfObject1.length; i++) arrayOfObject2[(i + paramArrayOfObject.length)] = arrayOfObject1[i];
/*  91 */     return arrayOfObject2;
/*     */   }
/*     */   
/*     */   Object removeItem(Object[] paramArrayOfObject, int paramInt)
/*     */   {
/*  96 */     Object[] arrayOfObject = new Object[paramArrayOfObject.length - 1];int i = 0;
/*  97 */     for (int j = 0; j < paramArrayOfObject.length; j++) if (j != paramInt - 1) arrayOfObject[(i++)] = paramArrayOfObject[j];
/*  98 */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   static Object lput(Object paramObject, Object[] paramArrayOfObject) {
/* 102 */     Object[] arrayOfObject = new Object[paramArrayOfObject.length + 1];
/* 103 */     for (int i = 0; i < paramArrayOfObject.length; i++) arrayOfObject[i] = paramArrayOfObject[i];
/* 104 */     arrayOfObject[paramArrayOfObject.length] = paramObject;
/* 105 */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   static int memberp(Object paramObject1, Object paramObject2) {
/* 109 */     if ((paramObject2 instanceof Object[])) {
/* 110 */       localObject = (Object[])paramObject2;
/* 111 */       for (int i = 0; i < localObject.length; i++)
/* 112 */         if (Logo.prs(paramObject1).equals(Logo.prs(localObject[i]))) return i + 1;
/* 113 */       return 0;
/*     */     }
/* 115 */     if ((paramObject1 instanceof Object[])) return 0;
/* 116 */     Object localObject = Logo.prs(paramObject1);String str = Logo.prs(paramObject2);
/* 117 */     for (int j = 0; j < str.length(); j++)
/* 118 */       if (((String)localObject).regionMatches(true, 0, str, j, ((String)localObject).length()))
/* 119 */         return j + 1;
/* 120 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object prim_first(Object paramObject, LContext paramLContext)
/*     */   {
/* 129 */     if ((paramObject instanceof Object[])) return ((Object[])paramObject)[0];
/* 130 */     return Logo.prs(paramObject).substring(0, 1);
/*     */   }
/*     */   
/*     */   Object prim_last(Object paramObject, LContext paramLContext) {
/* 134 */     if ((paramObject instanceof Object[])) {
/* 135 */       localObject = (Object[])paramObject;
/* 136 */       return localObject[(localObject.length - 1)];
/*     */     }
/* 138 */     Object localObject = Logo.prs(paramObject);
/* 139 */     return ((String)localObject).substring(((String)localObject).length() - 1, ((String)localObject).length());
/*     */   }
/*     */   
/*     */   Object prim_word(Object[] paramArrayOfObject, LContext paramLContext) {
/* 143 */     String str = "";
/* 144 */     for (int i = 0; i < paramArrayOfObject.length; i++) str = str + Logo.prs(paramArrayOfObject[i]);
/* 145 */     return str;
/*     */   }
/*     */   
/*     */   Object prim_butfirst(Object paramObject, LContext paramLContext) {
/* 149 */     if ((paramObject instanceof Object[])) {
/* 150 */       localObject = (Object[])paramObject;
/* 151 */       return copyList((Object[])localObject, 1, localObject.length - 1);
/*     */     }
/* 153 */     Object localObject = Logo.prs(paramObject);
/* 154 */     return ((String)localObject).substring(1, ((String)localObject).length());
/*     */   }
/*     */   
/*     */   Object prim_butlast(Object paramObject, LContext paramLContext)
/*     */   {
/* 159 */     if ((paramObject instanceof Object[])) {
/* 160 */       localObject = (Object[])paramObject;
/* 161 */       return copyList((Object[])localObject, 0, localObject.length - 1);
/*     */     }
/* 163 */     Object localObject = Logo.prs(paramObject);
/* 164 */     return ((String)localObject).substring(0, ((String)localObject).length() - 1);
/*     */   }
/*     */   
/*     */   Object prim_fput(Object paramObject1, Object paramObject2, LContext paramLContext)
/*     */   {
/* 169 */     Object[] arrayOfObject1 = (Object[])Logo.aList(paramObject2, paramLContext);
/* 170 */     Object[] arrayOfObject2 = new Object[arrayOfObject1.length + 1];
/* 171 */     arrayOfObject2[0] = paramObject1;
/* 172 */     for (int i = 0; i < arrayOfObject1.length; i++) arrayOfObject2[(i + 1)] = arrayOfObject1[i];
/* 173 */     return arrayOfObject2;
/*     */   }
/*     */   
/*     */   Object prim_lput(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 177 */     return lput(paramObject1, Logo.aList(paramObject2, paramLContext));
/*     */   }
/*     */   
/*     */   Object prim_item(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 181 */     int i = Logo.anInt(paramObject1, paramLContext) - 1;
/* 182 */     return (paramObject2 instanceof Object[]) ? ((Object[])paramObject2)[i] : Logo.prs(paramObject2).substring(i, i + 1);
/*     */   }
/*     */   
/*     */   Object prim_nth(Object paramObject1, Object paramObject2, LContext paramLContext)
/*     */   {
/* 187 */     int i = Logo.anInt(paramObject1, paramLContext);
/* 188 */     return (paramObject2 instanceof Object[]) ? ((Object[])paramObject2)[i] : Logo.prs(paramObject2).substring(i, i + 1);
/*     */   }
/*     */   
/*     */   Object prim_emptyp(Object paramObject, LContext paramLContext)
/*     */   {
/* 193 */     return new Boolean(((Object[])paramObject).length == 0);
/*     */   }
/*     */   
/*     */   Object prim_count(Object paramObject, LContext paramLContext)
/*     */   {
/* 198 */     return new Long((paramObject instanceof Object[]) ? ((Object[])paramObject).length : Logo.prs(paramObject).length());
/*     */   }
/*     */   
/*     */   Object prim_wordp(Object paramObject, LContext paramLContext)
/*     */   {
/* 203 */     return new Boolean(!(paramObject instanceof Object[]));
/*     */   }
/*     */   
/*     */   Object prim_listp(Object paramObject, LContext paramLContext) {
/* 207 */     return new Boolean(paramObject instanceof Object[]);
/*     */   }
/*     */   
/*     */   Object prim_memberp(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 211 */     return new Boolean(memberp(paramObject1, paramObject2) != 0);
/*     */   }
/*     */   
/*     */   Object prim_itempos(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 215 */     int i = memberp(paramObject1, paramObject2); if (i != 0) return new Long(i);
/* 216 */     Logo.error(paramLContext.cfun + " doesn't like " + Logo.prs(paramObject1) + " as input", paramLContext);
/* 217 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_setitem(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 221 */     ((Object[])Logo.aList(paramObject2, paramLContext))[(Logo.anInt(paramObject1, paramLContext) - 1)] = paramObject3;
/* 222 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_setnth(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 226 */     ((Object[])Logo.aList(paramObject2, paramLContext))[Logo.anInt(paramObject1, paramLContext)] = paramObject3;
/* 227 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_removeitem(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 231 */     Object[] arrayOfObject = Logo.aList(paramObject2, paramLContext);
/* 232 */     return removeItem(arrayOfObject, memberp(paramObject1, arrayOfObject));
/*     */   }
/*     */   
/*     */   Object prim_removeitempos(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 236 */     return removeItem(Logo.aList(paramObject2, paramLContext), Logo.anInt(paramObject1, paramLContext));
/*     */   }
/*     */   
/*     */   Object prim_sentence(Object[] paramArrayOfObject, LContext paramLContext) {
/* 240 */     Object[] arrayOfObject = new Object[0];
/* 241 */     for (int i = 0; i < paramArrayOfObject.length; i++) arrayOfObject = (Object[])addToList(arrayOfObject, paramArrayOfObject[i]);
/* 242 */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   Object prim_list(Object[] paramArrayOfObject, LContext paramLContext) {
/* 246 */     Object[] arrayOfObject = new Object[paramArrayOfObject.length];
/* 247 */     for (int i = 0; i < paramArrayOfObject.length; i++) arrayOfObject[i] = paramArrayOfObject[i];
/* 248 */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   Object prim_makelist(Object paramObject, LContext paramLContext) {
/* 252 */     int i = Logo.anInt(paramObject, paramLContext);Object[] arrayOfObject = new Object[i];
/* 253 */     for (int j = 0; j < i; j++) arrayOfObject[j] = new Object[0];
/* 254 */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   Object prim_copylist(Object paramObject, LContext paramLContext) {
/* 258 */     Object[] arrayOfObject = Logo.aList(paramObject, paramLContext);
/* 259 */     return copyList(arrayOfObject, 0, arrayOfObject.length);
/*     */   }
/*     */   
/*     */   Object prim_parse(Object paramObject, LContext paramLContext) {
/* 263 */     return Logo.parse(Logo.aString(paramObject, paramLContext), paramLContext);
/*     */   }
/*     */   
/*     */   Object prim_char(Object paramObject, LContext paramLContext) {
/* 267 */     char[] arrayOfChar = new char[1];
/* 268 */     arrayOfChar[0] = ((char)Logo.anInt(paramObject, paramLContext));
/* 269 */     return new String(arrayOfChar);
/*     */   }
/*     */   
/*     */   Object prim_ascii(Object paramObject, LContext paramLContext) {
/* 273 */     return new Long(Logo.aString(paramObject, paramLContext).charAt(0));
/*     */   }
/*     */   
/*     */   Object prim_reverse(Object paramObject, LContext paramLContext) {
/* 277 */     Object[] arrayOfObject1 = Logo.aList(paramObject, paramLContext);
/* 278 */     Object[] arrayOfObject2 = new Object[arrayOfObject1.length];
/* 279 */     for (int i = 0; i < arrayOfObject1.length; i++) arrayOfObject2[i] = arrayOfObject1[(arrayOfObject1.length - i - 1)];
/* 280 */     return arrayOfObject2;
/*     */   }
/*     */   
/*     */   Object prim_substring(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 284 */     String str = Logo.prs(paramObject1);
/* 285 */     int i = Logo.anInt(paramObject2, paramLContext);int j = Logo.anInt(paramObject3, paramLContext);
/* 286 */     if (i == -1) return str.substring(str.length() - j, str.length());
/* 287 */     if (j == -1) return str.substring(i, str.length());
/* 288 */     return str.substring(i, i + j);
/*     */   }
/*     */   
/*     */   Object prim_ucase(Object paramObject, LContext paramLContext) {
/* 292 */     return Logo.prs(paramObject).toUpperCase();
/*     */   }
/*     */   
/*     */   Object prim_insert(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 296 */     Object[] arrayOfObject1 = Logo.aList(paramObject1, paramLContext);
/* 297 */     int i = Logo.anInt(paramObject2, paramLContext) - 1;
/* 298 */     if ((0 > i) || (i > arrayOfObject1.length)) {
/* 299 */       Logo.error(paramLContext.cfun + " doesn't like " + Logo.prs(paramObject2) + " as input", paramLContext);
/*     */     }
/* 301 */     Object[] arrayOfObject2 = new Object[arrayOfObject1.length + 1];
/* 302 */     int j = 0;
/* 303 */     for (int k = 0; k < arrayOfObject1.length; k++) {
/* 304 */       if (k == i) arrayOfObject2[(j++)] = paramObject3;
/* 305 */       arrayOfObject2[(j++)] = arrayOfObject1[k];
/*     */     }
/* 307 */     if (i == arrayOfObject1.length) arrayOfObject2[j] = paramObject3;
/* 308 */     return arrayOfObject2;
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\WordListPrims.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */