/*     */ import java.awt.image.AffineTransformOp;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ class ImageFilter
/*     */ {
/*     */   BufferedImage filteredImage;
/*     */   BufferedImage tempImage;
/*     */   
/*     */   void setSourceImage(BufferedImage paramBufferedImage)
/*     */   {
/*  11 */     if ((this.filteredImage == null) || (this.filteredImage.getWidth(null) != paramBufferedImage.getWidth(null)) || (this.filteredImage.getHeight(null) != paramBufferedImage.getHeight(null)))
/*     */     {
/*     */ 
/*     */ 
/*  15 */       if (this.filteredImage != null) this.filteredImage.flush();
/*  16 */       this.filteredImage = new BufferedImage(paramBufferedImage.getWidth(null), paramBufferedImage.getHeight(null), 2);
/*     */     }
/*  18 */     this.filteredImage.getRaster().setDataElements(0, 0, paramBufferedImage.getData());
/*     */   }
/*     */   
/*     */   BufferedImage makeOutputImage(BufferedImage paramBufferedImage) {
/*  22 */     if ((this.tempImage == null) || (this.tempImage.getWidth(null) != paramBufferedImage.getWidth(null)) || (this.tempImage.getHeight(null) != paramBufferedImage.getHeight(null)))
/*     */     {
/*     */ 
/*     */ 
/*  26 */       if (this.tempImage != null) this.tempImage.flush();
/*  27 */       this.tempImage = new BufferedImage(paramBufferedImage.getWidth(null), paramBufferedImage.getHeight(null), 2);
/*     */     }
/*  29 */     return this.tempImage;
/*     */   }
/*     */   
/*     */   void applyHueShift(int paramInt) {
/*  33 */     BufferedImage localBufferedImage1 = this.filteredImage;
/*  34 */     BufferedImage localBufferedImage2 = makeOutputImage(localBufferedImage1);
/*     */     
/*  36 */     int i7 = localBufferedImage1.getWidth();
/*  37 */     int i8 = localBufferedImage1.getHeight();
/*     */     
/*  39 */     for (int i9 = 0; i9 < i7; i9++) {
/*  40 */       for (int i10 = 0; i10 < i8; i10++) { int j;
/*  41 */         int i = j = localBufferedImage1.getRGB(i9, i10);
/*  42 */         int k = i & 0xFF000000;
/*  43 */         if (k != 0) {
/*  44 */           int m = i >> 16 & 0xFF;
/*  45 */           int n = i >> 8 & 0xFF;
/*  46 */           int i1 = i & 0xFF;
/*  47 */           int i2 = m < n ? m : n; if (i1 < i2) i2 = i1;
/*  48 */           int i3 = m > n ? m : n; if (i1 > i3) { i3 = i1;
/*     */           }
/*  50 */           int i6 = i3 * 1000 / 255;
/*  51 */           if (i6 < 150) { i6 = 150;
/*     */           }
/*  53 */           int i5 = i3 == 0 ? 0 : (i3 - i2) * 1000 / i3;
/*  54 */           if (i5 < 150) { i5 = 150;
/*     */           }
/*  56 */           int i4 = rgb2hue(m, n, i1, i2, i3) + 180 * paramInt / 100;
/*  57 */           j = k | hsv2rgb(i4, i5, i6);
/*     */         }
/*  59 */         localBufferedImage2.setRGB(i9, i10, j);
/*     */       }
/*     */     }
/*  62 */     this.tempImage = this.filteredImage;
/*  63 */     this.filteredImage = localBufferedImage2;
/*     */   }
/*     */   
/*     */   void applyBrightnessShift(int paramInt) {
/*  67 */     BufferedImage localBufferedImage1 = this.filteredImage;
/*  68 */     BufferedImage localBufferedImage2 = makeOutputImage(localBufferedImage1);
/*     */     
/*  70 */     int i7 = localBufferedImage1.getWidth();
/*  71 */     int i8 = localBufferedImage1.getHeight();
/*     */     
/*  73 */     for (int i9 = 0; i9 < i7; i9++) {
/*  74 */       for (int i10 = 0; i10 < i8; i10++) { int j;
/*  75 */         int i = j = localBufferedImage1.getRGB(i9, i10);
/*  76 */         int k = i & 0xFF000000;
/*  77 */         if (k != 0) {
/*  78 */           int m = i >> 16 & 0xFF;
/*  79 */           int n = i >> 8 & 0xFF;
/*  80 */           int i1 = i & 0xFF;
/*  81 */           int i2 = m < n ? m : n; if (i1 < i2) i2 = i1;
/*  82 */           int i3 = m > n ? m : n; if (i1 > i3) i3 = i1;
/*  83 */           int i4 = rgb2hue(m, n, i1, i2, i3);
/*  84 */           int i5 = i3 == 0 ? 0 : (i3 - i2) * 1000 / i3;
/*  85 */           int i6 = i3 * 1000 / 255 + 10 * paramInt;
/*  86 */           if (i6 > 1000) i6 = 1000;
/*  87 */           if (i6 < 0) { i6 = 0;
/*     */           }
/*  89 */           j = k | hsv2rgb(i4, i5, i6);
/*     */         }
/*  91 */         localBufferedImage2.setRGB(i9, i10, j);
/*     */       }
/*     */     }
/*  94 */     this.tempImage = this.filteredImage;
/*  95 */     this.filteredImage = localBufferedImage2;
/*     */   }
/*     */   
/*     */   int rgb2hue(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  99 */     int i = paramInt5 - paramInt4;
/* 100 */     if (i == 0) return 0;
/* 101 */     if (paramInt1 == paramInt5) return 60 * (paramInt2 - paramInt3) / i;
/* 102 */     if (paramInt2 == paramInt5) return 120 + 60 * (paramInt3 - paramInt1) / i;
/* 103 */     return 240 + 60 * (paramInt1 - paramInt2) / i;
/*     */   }
/*     */   
/*     */   int hsv2rgb(int paramInt1, int paramInt2, int paramInt3) {
/* 107 */     int i = paramInt1 % 360;
/* 108 */     if (i < 0) i += 360;
/* 109 */     int j = i / 60;
/* 110 */     int k = i % 60;
/* 111 */     int m = (1000 - paramInt2) * paramInt3 / 3922;
/* 112 */     int n = (1000 - paramInt2 * k / 60) * paramInt3 / 3922;
/* 113 */     int i1 = (1000 - paramInt2 * (60 - k) / 60) * paramInt3 / 3922;
/* 114 */     int i2 = paramInt3 * 1000 / 3922;
/*     */     
/* 116 */     switch (j) {
/* 117 */     case 0:  return i2 << 16 | i1 << 8 | m;
/* 118 */     case 1:  return n << 16 | i2 << 8 | m;
/* 119 */     case 2:  return m << 16 | i2 << 8 | i1;
/* 120 */     case 3:  return m << 16 | n << 8 | i2;
/* 121 */     case 4:  return i1 << 16 | m << 8 | i2;
/* 122 */     case 5:  return i2 << 16 | m << 8 | n;
/*     */     }
/* 124 */     return 0;
/*     */   }
/*     */   
/*     */   void applyFisheye(double paramDouble) {
/* 128 */     BufferedImage localBufferedImage1 = this.filteredImage;
/* 129 */     BufferedImage localBufferedImage2 = makeOutputImage(localBufferedImage1);
/* 130 */     int i = localBufferedImage1.getWidth();
/* 131 */     int j = localBufferedImage1.getHeight();
/* 132 */     double d1 = i / 2;
/* 133 */     double d2 = j / 2;
/* 134 */     double d3 = (paramDouble + 100.0D) / 100.0D;
/*     */     
/*     */ 
/* 137 */     for (int k = 0; k < i; k++) {
/* 138 */       for (int m = 0; m < j; m++) {
/* 139 */         double d4 = (k - d1) / d1;
/* 140 */         double d5 = (m - d2) / d2;
/* 141 */         double d6 = Math.pow(Math.sqrt(d4 * d4 + d5 * d5), d3);
/* 142 */         double d8; double d9; if (d6 <= 1.0D) {
/* 143 */           double d7 = Math.atan2(d5, d4);
/* 144 */           d8 = d1 + d6 * Math.cos(d7) * d1;
/* 145 */           d9 = d2 + d6 * Math.sin(d7) * d2;
/*     */         } else {
/* 147 */           d8 = k;
/* 148 */           d9 = m;
/*     */         }
/* 150 */         localBufferedImage2.setRGB(k, m, interpolate(localBufferedImage1, d8, d9));
/*     */       }
/*     */     }
/* 153 */     this.tempImage = this.filteredImage;
/* 154 */     this.filteredImage = localBufferedImage2;
/*     */   }
/*     */   
/*     */   int interpolate(BufferedImage paramBufferedImage, double paramDouble1, double paramDouble2) {
/* 158 */     int i = (int)Math.round(paramDouble1);
/* 159 */     if (i < 0) i = 0;
/* 160 */     if (i >= paramBufferedImage.getWidth(null)) i = paramBufferedImage.getWidth(null) - 1;
/* 161 */     int j = (int)Math.round(paramDouble2);
/* 162 */     if (j < 0) j = 0;
/* 163 */     if (j >= paramBufferedImage.getHeight(null)) j = paramBufferedImage.getHeight(null) - 1;
/* 164 */     return paramBufferedImage.getRGB(i, j);
/*     */   }
/*     */   
/*     */   void applyWhirl(double paramDouble) {
/* 168 */     BufferedImage localBufferedImage1 = this.filteredImage;
/* 169 */     BufferedImage localBufferedImage2 = makeOutputImage(localBufferedImage1);
/*     */     
/* 171 */     double d14 = Math.toRadians(-paramDouble);
/* 172 */     int i = localBufferedImage1.getWidth();
/* 173 */     int j = localBufferedImage1.getHeight();
/* 174 */     double d15 = i / 2;
/* 175 */     double d16 = j / 2;
/*     */     double d1;
/* 177 */     double d3; double d4; if (d15 < d16) {
/* 178 */       d1 = d15;
/* 179 */       d3 = d16 / d15;
/* 180 */       d4 = 1.0D;
/*     */     } else {
/* 182 */       d1 = d16;
/* 183 */       d3 = 1.0D;
/* 184 */       if (d16 < d15) {
/* 185 */         d4 = d15 / d16;
/*     */       } else {
/* 187 */         d4 = 1.0D;
/*     */       }
/*     */     }
/* 190 */     double d2 = d1 * d1;
/* 191 */     for (int k = 0; k < i; k++) {
/* 192 */       for (int m = 0; m < j; m++) {
/* 193 */         double d5 = d3 * (k - d15);
/* 194 */         double d6 = d4 * (m - d16);
/* 195 */         double d7 = d5 * d5 + d6 * d6;
/* 196 */         if (d7 < d2) {
/* 197 */           double d8 = 1.0D - Math.sqrt(d7) / d1;
/* 198 */           double d9 = d14 * (d8 * d8);
/* 199 */           double d10 = Math.sin(d9);
/* 200 */           double d11 = Math.cos(d9);
/* 201 */           double d12 = (d11 * d5 - d10 * d6) / d3 + d15;
/* 202 */           double d13 = (d10 * d5 + d11 * d6) / d4 + d16;
/* 203 */           localBufferedImage2.setRGB(k, m, localBufferedImage1.getRGB((int)d12, (int)d13));
/*     */         } else {
/* 205 */           localBufferedImage2.setRGB(k, m, localBufferedImage1.getRGB(k, m));
/*     */         }
/*     */       }
/*     */     }
/* 209 */     this.tempImage = this.filteredImage;
/* 210 */     this.filteredImage = localBufferedImage2;
/*     */   }
/*     */   
/*     */   void applyMosaic(double paramDouble) {
/* 214 */     BufferedImage localBufferedImage1 = this.filteredImage;
/* 215 */     int i = (int)(Math.abs(paramDouble) + 10.0D) / 10;
/* 216 */     i = Math.min(i, Math.min(localBufferedImage1.getWidth(null), localBufferedImage1.getHeight(null)) - 1);
/* 217 */     if (i <= 1) { return;
/*     */     }
/*     */     
/* 220 */     java.awt.geom.AffineTransform localAffineTransform = java.awt.geom.AffineTransform.getScaleInstance(1.0D / i, 1.0D / i);
/* 221 */     AffineTransformOp localAffineTransformOp = new AffineTransformOp(localAffineTransform, 1);
/* 222 */     BufferedImage localBufferedImage2 = localAffineTransformOp.filter(localBufferedImage1, null);
/*     */     
/*     */ 
/* 225 */     int j = i * localBufferedImage2.getWidth(null);
/* 226 */     int k = i * localBufferedImage2.getHeight(null);
/* 227 */     BufferedImage localBufferedImage3 = new BufferedImage(j, k, 2);
/* 228 */     localBufferedImage3.getRaster();
/* 229 */     java.awt.Graphics localGraphics = localBufferedImage3.getGraphics();
/* 230 */     int m = localBufferedImage2.getWidth(null);
/* 231 */     int n = localBufferedImage2.getHeight(null);
/* 232 */     for (int i1 = 0; i1 < localBufferedImage3.getHeight(null); i1 += n) {
/* 233 */       for (int i2 = 0; i2 < localBufferedImage3.getWidth(null); i2 += m) {
/* 234 */         localGraphics.drawImage(localBufferedImage2, i2, i1, null);
/*     */       }
/*     */     }
/* 237 */     localGraphics.dispose();
/* 238 */     localBufferedImage2.flush();
/* 239 */     if (this.filteredImage != null) { this.filteredImage.flush();
/*     */     }
/*     */     
/* 242 */     localAffineTransform = java.awt.geom.AffineTransform.getScaleInstance(localBufferedImage1.getWidth(null) / localBufferedImage3.getWidth(null), localBufferedImage1.getHeight(null) / localBufferedImage3.getHeight(null));
/*     */     
/*     */ 
/* 245 */     localAffineTransformOp = new AffineTransformOp(localAffineTransform, 1);
/* 246 */     this.filteredImage = localAffineTransformOp.filter(localBufferedImage3, null);
/* 247 */     localBufferedImage3.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void applyPixelate(double paramDouble)
/*     */   {
/* 254 */     BufferedImage localBufferedImage1 = this.filteredImage;
/* 255 */     double d = (Math.abs(paramDouble) + 10.0D) / 10.0D;
/* 256 */     d = Math.min(d, Math.min(localBufferedImage1.getWidth(null), localBufferedImage1.getHeight(null)));
/* 257 */     if (d <= 1.0D) { return;
/*     */     }
/*     */     
/* 260 */     java.awt.geom.AffineTransform localAffineTransform = java.awt.geom.AffineTransform.getScaleInstance(1.0D / d, 1.0D / d);
/* 261 */     AffineTransformOp localAffineTransformOp = new AffineTransformOp(localAffineTransform, 2);
/* 262 */     BufferedImage localBufferedImage2 = localAffineTransformOp.filter(localBufferedImage1, null);
/*     */     
/*     */ 
/* 265 */     localAffineTransform = java.awt.geom.AffineTransform.getScaleInstance(d, d);
/* 266 */     localAffineTransformOp = new AffineTransformOp(localAffineTransform, 1);
/* 267 */     this.filteredImage = localAffineTransformOp.filter(localBufferedImage2, this.filteredImage);
/* 268 */     localBufferedImage2.flush();
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\ImageFilter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */