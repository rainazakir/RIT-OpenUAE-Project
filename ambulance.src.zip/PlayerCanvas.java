/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.DataLine.Info;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import javax.sound.sampled.TargetDataLine;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PlayerCanvas
/*     */   extends JPanel
/*     */   implements KeyListener, MouseListener, MouseMotionListener
/*     */ {
/*     */   static final String versionString = "v39";
/*     */   static final int width = 482;
/*     */   static final int height = 387;
/*     */   static final int topBarHeight = 26;
/*     */   static final int goButtonX = 418;
/*     */   static final int stopButtonX = 451;
/*     */   static final int buttonY = 4;
/* 490 */   static final Color BLACK = new Color(0, 0, 0);
/* 491 */   static final Color WHITE = new Color(255, 255, 255);
/*     */   
/*     */   static final int soundInputBufSize = 50000;
/*     */   static TargetDataLine soundInputLine;
/* 495 */   byte[] soundInputBuf = new byte[50000];
/* 496 */   int soundLevel = 0;
/*     */   
/* 498 */   boolean overGoButton = false;
/* 499 */   boolean overStopButton = false;
/*     */   
/* 501 */   String message = "";
/* 502 */   boolean isLoading = true;
/* 503 */   double loadingFraction = 0.2D;
/*     */   
/*     */   LContext lc;
/*     */   Sprite stage;
/* 507 */   Object[] sprites = new Object[0];
/*     */   BufferedImage offscreen;
/* 509 */   BufferedImage penTrails; Rectangle invalrect = new Rectangle();
/*     */   int mouseX;
/*     */   int mouseY;
/* 512 */   boolean mouseIsDown = false;
/*     */   int mouseDownX;
/*     */   int mouseDownY;
/*     */   Drawable mouseDragTarget;
/*     */   int mouseDragXOffset;
/*     */   int mouseDragYOffset;
/* 518 */   boolean reportClickOnMouseUp; Vector mouseclicks = new Vector();
/* 519 */   boolean[] keydown = new boolean['Ā'];
/* 520 */   Vector keystrokes = new Vector();
/*     */   
/* 522 */   AskPrompter askPrompt = null;
/* 523 */   String lastAnswer = "";
/*     */   
/*     */   PlayerCanvas() {
/* 526 */     setLayout(null);
/* 527 */     addKeyListener(this);
/* 528 */     addMouseListener(this);
/* 529 */     addMouseMotionListener(this);
/*     */   }
/*     */   
/*     */   public void addNotify() {
/* 533 */     super.addNotify();
/* 534 */     this.offscreen = ((BufferedImage)createImage(482, 387));
/* 535 */     this.offscreen.getRaster();
/* 536 */     Graphics localGraphics = this.offscreen.getGraphics();
/* 537 */     localGraphics.setColor(WHITE);
/* 538 */     localGraphics.fillRect(0, 0, 482, 387);
/* 539 */     localGraphics.dispose();
/*     */     
/* 541 */     repaint();
/*     */   }
/*     */   
/* 544 */   public Dimension getMinimumSize() { return new Dimension(482, 387); }
/* 545 */   public Dimension getPreferredSize() { return new Dimension(482, 387); }
/*     */   
/*     */   public synchronized void paintComponent(Graphics paramGraphics) {
/* 548 */     paramGraphics.drawImage(this.offscreen, 0, 0, 482, 387, this);
/*     */   }
/*     */   
/*     */   void clearall(LContext paramLContext) {
/* 552 */     this.stage = null;
/* 553 */     this.sprites = new Object[0];
/* 554 */     this.askPrompt = null;
/* 555 */     this.lastAnswer = "";
/* 556 */     this.penTrails = null;
/* 557 */     SoundPlayer.stopSoundsForApplet(paramLContext);
/* 558 */     this.soundLevel = 0;
/* 559 */     paramLContext.props = new Hashtable();
/* 560 */     Runtime.getRuntime().gc();
/* 561 */     clearkeys();
/* 562 */     this.mouseclicks = new Vector();
/* 563 */     this.mouseIsDown = false;
/* 564 */     this.mouseDragTarget = null;
/*     */   }
/*     */   
/*     */   void setMessage(String paramString) {
/* 568 */     this.message = paramString;
/* 569 */     redraw_all();
/*     */   }
/*     */   
/*     */   synchronized void inval(Rectangle paramRectangle) {
/* 573 */     if (this.invalrect.isEmpty()) this.invalrect = new Rectangle(paramRectangle); else
/* 574 */       this.invalrect = this.invalrect.union(paramRectangle);
/*     */   }
/*     */   
/* 577 */   void invalAll() { inval(new Rectangle(0, 0, 482, 387)); }
/*     */   
/* 579 */   void redraw_all() { redraw(new Rectangle(0, 0, 482, 387), false); }
/* 580 */   void redraw_invalid() { redraw(this.invalrect, false); }
/*     */   
/*     */   synchronized void redraw(Rectangle paramRectangle, boolean paramBoolean) {
/* 583 */     Graphics localGraphics = this.offscreen.getGraphics();
/* 584 */     localGraphics.setClip(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
/* 585 */     localGraphics.setColor(WHITE);
/* 586 */     localGraphics.fillRect(0, 0, 482, 387);
/* 587 */     if (this.isLoading) {
/* 588 */       drawProgressBar(localGraphics);
/*     */     } else {
/* 590 */       if (this.stage != null) { this.stage.setStageOffset();this.stage.paint(localGraphics); }
/* 591 */       if (this.penTrails != null) localGraphics.drawImage(this.penTrails, 0, 0, 482, 387, null);
/* 592 */       Drawable localDrawable; for (int i = this.sprites.length - 1; i >= 0; i--) {
/* 593 */         localDrawable = (Drawable)this.sprites[i];
/* 594 */         if ((localDrawable.isShowing()) && (paramRectangle.intersects(localDrawable.fullRect()))) localDrawable.paint(localGraphics);
/*     */       }
/* 596 */       for (i = this.sprites.length - 1; i >= 0; i--) {
/* 597 */         localDrawable = (Drawable)this.sprites[i];
/* 598 */         if ((localDrawable.isShowing()) && (paramRectangle.intersects(localDrawable.fullRect()))) localDrawable.paintBubble(localGraphics);
/*     */       }
/* 600 */       if (this.askPrompt != null) this.askPrompt.paint(localGraphics);
/*     */     }
/* 602 */     drawBorder(localGraphics);
/* 603 */     if (paramBoolean) {
/* 604 */       localGraphics.setColor(new Color(200, 0, 0));
/* 605 */       localGraphics.fillRect(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
/*     */     }
/* 607 */     localGraphics.dispose();
/* 608 */     repaint(paramRectangle);
/* 609 */     this.invalrect = new Rectangle();
/*     */   }
/*     */   
/*     */   void drawBorder(Graphics paramGraphics) {
/* 613 */     paramGraphics.setColor(new Color(130, 130, 130));
/* 614 */     paramGraphics.fillRect(0, 0, 482, 25);
/*     */     
/* 616 */     paramGraphics.setColor(BLACK);
/* 617 */     paramGraphics.fillRect(0, 0, 482, 1);
/* 618 */     paramGraphics.fillRect(0, 0, 1, 387);
/* 619 */     paramGraphics.fillRect(0, 386, 482, 1);
/* 620 */     paramGraphics.fillRect(481, 0, 1, 387);
/* 621 */     paramGraphics.fillRect(0, 25, 482, 1);
/*     */     
/* 623 */     paramGraphics.drawImage(this.overGoButton ? Skin.goButtonOver : Skin.goButton, 418, 4, null);
/*     */     
/*     */ 
/* 626 */     paramGraphics.drawImage(this.overStopButton ? Skin.stopButtonOver : Skin.stopButton, 451, 4, null);
/*     */     
/*     */ 
/*     */ 
/* 630 */     paramGraphics.setColor(WHITE);
/* 631 */     paramGraphics.setFont(new Font("SansSerif", 0, 8));
/* 632 */     paramGraphics.drawString("v39", 5, 11);
/* 633 */     if (this.message.length() > 0) {
/* 634 */       paramGraphics.setFont(new Font("SansSerif", 1, 13));
/* 635 */       paramGraphics.setColor(new Color(250, 250, 0));
/* 636 */       paramGraphics.drawString(this.message, 70, 17);
/*     */     }
/*     */   }
/*     */   
/*     */   void drawProgressBar(Graphics paramGraphics) {
/* 641 */     paramGraphics.setColor(BLACK);
/* 642 */     paramGraphics.setFont(new Font("SansSerif", 1, 24));
/* 643 */     paramGraphics.drawString("Loading...", 188, 173);
/*     */     
/* 645 */     int i = 91;
/* 646 */     int j = 193;
/* 647 */     paramGraphics.fillRect(i, j, 300, 1);
/* 648 */     paramGraphics.fillRect(i, j, 1, 29);
/* 649 */     paramGraphics.fillRect(i, j + 28, 300, 1);
/* 650 */     paramGraphics.fillRect(i + 299, j, 1, 29);
/*     */     
/* 652 */     paramGraphics.setColor(new Color(10, 10, 200));
/* 653 */     paramGraphics.fillRect(i + 2, j + 2, (int)(296.0D * Math.min(this.loadingFraction, 1.0D)), 25);
/*     */     
/* 655 */     drawBorder(paramGraphics);
/*     */   }
/*     */   
/*     */   BufferedImage drawAreaWithoutSprite(Rectangle paramRectangle, Sprite paramSprite) {
/* 659 */     BufferedImage localBufferedImage = new BufferedImage(paramRectangle.width, paramRectangle.height, 2);
/* 660 */     Graphics localGraphics = localBufferedImage.getGraphics();
/* 661 */     localGraphics.setColor(new Color(0, 0, 0, 0));
/* 662 */     localGraphics.fillRect(0, 0, paramRectangle.width, paramRectangle.height);
/* 663 */     localGraphics = localGraphics.create(-paramRectangle.x, -paramRectangle.y, paramRectangle.width, paramRectangle.height);
/* 664 */     localGraphics.setClip(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
/* 665 */     if (this.stage != null) { this.stage.setStageOffset();this.stage.paint(localGraphics); }
/* 666 */     if (this.penTrails != null) localGraphics.drawImage(this.penTrails, 0, 0, 482, 387, null);
/* 667 */     for (int i = this.sprites.length - 1; i >= 0; i--) {
/* 668 */       Drawable localDrawable = (Drawable)this.sprites[i];
/* 669 */       if ((localDrawable != paramSprite) && (localDrawable.isShowing()) && (paramRectangle.intersects(localDrawable.rect()))) localDrawable.paint(localGraphics);
/*     */     }
/* 671 */     localGraphics.dispose();
/* 672 */     return localBufferedImage;
/*     */   }
/*     */   
/*     */   void drawRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 676 */     Graphics localGraphics = this.offscreen.getGraphics();
/* 677 */     localGraphics.setColor(BLACK);
/* 678 */     localGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 679 */     localGraphics.dispose();
/* 680 */     repaint();
/*     */   }
/*     */   
/*     */   void startLoading() {
/* 684 */     this.isLoading = true;
/* 685 */     this.loadingFraction = 0.0D;
/* 686 */     redraw_all();
/*     */   }
/*     */   
/*     */   void stopLoading() {
/* 690 */     this.loadingFraction = 1.0D;
/* 691 */     redraw_all();
/* 692 */     this.loadingFraction = 0.0D;
/* 693 */     this.isLoading = false;
/*     */   }
/*     */   
/*     */   void loadingProgress(double paramDouble) {
/* 697 */     this.loadingFraction = paramDouble;
/* 698 */     redraw_all();
/*     */   }
/*     */   
/*     */   boolean logoIsRunning() {
/* 702 */     return this.lc.logoThread != null;
/*     */   }
/*     */   
/*     */   void updatePenTrails() {
/* 706 */     for (int i = this.sprites.length - 1; i >= 0; i--) {
/* 707 */       if ((this.sprites[i] instanceof Sprite)) {
/* 708 */         Sprite localSprite = (Sprite)this.sprites[i];
/* 709 */         if (localSprite.penDown) updatePenTrailForSprite(localSprite);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void updatePenTrailForSprite(Sprite paramSprite) {
/* 715 */     if (this.penTrails == null) createPenTrails();
/* 716 */     int i = 241 + (int)paramSprite.x;
/* 717 */     int j = 206 - (int)paramSprite.y;
/* 718 */     if (paramSprite.lastPenX == -1000000.0D) {
/* 719 */       paramSprite.lastPenX = i;
/* 720 */       paramSprite.lastPenY = j;
/*     */     }
/* 722 */     else if ((paramSprite.lastPenX == i) && (paramSprite.lastPenY == j)) { return;
/*     */     }
/* 724 */     Graphics2D localGraphics2D = this.penTrails.createGraphics();
/* 725 */     localGraphics2D.setColor(paramSprite.penColor);
/* 726 */     localGraphics2D.setStroke(new BasicStroke(paramSprite.penSize, 1, 1));
/* 727 */     localGraphics2D.drawLine(paramSprite.lastPenX, paramSprite.lastPenY, i, j);
/* 728 */     localGraphics2D.dispose();
/*     */     
/* 730 */     Rectangle localRectangle = new Rectangle(paramSprite.lastPenX, paramSprite.lastPenY, 0, 0);
/* 731 */     localRectangle.add(i, j);
/* 732 */     localRectangle.grow(paramSprite.penSize, paramSprite.penSize);
/* 733 */     inval(localRectangle);
/*     */     
/* 735 */     paramSprite.lastPenX = i;
/* 736 */     paramSprite.lastPenY = j;
/*     */   }
/*     */   
/*     */   void stampCostume(Sprite paramSprite) {
/* 740 */     if (this.penTrails == null) createPenTrails();
/* 741 */     Graphics2D localGraphics2D = this.penTrails.createGraphics();
/* 742 */     if (paramSprite.filterChanged) paramSprite.applyFilters();
/* 743 */     localGraphics2D.drawImage(paramSprite.outImage(), paramSprite.screenX(), paramSprite.screenY(), null);
/* 744 */     localGraphics2D.dispose();
/* 745 */     paramSprite.inval();
/*     */   }
/*     */   
/*     */   void createPenTrails() {
/* 749 */     this.penTrails = new BufferedImage(482, 387, 2);
/* 750 */     this.penTrails.getRaster();
/*     */   }
/*     */   
/*     */   void clearPenTrails() {
/* 754 */     if (this.penTrails != null) this.penTrails.flush();
/* 755 */     this.penTrails = null;
/* 756 */     inval(new Rectangle(0, 0, 482, 387));
/*     */   }
/*     */   
/* 759 */   public void mouseEntered(MouseEvent paramMouseEvent) { requestFocus();mouseDragOrMove(paramMouseEvent); }
/* 760 */   public void mouseExited(MouseEvent paramMouseEvent) { updateMouseXY(paramMouseEvent); }
/* 761 */   public void mousePressed(MouseEvent paramMouseEvent) { mouseDown(paramMouseEvent); }
/* 762 */   public void mouseReleased(MouseEvent paramMouseEvent) { mouseUp(paramMouseEvent); }
/* 763 */   public void mouseClicked(MouseEvent paramMouseEvent) { updateMouseXY(paramMouseEvent); }
/* 764 */   public void mouseDragged(MouseEvent paramMouseEvent) { mouseDragOrMove(paramMouseEvent); }
/* 765 */   public void mouseMoved(MouseEvent paramMouseEvent) { mouseDragOrMove(paramMouseEvent); }
/*     */   
/*     */   void mouseDown(MouseEvent paramMouseEvent) {
/* 768 */     updateMouseXY(paramMouseEvent);
/* 769 */     requestFocus();
/* 770 */     if (inGoButton(paramMouseEvent)) {
/* 771 */       doStopButton();
/* 772 */       LogoCommandRunner.startLogoThread("greenflag", this.lc);
/* 773 */       return;
/*     */     }
/* 775 */     if (inStopButton(paramMouseEvent)) {
/* 776 */       doStopButton();
/* 777 */       LogoCommandRunner.startLogoThread("interact", this.lc);
/* 778 */       return;
/*     */     }
/* 780 */     this.mouseIsDown = true;
/* 781 */     this.mouseDownX = paramMouseEvent.getX();
/* 782 */     this.mouseDownY = paramMouseEvent.getY();
/* 783 */     this.mouseDragTarget = findDragTarget(paramMouseEvent.getX(), paramMouseEvent.getY());
/* 784 */     this.mouseDragXOffset = (this.mouseDragYOffset = 0);
/* 785 */     this.reportClickOnMouseUp = true;
/* 786 */     Object localObject; if ((this.mouseDragTarget instanceof Sprite)) {
/* 787 */       localObject = (Sprite)this.mouseDragTarget;
/* 788 */       if (((Sprite)localObject).isDraggable) {
/* 789 */         this.mouseDragXOffset = (((Sprite)localObject).screenX() - paramMouseEvent.getX());
/* 790 */         this.mouseDragYOffset = (((Sprite)localObject).screenY() - paramMouseEvent.getY());
/* 791 */         moveSpriteToFront((Sprite)localObject);
/*     */       } else {
/* 793 */         this.mouseDragTarget = null;
/*     */       }
/*     */     }
/* 796 */     if ((this.mouseDragTarget instanceof ListWatcher)) {
/* 797 */       localObject = (ListWatcher)this.mouseDragTarget;
/* 798 */       ((ListWatcher)localObject).mouseDown(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */     }
/* 800 */     if (this.askPrompt != null) {
/* 801 */       boolean bool = this.askPrompt.mouseDown(paramMouseEvent.getX(), paramMouseEvent.getY(), this);
/* 802 */       if (bool) return;
/*     */     }
/* 804 */     if (this.mouseDragTarget == null) {
/* 805 */       reportClick();
/*     */     }
/*     */   }
/*     */   
/*     */   void mouseDragOrMove(MouseEvent paramMouseEvent) {
/* 810 */     updateMouseXY(paramMouseEvent);
/* 811 */     if ((paramMouseEvent.getX() != this.mouseDownX) || (paramMouseEvent.getY() != this.mouseDownY)) {
/* 812 */       this.reportClickOnMouseUp = false;
/*     */     }
/* 814 */     if (this.mouseDragTarget != null) {
/* 815 */       this.mouseDragTarget.dragTo(paramMouseEvent.getX() + this.mouseDragXOffset, paramMouseEvent.getY() + this.mouseDragYOffset);
/*     */     } else {
/* 817 */       boolean bool1 = this.overGoButton;
/* 818 */       boolean bool2 = this.overStopButton;
/* 819 */       this.overGoButton = inGoButton(paramMouseEvent);
/* 820 */       this.overStopButton = inStopButton(paramMouseEvent);
/* 821 */       if ((bool1 != this.overGoButton) || (bool2 != this.overStopButton)) {
/* 822 */         inval(new Rectangle(0, 0, 482, 26));
/* 823 */         redraw_invalid();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void mouseUp(MouseEvent paramMouseEvent) {
/* 829 */     updateMouseXY(paramMouseEvent);
/* 830 */     if (this.reportClickOnMouseUp) {
/* 831 */       if ((this.mouseDragTarget instanceof Watcher)) {
/* 832 */         ((Watcher)this.mouseDragTarget).click(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */       } else {
/* 834 */         reportClick();
/*     */       }
/*     */     }
/* 837 */     this.mouseDragTarget = null;
/* 838 */     this.mouseIsDown = false;
/*     */   }
/*     */   
/*     */   void reportClick() {
/* 842 */     Object[] arrayOfObject = new Object[2];
/* 843 */     arrayOfObject[0] = new Double(this.mouseDownX - 241);
/* 844 */     arrayOfObject[1] = new Double(206 - this.mouseDownY);
/* 845 */     this.mouseclicks.addElement(arrayOfObject);
/* 846 */     this.reportClickOnMouseUp = false;
/*     */   }
/*     */   
/*     */   void updateMouseXY(MouseEvent paramMouseEvent) {
/* 850 */     this.mouseX = (paramMouseEvent.getX() - 241);
/* 851 */     this.mouseY = (206 - paramMouseEvent.getY());
/*     */   }
/*     */   
/*     */   boolean inGoButton(MouseEvent paramMouseEvent) {
/* 855 */     if (paramMouseEvent.getY() >= 26) return false;
/* 856 */     int i = paramMouseEvent.getX();
/* 857 */     return (i >= 418) && (i <= 418 + Skin.goButton.getWidth(null));
/*     */   }
/*     */   
/*     */   boolean inStopButton(MouseEvent paramMouseEvent) {
/* 861 */     if (paramMouseEvent.getY() >= 26) return false;
/* 862 */     int i = paramMouseEvent.getX();
/* 863 */     return (i >= 451) && (i <= 451 + Skin.stopButton.getWidth(null));
/*     */   }
/*     */   
/*     */   void doStopButton() {
/* 867 */     SoundPlayer.stopSoundsForApplet(this.lc);
/* 868 */     LogoCommandRunner.stopLogoThread(this.lc);
/* 869 */     new LogoCommandRunner("stopAll", this.lc, true).run();
/* 870 */     clearkeys();
/* 871 */     this.mouseclicks = new Vector();
/* 872 */     this.mouseIsDown = false;
/* 873 */     this.mouseDragTarget = null;
/* 874 */     redraw_all();
/*     */   }
/*     */   
/*     */   Drawable findDragTarget(int paramInt1, int paramInt2) {
/* 878 */     for (int i = 0; i < this.sprites.length; i++) { Object localObject;
/* 879 */       if ((this.sprites[i] instanceof Watcher)) {
/* 880 */         localObject = (Watcher)this.sprites[i];
/* 881 */         if (((Watcher)localObject).inSlider(paramInt1, paramInt2)) return (Drawable)localObject;
/*     */       }
/* 883 */       if ((this.sprites[i] instanceof ListWatcher)) {
/* 884 */         localObject = (ListWatcher)this.sprites[i];
/* 885 */         if (((ListWatcher)localObject).inScrollbar(paramInt1, paramInt2)) return (Drawable)localObject;
/*     */       }
/* 887 */       if ((this.sprites[i] instanceof Sprite)) {
/* 888 */         localObject = (Sprite)this.sprites[i];
/* 889 */         if ((((Sprite)localObject).isShowing()) && (((Sprite)localObject).containsPoint(paramInt1, paramInt2))) return (Drawable)localObject;
/*     */       }
/*     */     }
/* 892 */     return null;
/*     */   }
/*     */   
/*     */   void moveSpriteToFront(Sprite paramSprite) {
/* 896 */     int i = -1;
/* 897 */     for (int j = 0; j < this.sprites.length; j++) {
/* 898 */       if (this.sprites[j] == paramSprite) i = j;
/*     */     }
/* 900 */     if (i < 0) return;
/* 901 */     Object localObject = this.sprites[i];
/* 902 */     for (int k = i; k > 0; k--) this.sprites[k] = this.sprites[(k - 1)];
/* 903 */     this.sprites[0] = localObject;
/* 904 */     paramSprite.inval();
/*     */   }
/*     */   
/*     */   public void keyPressed(KeyEvent paramKeyEvent) {
/* 908 */     int i = keyCodeFor(paramKeyEvent);
/* 909 */     this.keydown[i] = true;
/* 910 */     if ((i == 10) || ((i >= 28) && (i <= 31))) this.keystrokes.addElement(new Double(i));
/*     */   }
/*     */   
/*     */   public void keyReleased(KeyEvent paramKeyEvent) {
/* 914 */     int i = keyCodeFor(paramKeyEvent);
/* 915 */     this.keydown[i] = false;
/*     */   }
/*     */   
/*     */   public void keyTyped(KeyEvent paramKeyEvent) {
/* 919 */     int i = paramKeyEvent.getKeyChar();
/*     */     
/* 921 */     if (this.askPrompt != null) {
/* 922 */       this.askPrompt.handleKeystroke(i, this);
/* 923 */       return;
/*     */     }
/*     */     
/* 926 */     if ((i >= 65) && (i <= 90)) i += 32;
/* 927 */     this.keystrokes.addElement(new Double(i));
/*     */   }
/*     */   
/*     */   int keyCodeFor(KeyEvent paramKeyEvent) {
/* 931 */     int i = paramKeyEvent.getKeyCode();
/* 932 */     if (i == 10) return 10;
/* 933 */     if (i == 37) return 28;
/* 934 */     if (i == 38) return 30;
/* 935 */     if (i == 39) return 29;
/* 936 */     if (i == 40) return 31;
/* 937 */     if ((i >= 65) && (i <= 90)) return i + 32;
/* 938 */     return Math.min(i, 255);
/*     */   }
/*     */   
/*     */   void clearkeys() {
/* 942 */     for (int i = 0; i < this.keydown.length; i++) this.keydown[i] = false;
/* 943 */     this.keystrokes = new Vector();
/*     */   }
/*     */   
/*     */   int soundLevel() {
/* 947 */     if (soundInputLine == null) { return 0;
/*     */     }
/* 949 */     int i = soundInputLine.available();
/* 950 */     if (i == 0) return this.soundLevel;
/* 951 */     i = soundInputLine.read(this.soundInputBuf, 0, i);
/*     */     
/* 953 */     int j = 0;
/* 954 */     for (int k = 0; k < i / 2; k++) {
/* 955 */       int m = (this.soundInputBuf[(2 * k)] << 8) + this.soundInputBuf[(2 * k + 1)];
/* 956 */       if (m >= 32768) m = 65536 - m;
/* 957 */       if (m > j) j = m;
/*     */     }
/* 959 */     this.soundLevel = (j / 327);
/* 960 */     return this.soundLevel;
/*     */   }
/*     */   
/*     */   void openSoundInput() {
/* 964 */     if (soundInputLine != null) soundInputLine.close();
/* 965 */     AudioFormat localAudioFormat = new AudioFormat(44100.0F, 16, 1, true, true);
/* 966 */     DataLine.Info localInfo = new DataLine.Info(TargetDataLine.class, localAudioFormat);
/*     */     try {
/* 968 */       soundInputLine = (TargetDataLine)AudioSystem.getLine(localInfo);
/* 969 */       soundInputLine.open(localAudioFormat, 50000);
/* 970 */       soundInputLine.start();
/*     */     } catch (LineUnavailableException localLineUnavailableException) {
/* 972 */       soundInputLine = null;
/*     */     }
/*     */   }
/*     */   
/*     */   void showAskPrompt(String paramString) {
/* 977 */     this.askPrompt = new AskPrompter(paramString);
/* 978 */     invalAll();
/*     */   }
/*     */   
/*     */   void hideAskPrompt() {
/* 982 */     if (this.askPrompt != null) this.lastAnswer = this.askPrompt.answerString;
/* 983 */     this.askPrompt = null;
/* 984 */     invalAll();
/*     */   }
/*     */   
/*     */   boolean askPromptShowing() {
/* 988 */     return this.askPrompt != null;
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\PlayerCanvas.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */