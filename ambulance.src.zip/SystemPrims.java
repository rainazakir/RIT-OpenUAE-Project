/*     */ import java.util.Vector;
/*     */ 
/*     */ class SystemPrims extends Primitives
/*     */ {
/*   5 */   static String[] primlist = { "resett", "0", "%timer", "0", "wait", "1", "mwait", "1", "eq", "2", "(", "0", ")", "0", "true", "0", "false", "0", "hexw", "2", "tab", "0", "classof", "1", "class", "1", "string", "1", "print", "1", "prs", "1", "ignore", "1" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  25 */   public String[] primlist() { return primlist; }
/*     */   
/*     */   public Object dispatch(int paramInt, Object[] paramArrayOfObject, LContext paramLContext) {
/*  28 */     switch (paramInt) {
/*  29 */     case 0:  return prim_resett(paramLContext);
/*  30 */     case 1:  return prim_timer(paramLContext);
/*  31 */     case 2:  return prim_wait(paramArrayOfObject[0], paramLContext);
/*  32 */     case 3:  return prim_mwait(paramArrayOfObject[0], paramLContext);
/*  33 */     case 4:  return prim_eq(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  34 */     case 5:  return prim_parleft(paramLContext);
/*  35 */     case 6:  return prim_parright(paramLContext);
/*  36 */     case 7:  return new Boolean(true);
/*  37 */     case 8:  return new Boolean(false);
/*  38 */     case 9:  return prim_hexw(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  39 */     case 10:  return "\t";
/*  40 */     case 11:  return paramArrayOfObject[0].getClass();
/*  41 */     case 12:  return prim_class(paramArrayOfObject[0], paramLContext);
/*  42 */     case 13:  return prstring(paramArrayOfObject[0]);
/*  43 */     case 14:  paramLContext.tyo.println(Logo.prs(paramArrayOfObject[0]));return null;
/*  44 */     case 15:  paramLContext.tyo.print(Logo.prs(paramArrayOfObject[0]));return null;
/*  45 */     case 16:  return null;
/*     */     }
/*  47 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_resett(LContext paramLContext) {
/*  51 */     Logo.starttime = System.currentTimeMillis();
/*  52 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_timer(LContext paramLContext) {
/*  56 */     return new Double(System.currentTimeMillis() - Logo.starttime);
/*     */   }
/*     */   
/*     */   Object prim_wait(Object paramObject, LContext paramLContext) {
/*  60 */     int i = (int)(100.0D * Logo.aDouble(paramObject, paramLContext));
/*  61 */     sleepForMSecs(i, paramLContext);
/*  62 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_mwait(Object paramObject, LContext paramLContext) {
/*  66 */     int i = Logo.anInt(paramObject, paramLContext);
/*  67 */     sleepForMSecs(i, paramLContext);
/*  68 */     return null;
/*     */   }
/*     */   
/*     */   void sleepForMSecs(int paramInt, LContext paramLContext) {
/*  72 */     if (paramInt <= 0) return;
/*  73 */     long l1 = System.currentTimeMillis();
/*  74 */     long l2 = System.currentTimeMillis() - l1;
/*  75 */     while ((l2 >= 0L) && (l2 < paramInt)) {
/*  76 */       if (paramLContext.timeToStop) Logo.error("Stopped!!!", paramLContext);
/*  77 */       try { Thread.sleep(Math.min(paramInt - l2, 10L)); } catch (InterruptedException localInterruptedException) {}
/*  78 */       l2 = System.currentTimeMillis() - l1;
/*     */     }
/*     */   }
/*     */   
/*     */   Object prim_eq(Object paramObject1, Object paramObject2, LContext paramLContext) {
/*  83 */     return new Boolean(paramObject1.equals(paramObject2));
/*     */   }
/*     */   
/*     */   Object prim_parright(LContext paramLContext) {
/*  87 */     Logo.error("Missing \"(\"", paramLContext);
/*  88 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_parleft(LContext paramLContext) {
/*  92 */     if (ipmnext(paramLContext.iline)) return ipmcall(paramLContext);
/*  93 */     Object localObject1 = Logo.eval(paramLContext);Object localObject2 = paramLContext.iline.next();
/*  94 */     if (((localObject2 instanceof Symbol)) && (((Symbol)localObject2).pname.equals(")")))
/*     */     {
/*  96 */       return localObject1; }
/*  97 */     Logo.error("Missing \")\"", paramLContext);
/*  98 */     return null;
/*     */   }
/*     */   
/*     */   boolean ipmnext(MapList paramMapList) {
/* 102 */     try { return ((Symbol)paramMapList.peek()).fcn.ipm; } catch (Exception localException) {}
/* 103 */     return false;
/*     */   }
/*     */   
/*     */   Object ipmcall(LContext paramLContext) {
/* 107 */     Vector localVector = new Vector();
/* 108 */     paramLContext.cfun = ((Symbol)paramLContext.iline.next());
/* 109 */     while (!finIpm(paramLContext.iline))
/* 110 */       localVector.addElement(Logo.evalOneArg(paramLContext.iline, paramLContext));
/* 111 */     Object[] arrayOfObject = new Object[localVector.size()];
/* 112 */     localVector.copyInto(arrayOfObject);
/* 113 */     return Logo.evalSym(paramLContext.cfun, arrayOfObject, paramLContext);
/*     */   }
/*     */   
/*     */   boolean finIpm(MapList paramMapList) {
/* 117 */     if (paramMapList.eof()) return true;
/* 118 */     Object localObject = paramMapList.peek();
/* 119 */     if (((localObject instanceof Symbol)) && (((Symbol)localObject).pname.equals(")"))) {
/* 120 */       paramMapList.next();
/* 121 */       return true;
/*     */     }
/* 123 */     return false;
/*     */   }
/*     */   
/*     */   Object prim_hexw(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 127 */     Logo.anInt(paramObject1, paramLContext);
/* 128 */     String str1 = Logo.prs(paramObject1, 16);
/* 129 */     int i = Logo.anInt(paramObject2, paramLContext);
/* 130 */     String str2 = "00000000".substring(8 - i + str1.length());
/* 131 */     return str2 + str1;
/*     */   }
/*     */   
/* 134 */   Object prim_class(Object paramObject, LContext paramLContext) { try { return Class.forName(Logo.prs(paramObject));
/*     */     }
/*     */     catch (Exception localException) {}catch (Error localError) {}
/* 137 */     return "";
/*     */   }
/*     */   
/*     */   String prstring(Object paramObject) {
/* 141 */     if (((paramObject instanceof Number)) && (Logo.isInt((Number)paramObject))) {
/* 142 */       return Long.toString(((Number)paramObject).longValue(), 10);
/*     */     }
/* 144 */     if ((paramObject instanceof String)) return "|" + (String)paramObject + "|";
/* 145 */     if ((paramObject instanceof Object[])) {
/* 146 */       String str = "";
/* 147 */       Object[] arrayOfObject = (Object[])paramObject;
/* 148 */       for (int i = 0; i < arrayOfObject.length; i++) {
/* 149 */         if ((arrayOfObject[i] instanceof Object[])) str = str + "[";
/* 150 */         str = str + prstring(arrayOfObject[i]);
/* 151 */         if ((arrayOfObject[i] instanceof Object[])) str = str + "]";
/* 152 */         if (i != arrayOfObject.length - 1) str = str + " ";
/*     */       }
/* 154 */       return str;
/*     */     }
/* 156 */     return paramObject.toString();
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\SystemPrims.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */