/*     */ import java.awt.Canvas;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.MediaTracker;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.awt.image.MemoryImageSource;
/*     */ import java.awt.image.PixelGrabber;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ObjReader
/*     */ {
/*     */   DataInputStream s;
/*     */   Object[][] objTable;
/*     */   static final int ObjectRefID = 99;
/*  44 */   static final Object[] empty = new Object[0];
/*  45 */   static final Canvas canvas = new Canvas();
/*     */   
/*     */   ObjReader(InputStream paramInputStream) {
/*  48 */     this.s = new DataInputStream(paramInputStream);
/*     */   }
/*     */   
/*     */   Object[][] readObjects(LContext paramLContext) throws IOException
/*     */   {
/*  53 */     readInfo();
/*  54 */     readObjTable(paramLContext);
/*  55 */     return this.objTable;
/*     */   }
/*     */   
/*     */   Hashtable readInfo() throws IOException
/*     */   {
/*  60 */     byte[] arrayOfByte = new byte[10];
/*  61 */     this.s.read(arrayOfByte);
/*  62 */     if ((!"ScratchV01".equals(new String(arrayOfByte))) && (!"ScratchV02".equals(new String(arrayOfByte)))) {
/*  63 */       throw new IOException();
/*     */     }
/*     */     
/*  66 */     int i = this.s.readInt();
/*  67 */     readObjTable(null);
/*     */     
/*  69 */     Object[] arrayOfObject = (Object[])this.objTable[0][0];
/*  70 */     Hashtable localHashtable = new Hashtable(arrayOfObject.length);
/*  71 */     for (int j = 0; j < arrayOfObject.length - 1; j += 2) {
/*  72 */       localHashtable.put(arrayOfObject[j], arrayOfObject[(j + 1)]);
/*     */     }
/*  74 */     return localHashtable;
/*     */   }
/*     */   
/*     */   void readObjTable(LContext paramLContext) throws IOException {
/*  78 */     byte[] arrayOfByte = new byte[4];
/*     */     
/*     */ 
/*  81 */     this.s.read(arrayOfByte);
/*  82 */     if ((!"ObjS".equals(new String(arrayOfByte))) || (this.s.readByte() != 1)) throw new IOException();
/*  83 */     this.s.read(arrayOfByte);
/*  84 */     if ((!"Stch".equals(new String(arrayOfByte))) || (this.s.readByte() != 1)) { throw new IOException();
/*     */     }
/*  86 */     int i = this.s.readInt();
/*     */     
/*  88 */     this.objTable = new Object[i][];
/*  89 */     for (int j = 0; j < i; j++) {
/*  90 */       this.objTable[j] = readObj();
/*     */     }
/*  92 */     createSpritesAndWatchers(paramLContext);
/*  93 */     buildImagesAndSounds();
/*  94 */     fixSounds();
/*  95 */     resolveReferences();
/*  96 */     uncompressMedia();
/*     */   }
/*     */   
/*     */   Object[] readObj()
/*     */     throws IOException
/*     */   {
/* 102 */     int i = this.s.readUnsignedByte();
/* 103 */     Object[] arrayOfObject; if (i < 99) {
/* 104 */       arrayOfObject = new Object[2];
/* 105 */       arrayOfObject[0] = readFixedFormat(i);
/* 106 */       arrayOfObject[1] = new Integer(i);
/*     */     } else {
/* 108 */       int j = this.s.readUnsignedByte();
/* 109 */       int k = this.s.readUnsignedByte();
/* 110 */       arrayOfObject = new Object[3 + k];
/* 111 */       arrayOfObject[0] = empty;
/* 112 */       arrayOfObject[1] = new Integer(i);
/* 113 */       arrayOfObject[2] = new Integer(j);
/* 114 */       for (int m = 3; m < arrayOfObject.length; m++) arrayOfObject[m] = readField();
/*     */     }
/* 116 */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   Object readField() throws IOException {
/* 120 */     int i = this.s.readUnsignedByte();
/* 121 */     if (i == 99) {
/* 122 */       int j = this.s.readUnsignedByte() << 16;
/* 123 */       j += (this.s.readUnsignedByte() << 8);
/* 124 */       j += this.s.readUnsignedByte();
/* 125 */       return new Ref(j);
/*     */     }
/* 127 */     return readFixedFormat(i);
/*     */   }
/*     */   
/*     */ 
/* 131 */   static final byte[] macRomanToISOLatin = { -60, -59, -57, -55, -47, -42, -36, -31, -32, -30, -28, -29, -27, -25, -23, -24, -22, -21, -19, -20, -18, -17, -15, -13, -14, -12, -10, -11, -6, -7, -5, -4, -122, -80, -94, -93, -89, -107, -74, -33, -82, -87, -103, -76, -88, Byte.MIN_VALUE, -58, -40, -127, -79, -118, -115, -91, -75, -114, -113, -112, -102, -99, -86, -70, -98, -26, -8, -65, -95, -84, -90, -125, -83, -78, -85, -69, -123, -96, -64, -61, -43, -116, -100, -106, -105, -109, -108, -111, -110, -9, -77, -1, -97, -71, -92, -117, -101, -68, -67, -121, -73, -126, -124, -119, -62, -54, -63, -53, -56, -51, -50, -49, -52, -45, -44, -66, -46, -38, -37, -39, -48, -120, -104, -81, -41, -35, -34, -72, -16, -3, -2 };
/*     */   
/*     */ 
/*     */   Object readFixedFormat(int paramInt)
/*     */     throws IOException
/*     */   {
/*     */     int i;
/*     */     
/*     */     int j;
/*     */     
/*     */     int k;
/*     */     
/*     */     byte[] arrayOfByte;
/*     */     Object[] arrayOfObject1;
/*     */     int m;
/* 146 */     switch (paramInt) {
/* 147 */     case 1:  return empty;
/* 148 */     case 2:  return Boolean.TRUE;
/* 149 */     case 3:  return Boolean.FALSE;
/* 150 */     case 4:  return new Integer(this.s.readInt());
/* 151 */     case 5:  return new Integer(this.s.readShort());
/*     */     case 6: 
/*     */     case 7: 
/* 154 */       double d1 = 0.0D;
/* 155 */       double d2 = 1.0D;
/* 156 */       i = this.s.readShort();
/* 157 */       for (j = 0; j < i; j++) {
/* 158 */         k = this.s.readUnsignedByte();
/* 159 */         d1 += d2 * k;
/* 160 */         d2 *= 256.0D;
/*     */       }
/* 162 */       if (paramInt == 7) d1 = -d1;
/* 163 */       return new Double(d1);
/*     */     case 8: 
/* 165 */       return new Double(this.s.readDouble());
/*     */     case 9: 
/*     */     case 10: 
/* 168 */       i = this.s.readInt();
/* 169 */       this.s.read(arrayOfByte = new byte[i]);
/* 170 */       for (j = 0; j < i; j++) {
/* 171 */         if (arrayOfByte[j] < 0) arrayOfByte[j] = macRomanToISOLatin[(arrayOfByte[j] + 128)];
/*     */       }
/*     */       try {
/* 174 */         return new String(arrayOfByte, "ISO-8859-1");
/*     */       } catch (UnsupportedEncodingException localUnsupportedEncodingException1) {
/* 176 */         return new String(arrayOfByte);
/*     */       }
/*     */     case 11: 
/* 179 */       i = this.s.readInt();
/* 180 */       this.s.read(arrayOfByte = new byte[i]);
/* 181 */       return arrayOfByte;
/*     */     case 12: 
/* 183 */       i = this.s.readInt();
/* 184 */       this.s.read(arrayOfByte = new byte[2 * i]);
/* 185 */       return arrayOfByte;
/*     */     case 13: 
/* 187 */       i = this.s.readInt();
/* 188 */       int[] arrayOfInt = new int[i];
/* 189 */       for (k = 0; k < arrayOfInt.length; k++) arrayOfInt[k] = this.s.readInt();
/* 190 */       return arrayOfInt;
/*     */     case 14: 
/* 192 */       i = this.s.readInt();
/* 193 */       this.s.read(arrayOfByte = new byte[i]);
/*     */       try {
/* 195 */         return new String(arrayOfByte, "UTF-8");
/*     */       } catch (UnsupportedEncodingException localUnsupportedEncodingException2) {
/* 197 */         return new String(arrayOfByte);
/*     */       }
/*     */     case 20: 
/*     */     case 21: 
/*     */     case 22: 
/*     */     case 23: 
/* 203 */       i = this.s.readInt();
/* 204 */       arrayOfObject1 = new Object[i];
/* 205 */       for (m = 0; m < arrayOfObject1.length; m++) arrayOfObject1[m] = readField();
/* 206 */       return arrayOfObject1;
/*     */     case 24: 
/*     */     case 25: 
/* 209 */       i = this.s.readInt();
/* 210 */       arrayOfObject1 = new Object[2 * i];
/* 211 */       for (m = 0; m < arrayOfObject1.length; m++) arrayOfObject1[m] = readField();
/* 212 */       return arrayOfObject1;
/*     */     case 30: 
/*     */     case 31: 
/* 215 */       m = this.s.readInt();
/* 216 */       int n = 255;
/* 217 */       if (paramInt == 31) n = this.s.readUnsignedByte();
/* 218 */       return new Color(m >> 22 & 0xFF, m >> 12 & 0xFF, m >> 2 & 0xFF, n);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     case 32: 
/* 224 */       arrayOfObject1 = new Object[2];
/* 225 */       arrayOfObject1[0] = readField();
/* 226 */       arrayOfObject1[1] = readField();
/* 227 */       return arrayOfObject1;
/*     */     case 33: 
/* 229 */       arrayOfObject1 = new Object[4];
/* 230 */       arrayOfObject1[0] = readField();
/* 231 */       arrayOfObject1[1] = readField();
/* 232 */       arrayOfObject1[2] = readField();
/* 233 */       arrayOfObject1[3] = readField();
/* 234 */       return arrayOfObject1;
/*     */     
/*     */     case 34: 
/*     */     case 35: 
/* 238 */       Object[] arrayOfObject2 = new Object[6];
/* 239 */       for (int i1 = 0; i1 < 5; i1++) { arrayOfObject2[i1] = readField();
/*     */       }
/* 241 */       if (paramInt == 35) arrayOfObject2[5] = readField();
/* 242 */       return arrayOfObject2;
/*     */     }
/* 244 */     System.out.println("Unknown fixed-format class " + paramInt);
/* 245 */     throw new IOException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void createSpritesAndWatchers(LContext paramLContext)
/*     */   {
/* 252 */     for (int i = 0; i < this.objTable.length; i++) {
/* 253 */       Object[] arrayOfObject = this.objTable[i];
/* 254 */       int j = ((Number)arrayOfObject[1]).intValue();
/* 255 */       if ((j == 124) || (j == 125)) arrayOfObject[0] = new Sprite(paramLContext);
/* 256 */       if (j == 155) {
/* 257 */         arrayOfObject[0] = new Watcher(paramLContext);
/*     */         
/*     */ 
/*     */ 
/* 261 */         if (((Number)arrayOfObject[2]).intValue() > 3) {
/* 262 */           Number localNumber1 = (Number)arrayOfObject[23];
/* 263 */           Number localNumber2 = (Number)arrayOfObject[24];
/* 264 */           if ((floatWithoutFraction(localNumber1)) || (floatWithoutFraction(localNumber2))) {
/* 265 */             arrayOfObject[24] = new Double(localNumber2.doubleValue() + 1.0E-8D);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   boolean floatWithoutFraction(Object paramObject) {
/* 273 */     if (!(paramObject instanceof Double)) return false;
/* 274 */     double d = ((Double)paramObject).doubleValue();
/* 275 */     return Math.round(d) == d;
/*     */   }
/*     */   
/*     */   void resolveReferences() throws IOException {
/* 279 */     for (int i = 0; i < this.objTable.length; i++) {
/* 280 */       int j = ((Number)this.objTable[i][1]).intValue();
/*     */       
/* 282 */       if ((j >= 20) && (j <= 29)) {
/* 283 */         Object[] arrayOfObject = (Object[])this.objTable[i][0];
/* 284 */         for (int m = 0; m < arrayOfObject.length; m++) {
/* 285 */           Object localObject2 = arrayOfObject[m];
/* 286 */           if ((localObject2 instanceof Ref)) {
/* 287 */             arrayOfObject[m] = deRef((Ref)localObject2);
/*     */           }
/*     */         }
/*     */       }
/* 291 */       if (j > 99) {
/* 292 */         for (int k = 3; k < this.objTable[i].length; k++) {
/* 293 */           Object localObject1 = this.objTable[i][k];
/* 294 */           if ((localObject1 instanceof Ref)) {
/* 295 */             this.objTable[i][k] = deRef((Ref)localObject1);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   Object deRef(Ref paramRef) {
/* 303 */     Object[] arrayOfObject = this.objTable[paramRef.index];
/* 304 */     return (arrayOfObject[0] == null) || (arrayOfObject[0] == empty) ? arrayOfObject : arrayOfObject[0];
/*     */   }
/*     */   
/*     */   void buildImagesAndSounds() throws IOException {
/* 308 */     for (int i = 0; i < this.objTable.length; i++) {
/* 309 */       int j = ((Number)this.objTable[i][1]).intValue();
/*     */       Object[] arrayOfObject;
/* 311 */       if ((j == 34) || (j == 35)) {
/* 312 */         arrayOfObject = (Object[])this.objTable[i][0];
/* 313 */         int k = ((Number)arrayOfObject[0]).intValue();
/* 314 */         int m = ((Number)arrayOfObject[1]).intValue();
/* 315 */         int n = ((Number)arrayOfObject[2]).intValue();
/* 316 */         int[] arrayOfInt = decodePixels(this.objTable[((Ref)arrayOfObject[4]).index][0]);
/* 317 */         MemoryImageSource localMemoryImageSource = null;
/*     */         
/* 319 */         this.objTable[i][0] = empty;
/*     */         Object localObject2;
/* 321 */         Object localObject1; if (n <= 8)
/*     */         {
/* 323 */           if (arrayOfObject[5] != null) {
/* 324 */             localObject2 = (Object[])this.objTable[((Ref)arrayOfObject[5]).index][0];
/* 325 */             localObject1 = customColorMap(n, (Object[])localObject2);
/*     */           } else {
/* 327 */             localObject1 = squeakColorMap(n);
/*     */           }
/* 329 */           localMemoryImageSource = new MemoryImageSource(k, m, (ColorModel)localObject1, rasterToByteRaster(arrayOfInt, k, m, n), 0, k);
/*     */         }
/* 331 */         if (n == 16) {
/* 332 */           localMemoryImageSource = new MemoryImageSource(k, m, raster16to32(arrayOfInt, k, m), 0, k);
/*     */         }
/* 334 */         if (n == 32) {
/* 335 */           localMemoryImageSource = new MemoryImageSource(k, m, rasterAddAlphaTo32(arrayOfInt), 0, k);
/*     */         }
/* 337 */         if (localMemoryImageSource != null) {
/* 338 */           localObject1 = new int[k * m];
/* 339 */           localObject2 = new PixelGrabber(localMemoryImageSource, 0, 0, k, m, (int[])localObject1, 0, k);
/* 340 */           try { ((PixelGrabber)localObject2).grabPixels(); } catch (InterruptedException localInterruptedException) {}
/* 341 */           BufferedImage localBufferedImage = new BufferedImage(k, m, 2);
/* 342 */           localBufferedImage.getRaster().setDataElements(0, 0, k, m, localObject1);
/* 343 */           this.objTable[i][0] = localBufferedImage;
/*     */         }
/*     */       }
/*     */       
/* 347 */       if (j == 109) {
/* 348 */         arrayOfObject = this.objTable[((Ref)this.objTable[i][6]).index];
/* 349 */         this.objTable[i][0] = new ScratchSound(((Number)this.objTable[i][7]).intValue(), (byte[])arrayOfObject[0]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int[] decodePixels(Object paramObject)
/*     */     throws IOException
/*     */   {
/* 365 */     if ((paramObject instanceof int[])) { return (int[])paramObject;
/*     */     }
/* 367 */     DataInputStream localDataInputStream = new DataInputStream(new ByteArrayInputStream((byte[])paramObject));
/* 368 */     int i = decodeInt(localDataInputStream);
/* 369 */     int[] arrayOfInt = new int[i];
/* 370 */     int j = 0;
/*     */     int m;
/* 372 */     int i2; int i3; while (((localDataInputStream.available() > 0 ? 1 : 0) & (j < i ? 1 : 0)) != 0) {
/* 373 */       int k = decodeInt(localDataInputStream);
/* 374 */       m = k >> 2;
/* 375 */       int n = k & 0x3;
/*     */       
/*     */ 
/* 378 */       switch (n) {
/*     */       case 0: 
/* 380 */         j += m;
/* 381 */         break;
/*     */       case 1: 
/* 383 */         int i1 = localDataInputStream.readUnsignedByte();
/* 384 */         i2 = i1 << 24 | i1 << 16 | i1 << 8 | i1;
/* 385 */         for (i3 = 0; i3 < m;) { arrayOfInt[(j++)] = i2;i3++; continue;
/*     */           
/*     */ 
/* 388 */           i2 = localDataInputStream.readInt();
/* 389 */           for (i3 = 0; i3 < m;) { arrayOfInt[(j++)] = i2;i3++; continue;
/*     */             
/*     */ 
/* 392 */             for (i3 = 0; i3 < m; i3++) {
/* 393 */               i2 = localDataInputStream.readUnsignedByte() << 24;
/* 394 */               i2 |= localDataInputStream.readUnsignedByte() << 16;
/* 395 */               i2 |= localDataInputStream.readUnsignedByte() << 8;
/* 396 */               i2 |= localDataInputStream.readUnsignedByte();
/* 397 */               arrayOfInt[(j++)] = i2;
/*     */             }
/*     */           }
/*     */         } }
/*     */     }
/* 402 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int decodeInt(DataInputStream paramDataInputStream)
/*     */     throws IOException
/*     */   {
/* 412 */     int i = paramDataInputStream.readUnsignedByte();
/* 413 */     if (i <= 223) return i;
/* 414 */     if (i <= 254) return (i - 224) * 256 + paramDataInputStream.readUnsignedByte();
/* 415 */     return paramDataInputStream.readInt();
/*     */   }
/*     */   
/*     */   int[] rasterAddAlphaTo32(int[] paramArrayOfInt)
/*     */   {
/* 420 */     for (int i = 0; i < paramArrayOfInt.length; i++) {
/* 421 */       int j = paramArrayOfInt[i];
/* 422 */       if (j != 0) paramArrayOfInt[i] = (0xFF000000 | j);
/*     */     }
/* 424 */     return paramArrayOfInt;
/*     */   }
/*     */   
/*     */ 
/*     */   int[] raster16to32(int[] paramArrayOfInt, int paramInt1, int paramInt2)
/*     */   {
/* 430 */     int[] arrayOfInt = new int[paramInt1 * paramInt2];
/* 431 */     int i2 = (paramInt1 + 1) / 2;
/* 432 */     for (int i3 = 0; i3 < paramInt2; i3++) {
/* 433 */       int i = 16;
/* 434 */       for (int i4 = 0; i4 < paramInt1; i4++) {
/* 435 */         int j = paramArrayOfInt[(i3 * i2 + i4 / 2)] >> i & 0xFFFF;
/* 436 */         int k = (j >> 10 & 0x1F) << 3;
/* 437 */         int m = (j >> 5 & 0x1F) << 3;
/* 438 */         int n = (j & 0x1F) << 3;
/* 439 */         int i1 = k + m + n == 0 ? 0 : 0xFF000000 | k << 16 | m << 8 | n;
/* 440 */         arrayOfInt[(i3 * paramInt1 + i4)] = i1;
/* 441 */         i = i == 16 ? 0 : 16;
/*     */       }
/*     */     }
/* 444 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   byte[] rasterToByteRaster(int[] paramArrayOfInt, int paramInt1, int paramInt2, int paramInt3) {
/* 448 */     byte[] arrayOfByte = new byte[paramInt1 * paramInt2];
/* 449 */     int i = paramArrayOfInt.length / paramInt2;
/* 450 */     int j = (1 << paramInt3) - 1;
/* 451 */     int k = 32 / paramInt3;
/*     */     
/* 453 */     for (int m = 0; m < paramInt2; m++) {
/* 454 */       for (int n = 0; n < paramInt1; n++) {
/* 455 */         int i1 = paramArrayOfInt[(m * i + n / k)];
/* 456 */         int i2 = paramInt3 * (k - n % k - 1);
/* 457 */         arrayOfByte[(m * paramInt1 + n)] = ((byte)(i1 >> i2 & j));
/*     */       }
/*     */     }
/* 460 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */ 
/* 464 */   static final byte[] squeakColors = { -1, -1, -1, 0, 0, 0, -1, -1, -1, Byte.MIN_VALUE, Byte.MIN_VALUE, Byte.MIN_VALUE, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, -1, -1, -1, -1, 0, -1, 0, -1, 32, 32, 32, 64, 64, 64, 96, 96, 96, -97, -97, -97, -65, -65, -65, -33, -33, -33, 8, 8, 8, 16, 16, 16, 24, 24, 24, 40, 40, 40, 48, 48, 48, 56, 56, 56, 72, 72, 72, 80, 80, 80, 88, 88, 88, 104, 104, 104, 112, 112, 112, 120, 120, 120, -121, -121, -121, -113, -113, -113, -105, -105, -105, -89, -89, -89, -81, -81, -81, -73, -73, -73, -57, -57, -57, -49, -49, -49, -41, -41, -41, -25, -25, -25, -17, -17, -17, -9, -9, -9, 0, 0, 0, 0, 51, 0, 0, 102, 0, 0, -103, 0, 0, -52, 0, 0, -1, 0, 0, 0, 51, 0, 51, 51, 0, 102, 51, 0, -103, 51, 0, -52, 51, 0, -1, 51, 0, 0, 102, 0, 51, 102, 0, 102, 102, 0, -103, 102, 0, -52, 102, 0, -1, 102, 0, 0, -103, 0, 51, -103, 0, 102, -103, 0, -103, -103, 0, -52, -103, 0, -1, -103, 0, 0, -52, 0, 51, -52, 0, 102, -52, 0, -103, -52, 0, -52, -52, 0, -1, -52, 0, 0, -1, 0, 51, -1, 0, 102, -1, 0, -103, -1, 0, -52, -1, 0, -1, -1, 51, 0, 0, 51, 51, 0, 51, 102, 0, 51, -103, 0, 51, -52, 0, 51, -1, 0, 51, 0, 51, 51, 51, 51, 51, 102, 51, 51, -103, 51, 51, -52, 51, 51, -1, 51, 51, 0, 102, 51, 51, 102, 51, 102, 102, 51, -103, 102, 51, -52, 102, 51, -1, 102, 51, 0, -103, 51, 51, -103, 51, 102, -103, 51, -103, -103, 51, -52, -103, 51, -1, -103, 51, 0, -52, 51, 51, -52, 51, 102, -52, 51, -103, -52, 51, -52, -52, 51, -1, -52, 51, 0, -1, 51, 51, -1, 51, 102, -1, 51, -103, -1, 51, -52, -1, 51, -1, -1, 102, 0, 0, 102, 51, 0, 102, 102, 0, 102, -103, 0, 102, -52, 0, 102, -1, 0, 102, 0, 51, 102, 51, 51, 102, 102, 51, 102, -103, 51, 102, -52, 51, 102, -1, 51, 102, 0, 102, 102, 51, 102, 102, 102, 102, 102, -103, 102, 102, -52, 102, 102, -1, 102, 102, 0, -103, 102, 51, -103, 102, 102, -103, 102, -103, -103, 102, -52, -103, 102, -1, -103, 102, 0, -52, 102, 51, -52, 102, 102, -52, 102, -103, -52, 102, -52, -52, 102, -1, -52, 102, 0, -1, 102, 51, -1, 102, 102, -1, 102, -103, -1, 102, -52, -1, 102, -1, -1, -103, 0, 0, -103, 51, 0, -103, 102, 0, -103, -103, 0, -103, -52, 0, -103, -1, 0, -103, 0, 51, -103, 51, 51, -103, 102, 51, -103, -103, 51, -103, -52, 51, -103, -1, 51, -103, 0, 102, -103, 51, 102, -103, 102, 102, -103, -103, 102, -103, -52, 102, -103, -1, 102, -103, 0, -103, -103, 51, -103, -103, 102, -103, -103, -103, -103, -103, -52, -103, -103, -1, -103, -103, 0, -52, -103, 51, -52, -103, 102, -52, -103, -103, -52, -103, -52, -52, -103, -1, -52, -103, 0, -1, -103, 51, -1, -103, 102, -1, -103, -103, -1, -103, -52, -1, -103, -1, -1, -52, 0, 0, -52, 51, 0, -52, 102, 0, -52, -103, 0, -52, -52, 0, -52, -1, 0, -52, 0, 51, -52, 51, 51, -52, 102, 51, -52, -103, 51, -52, -52, 51, -52, -1, 51, -52, 0, 102, -52, 51, 102, -52, 102, 102, -52, -103, 102, -52, -52, 102, -52, -1, 102, -52, 0, -103, -52, 51, -103, -52, 102, -103, -52, -103, -103, -52, -52, -103, -52, -1, -103, -52, 0, -52, -52, 51, -52, -52, 102, -52, -52, -103, -52, -52, -52, -52, -52, -1, -52, -52, 0, -1, -52, 51, -1, -52, 102, -1, -52, -103, -1, -52, -52, -1, -52, -1, -1, -1, 0, 0, -1, 51, 0, -1, 102, 0, -1, -103, 0, -1, -52, 0, -1, -1, 0, -1, 0, 51, -1, 51, 51, -1, 102, 51, -1, -103, 51, -1, -52, 51, -1, -1, 51, -1, 0, 102, -1, 51, 102, -1, 102, 102, -1, -103, 102, -1, -52, 102, -1, -1, 102, -1, 0, -103, -1, 51, -103, -1, 102, -103, -1, -103, -103, -1, -52, -103, -1, -1, -103, -1, 0, -52, -1, 51, -52, -1, 102, -52, -1, -103, -52, -1, -52, -52, -1, -1, -52, -1, 0, -1, -1, 51, -1, -1, 102, -1, -1, -103, -1, -1, -52, -1, -1, -1, -1 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   IndexColorModel squeakColorMap(int paramInt)
/*     */   {
/* 500 */     int i = paramInt == 1 ? -1 : 0;
/* 501 */     return new IndexColorModel(paramInt, 256, squeakColors, 0, false, i);
/*     */   }
/*     */   
/*     */   IndexColorModel customColorMap(int paramInt, Object[] paramArrayOfObject) {
/* 505 */     byte[] arrayOfByte = new byte[4 * paramArrayOfObject.length];
/* 506 */     int i = 0;
/* 507 */     for (int j = 0; j < paramArrayOfObject.length; j++) {
/* 508 */       Color localColor = (Color)this.objTable[((Ref)paramArrayOfObject[j]).index][0];
/* 509 */       arrayOfByte[(i++)] = ((byte)localColor.getRed());
/* 510 */       arrayOfByte[(i++)] = ((byte)localColor.getGreen());
/* 511 */       arrayOfByte[(i++)] = ((byte)localColor.getBlue());
/* 512 */       arrayOfByte[(i++)] = ((byte)localColor.getAlpha());
/*     */     }
/* 514 */     return new IndexColorModel(paramInt, paramArrayOfObject.length, arrayOfByte, 0, true, 0);
/*     */   }
/*     */   
/*     */   void fixSounds() {
/* 518 */     int i = 0;
/*     */     int k;
/* 520 */     for (int j = 0; j < this.objTable.length; j++) {
/* 521 */       k = ((Number)this.objTable[j][1]).intValue();
/* 522 */       if ((k == 109) && 
/* 523 */         (((ScratchSound)this.objTable[j][0]).isByteReversed())) { i = 1;
/*     */       }
/*     */     }
/* 526 */     if (i == 0) { return;
/*     */     }
/* 528 */     for (j = 0; j < this.objTable.length; j++) {
/* 529 */       k = ((Number)this.objTable[j][1]).intValue();
/* 530 */       if (k == 109) {
/* 531 */         ((ScratchSound)this.objTable[j][0]).reverseBytes();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void uncompressMedia() {
/* 537 */     for (int i = 0; i < this.objTable.length; i++) {
/* 538 */       Object[] arrayOfObject = this.objTable[i];
/* 539 */       int j = ((Number)arrayOfObject[1]).intValue();
/* 540 */       int k = -1;
/* 541 */       if (j >= 100) { k = ((Number)arrayOfObject[2]).intValue();
/*     */       }
/* 543 */       if ((j == 162) && (k >= 4)) {
/* 544 */         if ((arrayOfObject[7] instanceof byte[])) {
/* 545 */           BufferedImage localBufferedImage = jpegDecode((byte[])arrayOfObject[7]);
/* 546 */           if (localBufferedImage != null) {
/* 547 */             if ((arrayOfObject[4] instanceof Image)) ((Image)arrayOfObject[4]).flush();
/* 548 */             arrayOfObject[4] = localBufferedImage;
/* 549 */             arrayOfObject[7] = empty;
/*     */           }
/*     */         }
/* 552 */         if ((arrayOfObject[8] instanceof BufferedImage)) {
/* 553 */           arrayOfObject[4] = arrayOfObject[8];
/* 554 */           arrayOfObject[8] = empty;
/*     */         }
/*     */       }
/* 557 */       if ((j == 164) && (k >= 2) && 
/* 558 */         ((arrayOfObject[9] instanceof byte[]))) {
/* 559 */         int m = ((Number)arrayOfObject[7]).intValue();
/* 560 */         int n = ((Number)arrayOfObject[8]).intValue();
/* 561 */         byte[] arrayOfByte = (byte[])arrayOfObject[9];
/* 562 */         int i1 = (arrayOfByte.length * 8 + (n - 1)) / n;
/* 563 */         int[] arrayOfInt = new ADPCMDecoder(arrayOfByte, n).decode(i1);
/* 564 */         arrayOfObject[4] = new ScratchSound(m, arrayOfInt);
/* 565 */         arrayOfObject[7] = (arrayOfObject[8] = arrayOfObject[9] = empty);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void canonicalizeMedia()
/*     */   {
/* 572 */     Vector localVector1 = new Vector(100);
/* 573 */     Vector localVector2 = new Vector(100);
/*     */     
/* 575 */     for (int i = 0; i < this.objTable.length; i++) {
/* 576 */       Object[] arrayOfObject = this.objTable[i];
/* 577 */       int j = ((Number)arrayOfObject[1]).intValue();
/*     */       Object localObject;
/* 579 */       if (j == 162) {
/* 580 */         localObject = (BufferedImage)arrayOfObject[4];
/*     */       }
/*     */       
/* 583 */       if (j == 164) {
/* 584 */         localObject = (ScratchSound)arrayOfObject[4];
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   BufferedImage jpegDecode(byte[] paramArrayOfByte)
/*     */   {
/* 591 */     Toolkit localToolkit = Toolkit.getDefaultToolkit();
/* 592 */     Image localImage = localToolkit.createImage(paramArrayOfByte);
/*     */     
/*     */ 
/* 595 */     MediaTracker localMediaTracker = new MediaTracker(canvas);
/* 596 */     localMediaTracker.addImage(localImage, 0);
/* 597 */     try { localMediaTracker.waitForID(0); } catch (InterruptedException localInterruptedException) {}
/* 598 */     if (localImage == null) { return null;
/*     */     }
/*     */     
/* 601 */     int i = localImage.getWidth(null);
/* 602 */     int j = localImage.getHeight(null);
/* 603 */     BufferedImage localBufferedImage = new BufferedImage(i, j, 2);
/* 604 */     Graphics localGraphics = localBufferedImage.getGraphics();
/* 605 */     localGraphics.drawImage(localImage, 0, 0, i, j, null);
/* 606 */     localGraphics.dispose();
/* 607 */     localImage.flush();
/* 608 */     return localBufferedImage;
/*     */   }
/*     */   
/*     */   void printit(Object paramObject) {
/* 612 */     if (((paramObject instanceof Object[])) && (((Object[])paramObject).length == 0)) {
/* 613 */       System.out.print(" []");
/* 614 */       return;
/*     */     }
/* 616 */     if ((paramObject instanceof BufferedImage)) {
/* 617 */       BufferedImage localBufferedImage = (BufferedImage)paramObject;
/* 618 */       System.out.print(" BufferedImage_" + paramObject.hashCode() + "(" + localBufferedImage.getWidth(null) + "x" + localBufferedImage.getHeight(null) + ")");
/* 619 */       return;
/*     */     }
/* 621 */     System.out.print(" " + paramObject);
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\ObjReader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */