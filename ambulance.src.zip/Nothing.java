class Nothing {}


/* Location:              T:\p1\ambulance.jar!\Nothing.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */