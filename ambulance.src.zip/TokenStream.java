/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TokenStream
/*     */ {
/*     */   String str;
/* 367 */   int offset = 0;
/*     */   
/*     */   TokenStream(String paramString) {
/* 370 */     this.str = paramString;
/* 371 */     skipSpace();
/*     */   }
/*     */   
/*     */   Object[] readList(LContext paramLContext) {
/* 375 */     Vector localVector = new Vector();
/*     */     Object localObject;
/* 377 */     while ((!eof()) && ((localObject = readToken(paramLContext)) != null)) localVector.addElement(localObject);
/* 378 */     Object[] arrayOfObject = new Object[localVector.size()];
/* 379 */     localVector.copyInto(arrayOfObject);
/* 380 */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   Object readToken(LContext paramLContext) {
/* 384 */     String str1 = next();
/*     */     try {
/* 386 */       if ((str1.length() > 2) && (str1.charAt(0) == '0') && (str1.charAt(1) == 'x'))
/* 387 */         return new Double(Long.parseLong(str1.substring(2), 16));
/*     */     } catch (NumberFormatException localNumberFormatException1) {}
/* 389 */     try { if ((str1.length() > 1) && (str1.charAt(0) == '$'))
/* 390 */         return new Double(Long.parseLong(str1.substring(1), 16));
/*     */     } catch (NumberFormatException localNumberFormatException2) {}
/* 392 */     try { if ((str1.length() > 1) && (str1.charAt(0) == '0'))
/* 393 */         return new Double(Long.parseLong(str1.substring(1), 8)); } catch (NumberFormatException localNumberFormatException3) {}
/* 394 */     if (str1.equals("]")) return null;
/* 395 */     if (Logo.aValidNumber(str1))
/* 396 */       try { return Double.valueOf(str1);
/*     */       } catch (NumberFormatException localNumberFormatException4) {}
/* 398 */     if (str1.charAt(0) == '"')
/* 399 */       return new QuotedSymbol(Logo.intern(str1.substring(1), paramLContext));
/* 400 */     if (str1.charAt(0) == ':')
/* 401 */       return new DottedSymbol(Logo.intern(str1.substring(1), paramLContext));
/* 402 */     if (str1.equals("[")) return readList(paramLContext);
/* 403 */     if (str1.charAt(0) == '|')
/* 404 */       return str1.substring(1);
/* 405 */     return Logo.intern(str1, paramLContext);
/*     */   }
/*     */   
/* 408 */   boolean startsWith(String paramString) { return this.str.startsWith(paramString, this.offset); }
/*     */   
/*     */   void skipToNextLine() {
/* 411 */     while ((!eof()) && ("\n\r".indexOf(this.str.charAt(this.offset)) == -1)) this.offset += 1;
/* 412 */     skipSpace();
/*     */   }
/*     */   
/*     */   void skipSpace() {
/* 416 */     while ((!eof()) && (" ;,\t\r\n".indexOf(this.str.charAt(this.offset)) != -1)) {
/* 417 */       if (peekChar().equals(";"))
/* 418 */         while ((!eof()) && ("\n\r".indexOf(this.str.charAt(this.offset)) == -1))
/* 419 */           this.offset += 1;
/* 420 */       this.offset += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   String nextLine() {
/* 425 */     String str1 = "";
/* 426 */     while ((!eof()) && (";\n\r".indexOf(peekChar()) == -1)) str1 = str1 + nextChar();
/* 427 */     skipSpace();
/* 428 */     return str1;
/*     */   }
/*     */   
/*     */   String next() {
/* 432 */     String str1 = "";
/* 433 */     if (!delim(peekChar()))
/*     */     {
/* 435 */       while ((!eof()) && 
/* 436 */         (!delim(peekChar()))) {
/* 437 */         if (peekChar().equals("|")) {
/* 438 */           str1 = str1 + "|" + getVbarString();
/* 439 */           skipSpace();
/* 440 */           return str1;
/*     */         }
/* 442 */         str1 = str1 + nextChar();
/*     */       } }
/* 444 */     str1 = nextChar();
/* 445 */     skipSpace();
/* 446 */     return str1;
/*     */   }
/*     */   
/*     */   String getVbarString() {
/* 450 */     StringBuffer localStringBuffer = new StringBuffer();
/* 451 */     nextChar();
/*     */     
/* 453 */     while (!eof()) {
/* 454 */       if (peekChar().equals("|")) { nextChar(); break; }
/* 455 */       localStringBuffer.append(nextChar());
/*     */     }
/* 457 */     return localStringBuffer.toString();
/*     */   }
/*     */   
/*     */   boolean delim(String paramString) {
/* 461 */     int i = paramString.charAt(0);
/* 462 */     return "()[] ,\t\r\n".indexOf(i) != -1;
/*     */   }
/*     */   
/* 465 */   String peekChar() { return String.valueOf(this.str.charAt(this.offset)); }
/* 466 */   String nextChar() { return String.valueOf(this.str.charAt(this.offset++)); }
/* 467 */   boolean eof() { return this.str.length() == this.offset; }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\TokenStream.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */