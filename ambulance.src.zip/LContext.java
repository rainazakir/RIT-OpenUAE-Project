/*    */ import java.io.PrintStream;
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LContext
/*    */ {
/*    */   static final boolean isApplet = true;
/* 44 */   Hashtable oblist = new Hashtable();
/* 45 */   Hashtable props = new Hashtable();
/*    */   MapList iline;
/*    */   Symbol cfun;
/* 48 */   Symbol ufun; Object ufunresult; Object juststop = new Object();
/*    */   boolean mustOutput;
/* 50 */   boolean timeToStop; int priority = 0;
/*    */   Object[] locals;
/*    */   String errormessage;
/*    */   String codeBase;
/*    */   String projectURL;
/*    */   PlayerCanvas canvas;
/*    */   Sprite who;
/*    */   Thread logoThread;
/*    */   PrintStream tyo;
/*    */   boolean autostart;
/*    */ }


/* Location:              T:\p1\ambulance.jar!\LContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */