/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JProgressBar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DesktopScratchViewer$1
/*    */   extends Thread
/*    */ {
/*    */   DesktopScratchViewer$1(DesktopScratchViewer.DesktopScratchApplet paramDesktopScratchApplet, DesktopScratchViewer.LoadingPanel paramLoadingPanel, JFrame paramJFrame) {}
/*    */   
/*    */   public void run()
/*    */   {
/* 87 */     while (this.val$app.lc.canvas.isLoading) {
/* 88 */       this.val$load.Progress.setValue((int)(this.val$app.lc.canvas.loadingFraction * 100.0D));
/*    */       try {
/* 90 */         Thread.sleep(10L);
/*    */       } catch (InterruptedException e) {
/* 92 */         e.printStackTrace();
/*    */       }
/*    */     }
/* 95 */     this.val$frm.remove(this.val$load);
/* 96 */     this.val$frm.validate();
/*    */   }
/*    */ }


/* Location:              T:\p1\ambulance.jar!\DesktopScratchViewer$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */