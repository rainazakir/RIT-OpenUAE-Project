/*     */ import java.awt.AWTException;
/*     */ import java.awt.Cursor;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.net.InetAddress;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ public class PantherPrims
/*     */   extends Primitives
/*     */ {
/*  22 */   static final String[] primlist = { "showAskDialogWithText:", "1", "objName", "0", "setMyName:", "0", "isClone", "0", "showInformDialog:withText:", "1", "keyPressed", "0", "returnW:", "1", "cloneMe", "0", "readFile:", "1", "readLine:ofFile:", "2", "numFileLines:", "1", "readFromUrl:", "1", "readLine:FromUrl:", "2", "numUrlFileLines:", "1", "writeText:toFile:", "2", "clearFile:", "1", "getMeshIPAddress", "0", "z:set:cursor", "1" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] primlist()
/*     */   {
/*  30 */     return primlist;
/*     */   }
/*     */   
/*     */   public Object dispatch(int prim, Object[] params, LContext ctx)
/*     */   {
/*  35 */     switch (prim) {
/*     */     case 0: 
/*  37 */       JOptionPane.showInputDialog(DesktopScratchViewer.parent, params[0], "?", 3);
/*  38 */       break;
/*     */     
/*     */     case 1: 
/*  41 */       return ((Hashtable)ctx.props.get(ctx.who)).get(Logo.aSymbol("name", ctx));
/*     */     
/*     */     case 2: 
/*  44 */       ((Hashtable)ctx.props.get(ctx.who)).put(Logo.aSymbol("name", ctx), params[0]);
/*  45 */       break;
/*     */     
/*     */     case 3: 
/*  48 */       Object clone = ((Hashtable)ctx.props.get(ctx.who)).get(Logo.aSymbol("isclone?", ctx));
/*  49 */       return Boolean.valueOf(clone != null);
/*     */     
/*     */     case 4: 
/*  52 */       JOptionPane.showMessageDialog(DesktopScratchViewer.parent, params[0], "info", 1);
/*  53 */       break;
/*     */     
/*     */     case 5: 
/*  56 */       noSupport(prim);
/*  57 */       break;
/*     */     
/*     */     case 6: 
/*  60 */       noSupport(prim);
/*  61 */       break;
/*     */     
/*     */     case 7: 
/*  64 */       noSupport(prim);
/*  65 */       Sprite s = new Sprite(ctx);
/*  66 */       s.x = ctx.who.x;
/*  67 */       s.y = ctx.who.y;
/*  68 */       s.costume = ctx.who.costume;
/*  69 */       s.filteredCostume = ctx.who.filteredCostume;
/*  70 */       s.rotatedCostume = ctx.who.rotatedCostume;
/*  71 */       s.isDraggable = ctx.who.isDraggable;
/*  72 */       s.isShowing = ctx.who.isShowing;
/*  73 */       Hashtable p = new Hashtable();
/*  74 */       Hashtable ctab = (Hashtable)ctx.props.get(ctx.who);
/*  75 */       Enumeration keys = ctab.keys();
/*  76 */       Enumeration values = ctab.elements();
/*  77 */       while (keys.hasMoreElements()) {
/*  78 */         p.put(keys.nextElement(), values.nextElement());
/*     */       }
/*  80 */       p.put("isclone?", "true");
/*  81 */       p.put("name", "clone@" + s.hashCode());
/*  82 */       ctx.props.put(s, p);
/*  83 */       Object[] sprites = new Object[ctx.canvas.sprites.length + 1];
/*  84 */       System.arraycopy(ctx.canvas.sprites, 0, sprites, 0, ctx.canvas.sprites.length);
/*  85 */       sprites[(sprites.length - 1)] = s;
/*  86 */       ctx.canvas.sprites = sprites;
/*  87 */       s.inval();
/*  88 */       break;
/*     */     case 8: 
/*     */       try
/*     */       {
/*  92 */         File f = new File(Logo.aString(params[0], ctx));
/*  93 */         if (!f.exists()) {
/*  94 */           return "";
/*     */         }
/*  96 */         if (f.length() > 100000L) {
/*  97 */           return "Error: This file is to big!";
/*     */         }
/*  99 */         BufferedReader in = new BufferedReader(new FileReader(f));
/* 100 */         StringBuilder contents = new StringBuilder();
/*     */         String line;
/* 102 */         while ((line = in.readLine()) != null) {
/* 103 */           contents.append(line);
/* 104 */           contents.append('\n');
/*     */         }
/* 106 */         in.close();
/* 107 */         return contents.toString();
/*     */       } catch (IOException io) {
/* 109 */         return "";
/*     */       }
/*     */     case 9: 
/*     */       try {
/* 113 */         File f = new File(Logo.aString(params[1], ctx));
/* 114 */         if (!f.exists()) {
/* 115 */           return "";
/*     */         }
/* 117 */         int line = Logo.anInt(params[0], ctx);
/* 118 */         BufferedReader in = new BufferedReader(new FileReader(f));
/* 119 */         for (int i = 1; i < line; i++) {
/* 120 */           in.readLine();
/*     */         }
/* 122 */         String result = in.readLine();
/* 123 */         in.close();
/* 124 */         return result;
/*     */       } catch (IOException io) {
/* 126 */         return "";
/*     */       }
/*     */     case 10: 
/*     */       try {
/* 130 */         File f = new File(Logo.aString(params[0], ctx));
/* 131 */         if (!f.exists()) {
/* 132 */           return "";
/*     */         }
/* 134 */         int lines = 0;
/* 135 */         BufferedReader in = new BufferedReader(new FileReader(f));
/* 136 */         while (in.readLine() != null) {
/* 137 */           lines++;
/*     */         }
/* 139 */         in.close();
/* 140 */         return Integer.valueOf(lines);
/*     */       } catch (IOException io) {
/* 142 */         return "";
/*     */       }
/*     */     case 11: 
/*     */       try {
/* 146 */         String u = Logo.aString(params[0], ctx);
/* 147 */         if (!u.startsWith("http:/")) {
/* 148 */           u = "http://" + u;
/*     */         }
/* 150 */         URLConnection con = new URL(u).openConnection();
/* 151 */         if (con.getContentLength() > 100000) {
/* 152 */           return "Error: This file is to big!";
/*     */         }
/* 154 */         BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
/* 155 */         StringBuilder contents = new StringBuilder();
/*     */         String line;
/* 157 */         while ((line = in.readLine()) != null) {
/* 158 */           contents.append(line);
/* 159 */           contents.append('\n');
/*     */         }
/* 161 */         in.close();
/* 162 */         return contents.toString();
/*     */       } catch (IOException io) {
/* 164 */         return "";
/*     */       }
/*     */     case 12: 
/*     */       try {
/* 168 */         String u = Logo.aString(params[1], ctx);
/* 169 */         if (!u.startsWith("http:/")) {
/* 170 */           u = "http://" + u;
/*     */         }
/* 172 */         URLConnection con = new URL(u).openConnection();
/* 173 */         BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
/* 174 */         int line = Logo.anInt(params[0], ctx);
/* 175 */         for (int i = 1; i < line; i++) {
/* 176 */           in.readLine();
/*     */         }
/* 178 */         String result = in.readLine();
/* 179 */         in.close();
/* 180 */         return result;
/*     */       } catch (IOException io) {
/* 182 */         return "";
/*     */       }
/*     */     case 13: 
/*     */       try {
/* 186 */         String u = Logo.aString(params[0], ctx);
/* 187 */         if (!u.startsWith("http:/")) {
/* 188 */           u = "http://" + u;
/*     */         }
/* 190 */         URLConnection con = new URL(u).openConnection();
/* 191 */         BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
/* 192 */         int lines = 0;
/* 193 */         while (in.readLine() != null) {
/* 194 */           lines++;
/*     */         }
/* 196 */         in.close();
/* 197 */         return Integer.valueOf(lines);
/*     */       } catch (IOException io) {
/* 199 */         return "";
/*     */       }
/*     */     case 14: 
/*     */       try {
/* 203 */         File f = new File(Logo.aString(params[1], ctx));
/* 204 */         String data = Logo.aString(params[0], ctx);
/* 205 */         BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f, true)));
/* 206 */         out.write(data);
/* 207 */         out.close();
/*     */       }
/*     */       catch (IOException io) {}
/*     */     
/*     */     case 15: 
/* 212 */       new File(Logo.aString(params[0], ctx)).delete();
/*     */     case 16: 
/*     */       try
/*     */       {
/* 216 */         return InetAddress.getLocalHost().getHostAddress();
/*     */       } catch (UnknownHostException ex) {
/* 218 */         return "";
/*     */       }
/*     */     
/*     */     case 17: 
/*     */       try
/*     */       {
/* 224 */         ctx.canvas.setCursor(Cursor.getSystemCustomCursor(Logo.aString(params[0], ctx)));
/*     */       }
/*     */       catch (AWTException ex) {}
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 231 */     return null;
/*     */   }
/*     */   
/*     */   void noSupport(int x) {
/* 235 */     JOptionPane.showMessageDialog(DesktopScratchViewer.parent, "Error:\nThe block '" + primlist[(x * 2)] + "' is not (yet) supported!", "Error", 0);
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\PantherPrims.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */