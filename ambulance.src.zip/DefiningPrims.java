/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ class DefiningPrims extends Primitives
/*     */ {
/*   7 */   static String[] primlist = { "make", "2", "define", "3", "let", "1", "thing", "1", "put", "3", "get", "2", "getp", "2", "plist", "1", "erplist", "1", "name?", "1", "defined?", "1", "clearname", "1", "quote", "1", "intern", "1" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  24 */   public String[] primlist() { return primlist; }
/*     */   
/*     */   public Object dispatch(int paramInt, Object[] paramArrayOfObject, LContext paramLContext) {
/*  27 */     switch (paramInt) {
/*  28 */     case 0:  return prim_make(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  29 */     case 1:  return prim_define(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);
/*  30 */     case 2:  return prim_let(paramArrayOfObject[0], paramLContext);
/*  31 */     case 3:  return prim_thing(paramArrayOfObject[0], paramLContext);
/*  32 */     case 4:  return prim_put(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);
/*  33 */     case 5:  return prim_get(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  34 */     case 6:  return prim_get(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  35 */     case 7:  return prim_plist(paramArrayOfObject[0], paramLContext);
/*  36 */     case 8:  return prim_erplist(paramArrayOfObject[0], paramLContext);
/*  37 */     case 9:  return prim_namep(paramArrayOfObject[0], paramLContext);
/*  38 */     case 10:  return prim_definedp(paramArrayOfObject[0], paramLContext);
/*  39 */     case 11:  return prim_clearname(paramArrayOfObject[0], paramLContext);
/*  40 */     case 12:  return prim_quote(paramArrayOfObject[0], paramLContext);
/*  41 */     case 13:  return prim_intern(paramArrayOfObject[0], paramLContext);
/*     */     }
/*     */     
/*  44 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_make(Object paramObject1, Object paramObject2, LContext paramLContext) {
/*  48 */     Logo.setValue(Logo.aSymbol(paramObject1, paramLContext), paramObject2, paramLContext);
/*  49 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_clearname(Object paramObject, LContext paramLContext) {
/*  53 */     Logo.setValue(Logo.aSymbol(paramObject, paramLContext), null, paramLContext);
/*  54 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_define(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext)
/*     */   {
/*  59 */     Symbol localSymbol = Logo.aSymbol(paramObject1, paramLContext);
/*  60 */     Object[] arrayOfObject1 = Logo.aList(paramObject2, paramLContext);
/*  61 */     Object[] arrayOfObject2 = Logo.aList(paramObject3, paramLContext);
/*  62 */     Ufun localUfun = new Ufun(arrayOfObject1, arrayOfObject2);
/*  63 */     localSymbol.fcn = new Function(localUfun, arrayOfObject1.length, 0);
/*  64 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_let(Object paramObject, LContext paramLContext) {
/*  68 */     Vector localVector = new Vector();
/*  69 */     if (paramLContext.locals != null)
/*  70 */       for (int i = 0; i < paramLContext.locals.length; i++)
/*  71 */         localVector.addElement(paramLContext.locals[i]);
/*  72 */     MapList localMapList = new MapList(Logo.aList(paramObject, paramLContext));
/*  73 */     while (!localMapList.eof()) {
/*  74 */       Symbol localSymbol = Logo.aSymbol(localMapList.next(), paramLContext);
/*  75 */       localVector.addElement(localSymbol);
/*  76 */       localVector.addElement(localSymbol.value);
/*  77 */       Logo.setValue(localSymbol, Logo.evalOneArg(localMapList, paramLContext), paramLContext);
/*     */     }
/*  79 */     paramLContext.locals = new Object[localVector.size()];
/*  80 */     localVector.copyInto(paramLContext.locals);
/*  81 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_thing(Object paramObject, LContext paramLContext) {
/*  85 */     return Logo.getValue(Logo.aSymbol(paramObject, paramLContext), paramLContext);
/*     */   }
/*     */   
/*     */   Object prim_put(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/*  89 */     Hashtable localHashtable = (Hashtable)paramLContext.props.get(paramObject1);
/*  90 */     if (localHashtable == null) {
/*  91 */       localHashtable = new Hashtable();
/*  92 */       paramLContext.props.put(paramObject1, localHashtable);
/*     */     }
/*  94 */     localHashtable.put(paramObject2, paramObject3);
/*  95 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_get(Object paramObject1, Object paramObject2, LContext paramLContext) {
/*  99 */     Hashtable localHashtable = (Hashtable)paramLContext.props.get(paramObject1);
/* 100 */     if (localHashtable == null)
/* 101 */       return new Object[0];
/* 102 */     Object localObject = localHashtable.get(paramObject2);
/* 103 */     if (localObject == null) return new Object[0];
/* 104 */     return localObject;
/*     */   }
/*     */   
/*     */   Object prim_plist(Object paramObject, LContext paramLContext) {
/* 108 */     Hashtable localHashtable = (Hashtable)paramLContext.props.get(paramObject);
/* 109 */     if (localHashtable == null) return new Object[0];
/* 110 */     Vector localVector = new Vector();
/* 111 */     for (Object localObject1 = localHashtable.keys(); ((Enumeration)localObject1).hasMoreElements();) {
/* 112 */       Object localObject2 = ((Enumeration)localObject1).nextElement();
/* 113 */       localVector.add(localObject2);
/* 114 */       localVector.add(localHashtable.get(localObject2));
/*     */     }
/* 116 */     localObject1 = new Object[localVector.size()];
/* 117 */     localVector.copyInto((Object[])localObject1);
/* 118 */     return localObject1;
/*     */   }
/*     */   
/*     */   Object prim_erplist(Object paramObject, LContext paramLContext) {
/* 122 */     paramLContext.props.remove(paramObject);
/* 123 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_namep(Object paramObject, LContext paramLContext) {
/* 127 */     return new Boolean(Logo.aSymbol(paramObject, paramLContext).value != null);
/*     */   }
/*     */   
/*     */   Object prim_definedp(Object paramObject, LContext paramLContext) {
/* 131 */     return new Boolean(Logo.aSymbol(paramObject, paramLContext).fcn != null);
/*     */   }
/*     */   
/*     */   Object prim_quote(Object paramObject, LContext paramLContext) {
/* 135 */     if ((paramObject instanceof Object[])) return paramObject;
/* 136 */     return new QuotedSymbol(Logo.aSymbol(paramObject, paramLContext));
/*     */   }
/*     */   
/*     */   Object prim_intern(Object paramObject, LContext paramLContext) {
/* 140 */     return Logo.aSymbol(paramObject, paramLContext);
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\DefiningPrims.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */