/*     */ class ControlPrims extends Primitives
/*     */ {
/*   3 */   static String[] primlist = { "repeat", "2", "if", "2", "ifelse", "3", "stop", "0", "output", "1", "dotimes", "2", "dolist", "2", "carefully", "2", "errormessage", "0", "unwind-protect", "2", "error", "1", "dispatch", "2", "run", "1", "loop", "1", "forever", "1", "selectq", "2", "stopme", "0" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  22 */   public String[] primlist() { return primlist; }
/*     */   
/*     */   public Object dispatch(int paramInt, Object[] paramArrayOfObject, LContext paramLContext) {
/*  25 */     switch (paramInt) {
/*  26 */     case 0:  return prim_repeat(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  27 */     case 1:  return prim_if(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  28 */     case 2:  return prim_ifelse(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);
/*  29 */     case 3:  return prim_stop(paramLContext);
/*  30 */     case 4:  return prim_output(paramArrayOfObject[0], paramLContext);
/*  31 */     case 5:  return prim_dotimes(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  32 */     case 6:  return prim_dolist(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  33 */     case 7:  return prim_carefully(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  34 */     case 8:  return paramLContext.errormessage;
/*  35 */     case 9:  return prim_unwindprotect(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  36 */     case 10:  return prim_error(paramArrayOfObject[0], paramLContext);
/*  37 */     case 11:  return prim_dispatch(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  38 */     case 12:  return prim_run(paramArrayOfObject[0], paramLContext);
/*  39 */     case 13:  return prim_loop(paramArrayOfObject[0], paramLContext);
/*  40 */     case 14:  return prim_loop(paramArrayOfObject[0], paramLContext);
/*  41 */     case 15:  return prim_selectq(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/*  42 */     case 16:  return prim_stopme(paramLContext);
/*     */     }
/*  44 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_repeat(Object paramObject1, Object paramObject2, LContext paramLContext) {
/*  48 */     int i = Logo.anInt(paramObject1, paramLContext);
/*  49 */     Object[] arrayOfObject = Logo.aList(paramObject2, paramLContext);
/*  50 */     for (int j = 0; j < i; j++) { Logo.runCommand(arrayOfObject, paramLContext); if (paramLContext.ufunresult != null) return null; }
/*  51 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_if(Object paramObject1, Object paramObject2, LContext paramLContext) {
/*  55 */     if (Logo.aBoolean(paramObject1, paramLContext)) Logo.runCommand(Logo.aList(paramObject2, paramLContext), paramLContext);
/*  56 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_ifelse(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/*  60 */     boolean bool = Logo.aBoolean(paramObject1, paramLContext);
/*  61 */     Object[] arrayOfObject1 = Logo.aList(paramObject2, paramLContext);
/*  62 */     Object[] arrayOfObject2 = Logo.aList(paramObject3, paramLContext);
/*  63 */     return bool ? Logo.runList(arrayOfObject1, paramLContext) : Logo.runList(arrayOfObject2, paramLContext);
/*     */   }
/*     */   
/*  66 */   Object prim_stop(LContext paramLContext) { paramLContext.ufunresult = paramLContext.juststop;return null; }
/*  67 */   Object prim_output(Object paramObject, LContext paramLContext) { paramLContext.ufunresult = paramObject;return null;
/*     */   }
/*     */   
/*  70 */   Object prim_dotimes(Object paramObject1, Object paramObject2, LContext paramLContext) { MapList localMapList = new MapList(Logo.aList(paramObject1, paramLContext));
/*  71 */     Object[] arrayOfObject = Logo.aList(paramObject2, paramLContext);
/*  72 */     Symbol localSymbol = Logo.aSymbol(localMapList.next(), paramLContext);
/*  73 */     int i = Logo.anInt(Logo.evalOneArg(localMapList, paramLContext), paramLContext);
/*  74 */     Logo.checkListEmpty(localMapList, paramLContext);
/*  75 */     Object localObject1 = localSymbol.value;
/*     */     try {
/*  77 */       for (int j = 0; j < i; j++) {
/*  78 */         localSymbol.value = new Double(j);
/*  79 */         Logo.runCommand(arrayOfObject, paramLContext); }
/*  80 */       if (paramLContext.ufunresult != null) return null;
/*     */     } finally {
/*  82 */       localSymbol.value = localObject1; }
/*  83 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_dolist(Object paramObject1, Object paramObject2, LContext paramLContext) {
/*  87 */     MapList localMapList = new MapList(Logo.aList(paramObject1, paramLContext));
/*  88 */     Object[] arrayOfObject1 = Logo.aList(paramObject2, paramLContext);
/*  89 */     Symbol localSymbol = Logo.aSymbol(localMapList.next(), paramLContext);
/*  90 */     Object[] arrayOfObject2 = Logo.aList(Logo.evalOneArg(localMapList, paramLContext), paramLContext);
/*  91 */     Logo.checkListEmpty(localMapList, paramLContext);
/*  92 */     Object localObject1 = localSymbol.value;
/*     */     try {
/*  94 */       for (int i = 0; i < arrayOfObject2.length; i++) {
/*  95 */         localSymbol.value = arrayOfObject2[i];Logo.runCommand(arrayOfObject1, paramLContext);
/*  96 */         if (paramLContext.ufunresult != null) return null;
/*     */       }
/*     */     } finally {
/*  99 */       localSymbol.value = localObject1; }
/* 100 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_carefully(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 104 */     Object[] arrayOfObject1 = Logo.aList(paramObject1, paramLContext);
/* 105 */     Object[] arrayOfObject2 = Logo.aList(paramObject2, paramLContext);
/* 106 */     try { return Logo.runList(arrayOfObject1, paramLContext);
/*     */     } catch (Exception localException) {
/* 108 */       paramLContext.errormessage = localException.getMessage(); }
/* 109 */     return Logo.runList(arrayOfObject2, paramLContext);
/*     */   }
/*     */   
/*     */   Object prim_unwindprotect(Object paramObject1, Object paramObject2, LContext paramLContext)
/*     */   {
/* 114 */     Object[] arrayOfObject1 = Logo.aList(paramObject1, paramLContext);
/* 115 */     Object[] arrayOfObject2 = Logo.aList(paramObject2, paramLContext);
/* 116 */     try { Logo.runCommand(arrayOfObject1, paramLContext);
/* 117 */     } finally { Logo.runCommand(arrayOfObject2, paramLContext); }
/* 118 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_error(Object paramObject, LContext paramLContext) {
/* 122 */     Logo.error(Logo.prs(paramObject), paramLContext);
/* 123 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_dispatch(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 127 */     int i = Logo.anInt(paramObject1, paramLContext);
/* 128 */     Object[] arrayOfObject1 = Logo.aList(paramObject2, paramLContext);
/* 129 */     Object[] arrayOfObject2 = Logo.aList(arrayOfObject1[i], paramLContext);
/* 130 */     return Logo.runList(arrayOfObject2, paramLContext);
/*     */   }
/*     */   
/*     */   Object prim_run(Object paramObject, LContext paramLContext) {
/* 134 */     return Logo.runList(Logo.aList(paramObject, paramLContext), paramLContext);
/*     */   }
/*     */   
/*     */   Object prim_loop(Object paramObject, LContext paramLContext) {
/* 138 */     Object[] arrayOfObject = Logo.aList(paramObject, paramLContext);
/* 139 */     do { Logo.runCommand(arrayOfObject, paramLContext); } while (paramLContext.ufunresult == null); return null;
/*     */   }
/*     */   
/*     */   Object prim_selectq(Object paramObject1, Object paramObject2, LContext paramLContext)
/*     */   {
/* 144 */     Object[] arrayOfObject = Logo.aList(paramObject2, paramLContext);
/* 145 */     for (int i = 0; i < arrayOfObject.length; i += 2)
/* 146 */       if ((arrayOfObject[i] instanceof DottedSymbol) ? Logo.getValue(((DottedSymbol)arrayOfObject[i]).sym, paramLContext).equals(paramObject1) : arrayOfObject[i].equals(paramObject1))
/*     */       {
/*     */ 
/* 149 */         return Logo.runList((Object[])arrayOfObject[(i + 1)], paramLContext); }
/* 150 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_stopme(LContext paramLContext) {
/* 154 */     Logo.error("", paramLContext);
/* 155 */     return null;
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\ControlPrims.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */