/*      */ import java.awt.Color;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.font.TextLayout;
/*      */ import java.awt.geom.Rectangle2D;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class Watcher
/*      */   implements Drawable
/*      */ {
/* 1122 */   static final Color black = new Color(0, 0, 0);
/* 1123 */   static final Font labelFont = new Font("Arial Unicode MS", 1, 10);
/*      */   
/*      */   static final int NORMAL_MODE = 1;
/*      */   
/*      */   static final int SLIDER_MODE = 2;
/*      */   static final int LARGE_MODE = 3;
/*      */   PlayerCanvas canvas;
/*      */   StretchyBox box;
/*      */   WatcherReadout readout;
/*      */   StretchyBox slider;
/* 1133 */   String label = "x";
/* 1134 */   int mode = 1;
/* 1135 */   double sliderMin = 0.0D;
/* 1136 */   double sliderMax = 100.0D;
/* 1137 */   boolean isDiscrete = false;
/* 1138 */   boolean isShowing = true;
/*      */   
/*      */   Watcher(LContext paramLContext) {
/* 1141 */     if (paramLContext != null) this.canvas = paramLContext.canvas;
/* 1142 */     this.box = new StretchyBox();
/* 1143 */     this.box.setFrameImage(Skin.watcherOuterFrame);
/* 1144 */     this.box.x = 50;
/* 1145 */     this.box.y = 50;
/* 1146 */     this.readout = new WatcherReadout(false);
/* 1147 */     this.readout.color = new Color(74, 107, 214);
/* 1148 */     this.slider = new StretchyBox();
/* 1149 */     this.slider.setFrameImage(Skin.sliderSlot);
/* 1150 */     this.slider.h = 5;
/*      */   }
/*      */   
/* 1153 */   void show() { this.isShowing = true;inval(); }
/* 1154 */   void hide() { this.isShowing = false;inval(); }
/* 1155 */   public boolean isShowing() { return this.isShowing; }
/*      */   
/* 1157 */   public Rectangle rect() { return new Rectangle(this.box.x, this.box.y, this.box.w, this.box.h); }
/* 1158 */   public Rectangle fullRect() { return rect(); }
/* 1159 */   void inval() { this.canvas.inval(rect()); }
/*      */   
/*      */   public void paint(Graphics paramGraphics) {
/* 1162 */     int i = labelWidth(paramGraphics);
/* 1163 */     this.readout.beLarge(this.mode == 3);
/* 1164 */     this.readout.adjustWidth(paramGraphics);
/* 1165 */     this.box.w = (i + this.readout.w + 17);
/* 1166 */     this.box.h = (this.mode == 1 ? 21 : 31);
/*      */     
/* 1168 */     if (this.mode == 3) {
/* 1169 */       this.readout.x = this.box.x;
/* 1170 */       this.readout.y = this.box.y;
/* 1171 */       this.readout.paint(paramGraphics);
/* 1172 */       return;
/*      */     }
/*      */     
/* 1175 */     this.box.paint(paramGraphics);
/* 1176 */     drawLabel(paramGraphics);
/* 1177 */     this.readout.x = (this.box.x + i + 12);
/* 1178 */     this.readout.y = (this.box.y + 3);
/* 1179 */     this.readout.paint(paramGraphics);
/* 1180 */     if (this.mode == 2) drawSlider(paramGraphics);
/*      */   }
/*      */   
/*      */   public void paintBubble(Graphics paramGraphics) {}
/*      */   
/*      */   public void mouseDown(int paramInt1, int paramInt2) {}
/*      */   
/* 1187 */   void drawLabel(Graphics paramGraphics) { paramGraphics.setColor(black);
/* 1188 */     paramGraphics.setFont(labelFont);
/* 1189 */     paramGraphics.drawString(this.label, this.box.x + 6, this.box.y + 14);
/*      */   }
/*      */   
/*      */   int labelWidth(Graphics paramGraphics) {
/* 1193 */     if (this.label.length() == 0) return 0;
/* 1194 */     TextLayout localTextLayout = new TextLayout(this.label, labelFont, ((Graphics2D)paramGraphics).getFontRenderContext());
/* 1195 */     return (int)localTextLayout.getBounds().getBounds().getWidth();
/*      */   }
/*      */   
/*      */   void drawSlider(Graphics paramGraphics) {
/* 1199 */     this.slider.x = (this.box.x + 6);
/* 1200 */     this.slider.y = (this.box.y + 21);
/* 1201 */     this.slider.w = (this.box.w - 12);
/* 1202 */     this.slider.paint(paramGraphics);
/* 1203 */     int i = (int)Math.round((this.slider.w - 8) * ((getSliderValue() - this.sliderMin) / (this.sliderMax - this.sliderMin)));
/* 1204 */     i = Math.max(0, Math.min(i, this.slider.w - 8));
/* 1205 */     paramGraphics.drawImage(Skin.sliderKnob, this.slider.x + i - 1, this.slider.y - 3, null);
/*      */   }
/*      */   
/*      */   boolean inSlider(int paramInt1, int paramInt2) {
/* 1209 */     if (this.mode != 2) return false;
/* 1210 */     if ((paramInt2 < this.slider.y - 1) || (paramInt2 > this.slider.y + this.slider.h + 4)) return false;
/* 1211 */     if ((paramInt1 < this.slider.x - 4) || (paramInt1 > this.slider.x + this.slider.w + 5)) return false;
/* 1212 */     return true;
/*      */   }
/*      */   
/*      */   public void dragTo(int paramInt1, int paramInt2) {
/* 1216 */     double d = paramInt1 - this.box.x - 10;
/* 1217 */     setSliderValue(d * (this.sliderMax - this.sliderMin) / (this.slider.w - 8) + this.sliderMin);
/*      */   }
/*      */   
/*      */   void click(int paramInt1, int paramInt2) {
/* 1221 */     double d = getSliderValue();
/* 1222 */     int i = this.slider.x + (int)Math.round((this.slider.w - 8) * ((d - this.sliderMin) / (this.sliderMax - this.sliderMin))) + 5;
/* 1223 */     int j = paramInt1 < i ? -1 : 1;
/* 1224 */     if (this.isDiscrete) {
/* 1225 */       setSliderValue(d + j);
/*      */     } else {
/* 1227 */       setSliderValue(d + j * ((this.sliderMax - this.sliderMin) / 100.0D));
/*      */     }
/*      */   }
/*      */   
/*      */   double getSliderValue() {
/* 1232 */     String str = Logo.prs(getObjProp(this, "param"));
/* 1233 */     Hashtable localHashtable = getVarsTable();
/* 1234 */     if ((str == null) || (localHashtable == null)) return (this.sliderMin + this.sliderMax) / 2.0D;
/* 1235 */     Object localObject = localHashtable.get(Logo.aSymbol(str, this.canvas.lc));
/* 1236 */     return (localObject instanceof Number) ? ((Number)localObject).doubleValue() : (this.sliderMin + this.sliderMax) / 2.0D;
/*      */   }
/*      */   
/*      */   void setSliderValue(double paramDouble) {
/* 1240 */     double d = this.isDiscrete ? Math.round(paramDouble) : paramDouble;
/* 1241 */     d = Math.min(this.sliderMax, Math.max(this.sliderMin, d));
/*      */     
/* 1243 */     String str = Logo.prs(getObjProp(this, "param"));
/* 1244 */     Hashtable localHashtable = getVarsTable();
/* 1245 */     if ((str == null) || (localHashtable == null)) return;
/* 1246 */     localHashtable.put(Logo.aSymbol(str, this.canvas.lc), new Double(d));
/* 1247 */     inval();
/*      */   }
/*      */   
/*      */   Hashtable getVarsTable() {
/* 1251 */     String str1 = Logo.prs(getObjProp(this, "op"));
/* 1252 */     String str2 = Logo.prs(getObjProp(this, "param"));
/* 1253 */     Object localObject1 = getObjProp(this, "target");
/* 1254 */     if ((localObject1 == null) || (!str1.equals("getVar:"))) { return null;
/*      */     }
/*      */     
/*      */ 
/* 1258 */     Object localObject2 = getObjProp(localObject1, "vars");
/* 1259 */     if (localObject2 == null) return null;
/* 1260 */     return (Hashtable)this.canvas.lc.props.get(localObject2);
/*      */   }
/*      */   
/*      */   Object getObjProp(Object paramObject, String paramString) {
/* 1264 */     Hashtable localHashtable = (Hashtable)this.canvas.lc.props.get(paramObject);
/* 1265 */     if (localHashtable == null) return null;
/* 1266 */     return localHashtable.get(Logo.aSymbol(paramString, this.canvas.lc));
/*      */   }
/*      */ }


/* Location:              T:\p1\ambulance.jar!\Watcher.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */