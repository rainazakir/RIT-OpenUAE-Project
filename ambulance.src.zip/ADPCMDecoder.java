/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ class ADPCMDecoder
/*     */ {
/*   8 */   static final int[] stepSizeTable = { 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  15 */   static final int[] indices2bit = { -1, 2 };
/*  16 */   static final int[] indices3bit = { -1, -1, 2, 4 };
/*  17 */   static final int[] indices4bit = { -1, -1, -1, -1, 2, 4, 6, 8 };
/*  18 */   static final int[] indices5bit = { -1, -1, -1, -1, -1, -1, -1, -1, 1, 2, 4, 6, 8, 10, 13, 16 };
/*     */   
/*     */   DataInputStream in;
/*     */   
/*     */   int bitsPerSample;
/*     */   
/*     */   int currentByte;
/*     */   int bitPosition;
/*     */   int[] indexTable;
/*     */   int predicted;
/*     */   int index;
/*     */   
/*     */   ADPCMDecoder(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/*  32 */     this(new ByteArrayInputStream(paramArrayOfByte), paramInt);
/*     */   }
/*     */   
/*     */   ADPCMDecoder(InputStream paramInputStream, int paramInt) {
/*  36 */     this.in = new DataInputStream(paramInputStream);
/*  37 */     this.bitsPerSample = paramInt;
/*  38 */     switch (this.bitsPerSample) {
/*     */     case 2: 
/*  40 */       this.indexTable = indices2bit;
/*  41 */       break;
/*     */     case 3: 
/*  43 */       this.indexTable = indices3bit;
/*  44 */       break;
/*     */     case 4: 
/*  46 */       this.indexTable = indices4bit;
/*  47 */       break;
/*     */     case 5: 
/*  49 */       this.indexTable = indices5bit;
/*     */     }
/*     */   }
/*     */   
/*     */   int[] decode(int paramInt)
/*     */   {
/*  55 */     int i = 1 << this.bitsPerSample - 1;
/*  56 */     int j = i - 1;
/*  57 */     int k = i >> 1;
/*     */     
/*     */ 
/*  60 */     int[] arrayOfInt = new int[paramInt];
/*     */     
/*  62 */     for (int i3 = 0; i3 < paramInt; i3++) {
/*  63 */       int m = nextBits();
/*  64 */       int n = stepSizeTable[this.index];
/*  65 */       int i1 = 0;
/*  66 */       for (int i2 = k; i2 > 0; i2 >>= 1) {
/*  67 */         if ((m & i2) != 0) i1 += n;
/*  68 */         n >>= 1;
/*     */       }
/*  70 */       i1 += n;
/*     */       
/*  72 */       this.predicted += ((m & i) != 0 ? -i1 : i1);
/*  73 */       if (this.predicted > 32767) this.predicted = 32767;
/*  74 */       if (this.predicted < 32768) this.predicted = 32768;
/*  75 */       arrayOfInt[i3] = this.predicted;
/*     */       
/*  77 */       this.index += this.indexTable[(m & j)];
/*  78 */       if (this.index < 0) this.index = 0;
/*  79 */       if (this.index > 88) this.index = 88;
/*     */     }
/*  81 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   int nextBits() {
/*  85 */     int i = 0;
/*  86 */     int j = this.bitsPerSample;
/*     */     do {
/*  88 */       int k = j - this.bitPosition;
/*  89 */       i += (k < 0 ? this.currentByte >> -k : this.currentByte << k);
/*  90 */       if (k <= 0) break;
/*  91 */       j -= this.bitPosition;
/*     */       try {
/*  93 */         this.currentByte = this.in.readUnsignedByte();
/*     */       } catch (IOException localIOException) {
/*  95 */         this.currentByte = -1;
/*     */       }
/*  97 */       this.bitPosition = 8;
/*  98 */     } while (this.currentByte >= 0);
/*  99 */     this.bitPosition = 0;
/* 100 */     return i;
/*     */     
/*     */ 
/* 103 */     this.bitPosition -= j;
/* 104 */     this.currentByte &= 255 >> 8 - this.bitPosition;
/* 105 */     return i;
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\ADPCMDecoder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */