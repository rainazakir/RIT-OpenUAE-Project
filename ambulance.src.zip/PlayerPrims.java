/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.MediaTracker;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.AccessControlException;
/*     */ import java.util.Vector;
/*     */ import javax.sound.midi.InvalidMidiDataException;
/*     */ import javax.sound.midi.MidiChannel;
/*     */ import javax.sound.midi.MidiSystem;
/*     */ import javax.sound.midi.MidiUnavailableException;
/*     */ import javax.sound.midi.Soundbank;
/*     */ import javax.sound.midi.Synthesizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PlayerPrims
/*     */   extends Primitives
/*     */ {
/*     */   static Synthesizer midiSynth;
/*  50 */   static boolean midiSynthInitialized = false;
/*  51 */   static int[] sensorValues = { 0, 0, 0, 1000, 1000, 1000, 1000, 1000, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */   
/*  53 */   static final String[] primlist = { "redrawall", "0", "redraw", "0", "drawrect", "4", "stage", "0", "setstage", "1", "sprites", "0", "setsprites", "1", "readprojfile", "1", "readprojurl", "0", "applet?", "0", "string?", "1", "sprite?", "1", "color?", "1", "mouseX", "0", "mouseY", "0", "mouseIsDown", "0", "mouseClick", "0", "keystroke", "0", "keydown?", "1", "clearkeys", "0", "midisetinstrument", "2", "midinoteon", "3", "midinoteoff", "2", "midicontrol", "3", "updatePenTrails", "0", "soundLevel", "0", "jpegDecode", "1", "memTotal", "0", "memFree", "0", "gc", "0", "clearall", "0", "requestFocus", "0", "setMessage", "1", "getSensorValue", "1", "autostart?", "0", "quoted?", "1", "unquote", "1" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */   public String[] primlist() { return primlist; }
/*     */   
/*     */   public Object dispatch(int paramInt, Object[] paramArrayOfObject, LContext paramLContext) {
/*  96 */     switch (paramInt) {
/*  97 */     case 0:  paramLContext.canvas.redraw_all();return null;
/*  98 */     case 1:  paramLContext.canvas.redraw_invalid();return null;
/*  99 */     case 2:  return prim_drawrect(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramArrayOfObject[3], paramLContext);
/* 100 */     case 3:  return paramLContext.canvas.stage == null ? new Object[0] : paramLContext.canvas.stage;
/* 101 */     case 4:  return prim_setstage(paramArrayOfObject[0], paramLContext);
/* 102 */     case 5:  return paramLContext.canvas.sprites;
/* 103 */     case 6:  paramLContext.canvas.sprites = ((Object[])paramArrayOfObject[0]);return null;
/* 104 */     case 7:  return prim_readprojfile(paramArrayOfObject[0], paramLContext);
/* 105 */     case 8:  return prim_readprojurl(paramLContext);
/* 106 */     case 9:  return new Boolean(true);
/* 107 */     case 10:  return new Boolean(((paramArrayOfObject[0] instanceof String)) || ((paramArrayOfObject[0] instanceof Symbol)));
/* 108 */     case 11:  return new Boolean(paramArrayOfObject[0] instanceof Sprite);
/* 109 */     case 12:  return new Boolean(paramArrayOfObject[0] instanceof Color);
/* 110 */     case 13:  return new Double(paramLContext.canvas.mouseX);
/* 111 */     case 14:  return new Double(paramLContext.canvas.mouseY);
/* 112 */     case 15:  return new Boolean(paramLContext.canvas.mouseIsDown);
/* 113 */     case 16:  return prim_mouseclick(paramLContext);
/* 114 */     case 17:  return prim_keystroke(paramLContext);
/* 115 */     case 18:  return prim_keydown(paramArrayOfObject[0], paramLContext);
/* 116 */     case 19:  paramLContext.canvas.clearkeys();return null;
/* 117 */     case 20:  return prim_midisetinstrument(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/* 118 */     case 21:  return prim_midinoteon(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);
/* 119 */     case 22:  return prim_midinoteoff(paramArrayOfObject[0], paramArrayOfObject[1], paramLContext);
/* 120 */     case 23:  return prim_midicontrol(paramArrayOfObject[0], paramArrayOfObject[1], paramArrayOfObject[2], paramLContext);
/* 121 */     case 24:  paramLContext.canvas.updatePenTrails();return null;
/* 122 */     case 25:  return new Double(paramLContext.canvas.soundLevel());
/* 123 */     case 26:  return prim_jpegDecode(paramArrayOfObject[0], paramLContext);
/* 124 */     case 27:  return new Double(Runtime.getRuntime().totalMemory());
/* 125 */     case 28:  return new Double(Runtime.getRuntime().freeMemory());
/* 126 */     case 29:  Runtime.getRuntime().gc();return null;
/* 127 */     case 30:  paramLContext.canvas.clearall(paramLContext);return null;
/* 128 */     case 31:  paramLContext.canvas.requestFocus();return null;
/* 129 */     case 32:  paramLContext.canvas.setMessage(Logo.aString(paramArrayOfObject[0], paramLContext));return null;
/* 130 */     case 33:  return prim_getSensorValue(paramArrayOfObject[0], paramLContext);
/* 131 */     case 34:  return new Boolean(paramLContext.autostart);
/* 132 */     case 35:  return new Boolean(paramArrayOfObject[0] instanceof QuotedSymbol);
/* 133 */     case 36:  return ((QuotedSymbol)paramArrayOfObject[0]).sym;
/*     */     }
/* 135 */     return null;
/*     */   }
/*     */   
/* 138 */   static final String[] primclasses = { "SystemPrims", "MathPrims", "ControlPrims", "DefiningPrims", "WordListPrims", "FilePrims", "PlayerPrims", "SpritePrims" };
/*     */   
/*     */ 
/*     */ 
/*     */   static synchronized LContext startup(String paramString1, String paramString2, Container paramContainer, boolean paramBoolean)
/*     */   {
/* 144 */     LContext localLContext = new LContext();
/* 145 */     Logo.setupPrims(primclasses, localLContext);
/* 146 */     localLContext.codeBase = paramString1;
/* 147 */     localLContext.projectURL = paramString2;
/* 148 */     localLContext.autostart = paramBoolean;
/* 149 */     PlayerCanvas localPlayerCanvas = new PlayerCanvas();
/* 150 */     localPlayerCanvas.lc = localLContext;
/* 151 */     localLContext.canvas = localPlayerCanvas;
/*     */     
/* 153 */     Skin.readSkin(localPlayerCanvas);
/* 154 */     SoundPlayer.startPlayer();
/* 155 */     paramContainer.add(localPlayerCanvas, "Center");
/* 156 */     LogoCommandRunner.startLogoThread("load \"startup startup", localLContext);
/* 157 */     return localLContext;
/*     */   }
/*     */   
/*     */   static synchronized void shutdown(LContext paramLContext) {
/* 161 */     if (paramLContext != null) {
/* 162 */       LogoCommandRunner.stopLogoThread(paramLContext);
/* 163 */       paramLContext.canvas.clearall(paramLContext);
/*     */     }
/* 165 */     SoundPlayer.stopSoundsForApplet(paramLContext);
/* 166 */     sensorValues = new int[16];
/* 167 */     for (int i = 3; i < 8; i++) sensorValues[i] = 1000;
/*     */   }
/*     */   
/*     */   static void stopMIDINotes() {
/* 171 */     if (midiSynth == null) return;
/* 172 */     MidiChannel[] arrayOfMidiChannel = midiSynth.getChannels();
/* 173 */     for (int i = 0; i < arrayOfMidiChannel.length; i++) {
/* 174 */       if (arrayOfMidiChannel[i] != null) {
/* 175 */         arrayOfMidiChannel[i].allNotesOff();
/* 176 */         arrayOfMidiChannel[i].programChange(0);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   Object prim_drawrect(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, LContext paramLContext) {
/* 182 */     int i = Logo.anInt(paramObject1, paramLContext);
/* 183 */     int j = Logo.anInt(paramObject2, paramLContext);
/* 184 */     int k = Logo.anInt(paramObject3, paramLContext);
/* 185 */     int m = Logo.anInt(paramObject4, paramLContext);
/* 186 */     paramLContext.canvas.drawRect(i, j, k, m);
/* 187 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_setstage(Object paramObject, LContext paramLContext) {
/* 191 */     if (!(paramObject instanceof Sprite)) return null;
/* 192 */     Sprite localSprite = (Sprite)paramObject;
/* 193 */     localSprite.x = (localSprite.y = 0.0D);
/* 194 */     paramLContext.canvas.stage = localSprite;
/* 195 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   Object prim_readprojfile(Object paramObject, LContext paramLContext)
/*     */   {
/* 201 */     Object[] arrayOfObject = new Object[0];
/*     */     
/*     */ 
/* 204 */     paramLContext.canvas.startLoading();
/*     */     FileInputStream localFileInputStream;
/* 206 */     try { localFileInputStream = new FileInputStream(paramObject.toString());
/*     */     } catch (FileNotFoundException localFileNotFoundException) {
/* 208 */       Logo.error("File not found: " + paramObject, paramLContext);
/* 209 */       return arrayOfObject;
/*     */     }
/*     */     
/* 212 */     paramLContext.canvas.loadingProgress(0.5D);
/*     */     Object[][] arrayOfObject1;
/* 214 */     try { ObjReader localObjReader = new ObjReader(localFileInputStream);
/* 215 */       arrayOfObject1 = localObjReader.readObjects(paramLContext);
/* 216 */       localFileInputStream.close();
/*     */     } catch (IOException localIOException) {
/* 218 */       localIOException.printStackTrace();
/* 219 */       return arrayOfObject;
/*     */     }
/* 221 */     paramLContext.canvas.stopLoading();
/* 222 */     return arrayOfObject1;
/*     */   }
/*     */   
/*     */   Object prim_readprojurl(LContext paramLContext) {
/* 226 */     Object[] arrayOfObject = new Object[0];
/*     */     
/*     */ 
/*     */ 
/* 230 */     if (paramLContext.projectURL == null) return arrayOfObject;
/*     */     URL localURL;
/* 232 */     try { localURL = new URL(paramLContext.projectURL);
/*     */     } catch (MalformedURLException localMalformedURLException) {
/* 234 */       Logo.error("Bad project URL: " + paramLContext.projectURL, paramLContext);
/* 235 */       return arrayOfObject;
/*     */     }
/*     */     Object[][] arrayOfObject1;
/*     */     try {
/* 239 */       paramLContext.canvas.startLoading();
/* 240 */       URLConnection localURLConnection = localURL.openConnection();
/* 241 */       localURLConnection.connect();
/* 242 */       int i = localURLConnection.getContentLength();
/* 243 */       byte[] arrayOfByte = new byte[i];
/* 244 */       InputStream localInputStream = localURLConnection.getInputStream();
/* 245 */       int j = 0;int k = 0;
/*     */       
/* 247 */       while ((j >= 0) && (k < i)) {
/* 248 */         j = localInputStream.read(arrayOfByte, k, i - k);
/* 249 */         if (j > 0) {
/* 250 */           k += j;
/* 251 */           paramLContext.canvas.loadingProgress(k / i);
/*     */         } else {
/* 253 */           try { Thread.sleep(100L);
/*     */           } catch (InterruptedException localInterruptedException) {}
/*     */         } }
/* 256 */       localInputStream.close();
/*     */       
/* 258 */       ObjReader localObjReader = new ObjReader(new ByteArrayInputStream(arrayOfByte));
/* 259 */       arrayOfObject1 = localObjReader.readObjects(paramLContext);
/*     */     } catch (IOException localIOException) {
/* 261 */       Logo.error("Problem reading project from URL: " + paramLContext.projectURL, paramLContext);
/* 262 */       return arrayOfObject;
/*     */     }
/* 264 */     paramLContext.canvas.stopLoading();
/* 265 */     return arrayOfObject1;
/*     */   }
/*     */   
/*     */   Object prim_mouseclick(LContext paramLContext) {
/* 269 */     if (paramLContext.canvas.mouseclicks.isEmpty()) return new Object[0];
/* 270 */     return paramLContext.canvas.mouseclicks.remove(0);
/*     */   }
/*     */   
/*     */   Object prim_keystroke(LContext paramLContext) {
/* 274 */     if (paramLContext.canvas.keystrokes.isEmpty()) return new Object[0];
/* 275 */     return paramLContext.canvas.keystrokes.remove(0);
/*     */   }
/*     */   
/*     */   Object prim_keydown(Object paramObject, LContext paramLContext) {
/* 279 */     int i = Logo.anInt(paramObject, paramLContext);
/* 280 */     if (i > 255) return new Boolean(false);
/* 281 */     return new Boolean(paramLContext.canvas.keydown[i]);
/*     */   }
/*     */   
/*     */   Object prim_midisetinstrument(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 285 */     init_midi(paramLContext);
/* 286 */     if (midiSynth == null) return null;
/* 287 */     int i = Logo.anInt(paramObject1, paramLContext) - 1 & 0xF;
/* 288 */     int j = Logo.anInt(paramObject2, paramLContext) - 1 & 0x7F;
/* 289 */     midiSynth.getChannels()[i].programChange(j);
/* 290 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_midinoteon(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 294 */     init_midi(paramLContext);
/* 295 */     if (midiSynth == null) return null;
/* 296 */     int i = Logo.anInt(paramObject1, paramLContext) - 1 & 0xF;
/* 297 */     int j = Logo.anInt(paramObject2, paramLContext) & 0x7F;
/* 298 */     int k = Logo.anInt(paramObject3, paramLContext) & 0x7F;
/* 299 */     midiSynth.getChannels()[i].noteOn(j, k);
/* 300 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_midinoteoff(Object paramObject1, Object paramObject2, LContext paramLContext) {
/* 304 */     init_midi(paramLContext);
/* 305 */     if (midiSynth == null) return null;
/* 306 */     int i = Logo.anInt(paramObject1, paramLContext) - 1 & 0xF;
/* 307 */     int j = Logo.anInt(paramObject2, paramLContext) & 0x7F;
/* 308 */     midiSynth.getChannels()[i].noteOff(j);
/* 309 */     return null;
/*     */   }
/*     */   
/*     */   Object prim_midicontrol(Object paramObject1, Object paramObject2, Object paramObject3, LContext paramLContext) {
/* 313 */     init_midi(paramLContext);
/* 314 */     if (midiSynth == null) return null;
/* 315 */     int i = Logo.anInt(paramObject1, paramLContext) - 1 & 0xF;
/* 316 */     int j = Logo.anInt(paramObject2, paramLContext) & 0x7F;
/* 317 */     int k = Logo.anInt(paramObject3, paramLContext) & 0x7F;
/* 318 */     midiSynth.getChannels()[i].controlChange(j, k);
/* 319 */     return null;
/*     */   }
/*     */   
/*     */   void init_midi(LContext paramLContext)
/*     */   {
/* 324 */     if (midiSynthInitialized) return;
/* 325 */     midiSynthInitialized = true;
/*     */     try {
/* 327 */       midiSynth = MidiSystem.getSynthesizer();
/* 328 */       midiSynth.open();
/* 329 */       if (midiSynth.getDefaultSoundbank() == null) {
/* 330 */         paramLContext.canvas.setMessage("Reading sound bank from server. Please wait...");
/* 331 */         URL localURL = new URL(paramLContext.codeBase + "soundbank.gm");
/*     */         
/*     */ 
/* 334 */         Soundbank localSoundbank = MidiSystem.getSoundbank(localURL);
/* 335 */         if (localSoundbank != null) {
/* 336 */           midiSynth.loadAllInstruments(localSoundbank);
/* 337 */           paramLContext.canvas.setMessage("");
/*     */         } else {
/* 339 */           midiSynth.close();
/* 340 */           midiSynth = null;
/*     */         }
/*     */       }
/*     */     } catch (MidiUnavailableException localMidiUnavailableException) {
/* 344 */       localMidiUnavailableException.printStackTrace();
/* 345 */       midiSynth = null;
/*     */     } catch (MalformedURLException localMalformedURLException) {
/* 347 */       localMalformedURLException.printStackTrace();
/* 348 */       midiSynth = null;
/*     */     } catch (InvalidMidiDataException localInvalidMidiDataException) {
/* 350 */       localInvalidMidiDataException.printStackTrace();
/* 351 */       midiSynth = null;
/*     */     } catch (IOException localIOException) {
/* 353 */       localIOException.printStackTrace();
/* 354 */       midiSynth = null;
/*     */     } catch (AccessControlException localAccessControlException) {
/* 356 */       localAccessControlException.printStackTrace();
/* 357 */       midiSynth = null;
/*     */     }
/* 359 */     if (midiSynth != null) {
/* 360 */       MidiChannel[] arrayOfMidiChannel = midiSynth.getChannels();
/* 361 */       for (int i = 0; i < arrayOfMidiChannel.length; i++) {
/* 362 */         if (arrayOfMidiChannel[i] != null) arrayOfMidiChannel[i].programChange(0);
/*     */       }
/*     */     }
/* 365 */     paramLContext.canvas.setMessage("No soundbank; note & drum commands disabled.");
/*     */   }
/*     */   
/*     */   Object prim_jpegDecode(Object paramObject, LContext paramLContext)
/*     */   {
/* 370 */     if (!(paramObject instanceof byte[])) return null;
/* 371 */     byte[] arrayOfByte = (byte[])paramObject;
/* 372 */     Toolkit localToolkit = Toolkit.getDefaultToolkit();
/* 373 */     Image localImage = localToolkit.createImage(arrayOfByte);
/*     */     
/*     */ 
/* 376 */     MediaTracker localMediaTracker = new MediaTracker(paramLContext.canvas);
/* 377 */     localMediaTracker.addImage(localImage, 0);
/* 378 */     try { localMediaTracker.waitForID(0); } catch (InterruptedException localInterruptedException) {}
/* 379 */     if (localImage == null) { return null;
/*     */     }
/*     */     
/* 382 */     int i = localImage.getWidth(null);
/* 383 */     int j = localImage.getHeight(null);
/* 384 */     BufferedImage localBufferedImage = new BufferedImage(i, j, 2);
/* 385 */     Graphics localGraphics = localBufferedImage.getGraphics();
/* 386 */     localGraphics.drawImage(localImage, 0, 0, i, j, null);
/* 387 */     localGraphics.dispose();
/* 388 */     return localBufferedImage;
/*     */   }
/*     */   
/*     */   Object prim_getSensorValue(Object paramObject, LContext paramLContext) {
/* 392 */     int i = Logo.anInt(paramObject, paramLContext) - 1;
/* 393 */     if ((i < 0) || (i > 15)) return new Double(123.0D);
/* 394 */     return new Double(sensorValues[i] / 10.0D);
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\PlayerPrims.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */