import java.awt.Graphics;
import java.awt.Rectangle;

abstract interface Drawable
{
  public abstract boolean isShowing();
  
  public abstract Rectangle rect();
  
  public abstract Rectangle fullRect();
  
  public abstract void paint(Graphics paramGraphics);
  
  public abstract void paintBubble(Graphics paramGraphics);
  
  public abstract void dragTo(int paramInt1, int paramInt2);
  
  public abstract void mouseDown(int paramInt1, int paramInt2);
}


/* Location:              T:\p1\ambulance.jar!\Drawable.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */