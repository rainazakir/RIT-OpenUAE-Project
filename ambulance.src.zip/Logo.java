/*     */ import java.io.PrintStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Logo
/*     */ {
/*  10 */   static long starttime = ;
/*     */   
/*     */   static String runToplevel(Object[] paramArrayOfObject, LContext paramLContext) {
/*  13 */     paramLContext.iline = new MapList(paramArrayOfObject);
/*  14 */     paramLContext.timeToStop = false;
/*  15 */     try { evLine(paramLContext);
/*  16 */     } catch (LogoError localLogoError) { if (localLogoError.getMessage() != null) return localLogoError.getMessage();
/*  17 */     } catch (Exception localException) { localException.printStackTrace();return localException.toString();
/*  18 */     } catch (Error localError) { return localError.toString(); }
/*  19 */     return null;
/*     */   }
/*     */   
/*     */   static void evLine(LContext paramLContext)
/*     */   {
/*  24 */     while ((!paramLContext.iline.eof()) && (paramLContext.ufunresult == null)) { Object localObject;
/*  25 */       if ((localObject = eval(paramLContext)) != null) error("You don't say what to do with " + prs(localObject), paramLContext);
/*     */     }
/*     */   }
/*     */   
/*  29 */   static Object eval(LContext paramLContext) { Object localObject = evalToken(paramLContext);
/*  30 */     while (infixNext(paramLContext.iline, paramLContext)) {
/*  31 */       if ((localObject instanceof Nothing)) error(paramLContext.iline.peek() + " needs more inputs", paramLContext);
/*  32 */       localObject = evalInfix(localObject, paramLContext);
/*     */     }
/*  34 */     return localObject;
/*     */   }
/*     */   
/*     */   static Object evalToken(LContext paramLContext) {
/*  38 */     Object localObject = paramLContext.iline.next();
/*  39 */     if ((localObject instanceof QuotedSymbol)) return ((QuotedSymbol)localObject).sym;
/*  40 */     if ((localObject instanceof DottedSymbol)) return getValue(((DottedSymbol)localObject).sym, paramLContext);
/*  41 */     if ((localObject instanceof Symbol)) return evalSym((Symbol)localObject, null, paramLContext);
/*  42 */     if ((localObject instanceof String)) return evalSym(intern((String)localObject, paramLContext), null, paramLContext);
/*  43 */     return localObject;
/*     */   }
/*     */   
/*     */   static Object evalSym(Symbol paramSymbol, Object[] paramArrayOfObject, LContext paramLContext) {
/*  47 */     if (paramLContext.timeToStop) error("Stopped!!!", paramLContext);
/*  48 */     if (paramSymbol.fcn == null) error("I don't know how to " + paramSymbol, paramLContext);
/*  49 */     Symbol localSymbol = paramLContext.cfun;paramLContext.cfun = paramSymbol;
/*  50 */     int i = paramLContext.priority;paramLContext.priority = 0;
/*  51 */     Object localObject1 = null;
/*  52 */     try { Function localFunction = paramSymbol.fcn;
/*  53 */       int j = localFunction.nargs;
/*  54 */       if (paramArrayOfObject == null) paramArrayOfObject = evalArgs(j, paramLContext);
/*  55 */       localObject1 = localFunction.instance.dispatch(localFunction.dispatchOffset, paramArrayOfObject, paramLContext);
/*     */     } catch (RuntimeException localRuntimeException) {
/*  57 */       errorHandler(paramSymbol, paramArrayOfObject, localRuntimeException, paramLContext);
/*  58 */     } finally { paramLContext.cfun = localSymbol;paramLContext.priority = i; }
/*  59 */     if ((paramLContext.mustOutput) && (localObject1 == null)) error(paramSymbol + " didn't output to " + paramLContext.cfun, paramLContext);
/*  60 */     return localObject1;
/*     */   }
/*     */   
/*     */   static Object[] evalArgs(int paramInt, LContext paramLContext) {
/*  64 */     boolean bool = paramLContext.mustOutput;paramLContext.mustOutput = true;
/*  65 */     Object[] arrayOfObject = new Object[paramInt];
/*     */     try {
/*  67 */       for (int i = 0; i < paramInt; i++) {
/*  68 */         if (paramLContext.iline.eof()) error(paramLContext.cfun + " needs more inputs", paramLContext);
/*  69 */         arrayOfObject[i] = eval(paramLContext);
/*  70 */         if ((arrayOfObject[i] instanceof Nothing)) error(paramLContext.cfun + " needs more inputs", paramLContext);
/*     */       }
/*     */     } finally {
/*  73 */       paramLContext.mustOutput = bool; }
/*  74 */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   static void runCommand(Object[] paramArrayOfObject, LContext paramLContext) {
/*  78 */     boolean bool = paramLContext.mustOutput;paramLContext.mustOutput = false;
/*  79 */     try { runList(paramArrayOfObject, paramLContext);
/*  80 */     } finally { paramLContext.mustOutput = bool;
/*     */     }
/*     */   }
/*     */   
/*  84 */   static Object runList(Object[] paramArrayOfObject, LContext paramLContext) { MapList localMapList = paramLContext.iline;
/*  85 */     paramLContext.iline = new MapList(paramArrayOfObject);
/*  86 */     Object localObject1 = null;
/*  87 */     try { if (paramLContext.mustOutput) localObject1 = eval(paramLContext); else evLine(paramLContext);
/*  88 */       checkListEmpty(paramLContext.iline, paramLContext);
/*  89 */     } finally { paramLContext.iline = localMapList; }
/*  90 */     return localObject1;
/*     */   }
/*     */   
/*     */   static Object evalOneArg(MapList paramMapList, LContext paramLContext) {
/*  94 */     boolean bool = paramLContext.mustOutput;paramLContext.mustOutput = true;
/*  95 */     MapList localMapList = paramLContext.iline;paramLContext.iline = paramMapList;
/*  96 */     try { return eval(paramLContext);
/*  97 */     } finally { paramLContext.iline = localMapList;paramLContext.mustOutput = bool;
/*     */     }
/*     */   }
/*     */   
/* 101 */   static boolean infixNext(MapList paramMapList, LContext paramLContext) { Object localObject = null;Function localFunction = null;
/* 102 */     return (!paramMapList.eof()) && (((localObject = paramMapList.peek()) instanceof Symbol)) && ((localFunction = ((Symbol)localObject).fcn) != null) && (localFunction.nargs < paramLContext.priority);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static Object evalInfix(Object paramObject, LContext paramLContext)
/*     */   {
/* 109 */     Symbol localSymbol1 = (Symbol)paramLContext.iline.next();
/* 110 */     Function localFunction = localSymbol1.fcn;
/* 111 */     Symbol localSymbol2 = paramLContext.cfun;paramLContext.cfun = localSymbol1;
/* 112 */     int i = paramLContext.priority;paramLContext.priority = localFunction.nargs;
/* 113 */     Object localObject1 = null;
/* 114 */     Object[] arrayOfObject1 = new Object[2];
/* 115 */     arrayOfObject1[0] = paramObject;
/* 116 */     try { Object[] arrayOfObject2 = evalArgs(1, paramLContext);
/* 117 */       arrayOfObject1[1] = arrayOfObject2[0];
/* 118 */       localObject1 = localFunction.instance.dispatch(localFunction.dispatchOffset, arrayOfObject1, paramLContext);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 120 */       errorHandler(localSymbol1, arrayOfObject1, localRuntimeException, paramLContext);
/* 121 */     } finally { paramLContext.cfun = localSymbol2;paramLContext.priority = i; }
/* 122 */     if ((paramLContext.mustOutput) && (localObject1 == null)) error(localSymbol1 + " didn't output to " + paramLContext.cfun, paramLContext);
/* 123 */     return localObject1;
/*     */   }
/*     */   
/*     */   static Symbol intern(String paramString, LContext paramLContext) {
/*     */     String str;
/* 128 */     if (paramString.length() == 0) { str = paramString;
/* 129 */     } else if (paramString.charAt(0) == '|') str = paramString = paramString.substring(1); else
/* 130 */       str = paramString;
/* 131 */     Symbol localSymbol = (Symbol)paramLContext.oblist.get(str);
/* 132 */     if (localSymbol == null) paramLContext.oblist.put(str, localSymbol = new Symbol(paramString));
/* 133 */     return localSymbol;
/*     */   }
/*     */   
/*     */   static Object[] parse(String paramString, LContext paramLContext) {
/* 137 */     TokenStream localTokenStream = new TokenStream(paramString);
/* 138 */     return localTokenStream.readList(paramLContext);
/*     */   }
/*     */   
/* 141 */   static String prs(Object paramObject) { return prs(paramObject, 10); }
/*     */   
/* 143 */   static String prs(Object paramObject, int paramInt) { return prs(paramObject, paramInt, new HashSet()); }
/*     */   
/*     */   static String prs(Object paramObject, int paramInt, HashSet paramHashSet) {
/* 146 */     if (((paramObject instanceof Number)) && (paramInt == 16))
/* 147 */       return Long.toString(((Number)paramObject).longValue(), 16).toUpperCase();
/* 148 */     if (((paramObject instanceof Number)) && (paramInt == 8))
/* 149 */       return Long.toString(((Number)paramObject).longValue(), 8);
/* 150 */     if (((paramObject instanceof Number)) && (isInt((Number)paramObject)))
/* 151 */       return Long.toString(((Number)paramObject).longValue(), 10);
/* 152 */     if ((paramObject instanceof Object[])) {
/* 153 */       Object[] arrayOfObject = (Object[])paramObject;
/* 154 */       if ((arrayOfObject.length > 0) && (paramHashSet.contains(paramObject))) return "...";
/* 155 */       if (arrayOfObject.length > 0) paramHashSet.add(paramObject);
/* 156 */       String str = "";
/* 157 */       for (int i = 0; i < arrayOfObject.length; i++) {
/* 158 */         if ((arrayOfObject[i] instanceof Object[])) str = str + "[";
/* 159 */         str = str + prs(arrayOfObject[i], paramInt, paramHashSet);
/* 160 */         if ((arrayOfObject[i] instanceof Object[])) str = str + "]";
/* 161 */         if (i != arrayOfObject.length - 1) str = str + " ";
/*     */       }
/* 163 */       return str;
/*     */     }
/* 165 */     return paramObject.toString();
/*     */   }
/*     */   
/*     */   static boolean isInt(Number paramNumber) {
/* 169 */     return paramNumber.doubleValue() == new Integer(paramNumber.intValue()).doubleValue();
/*     */   }
/*     */   
/*     */   static boolean aValidNumber(String paramString) {
/* 173 */     if ((paramString.length() == 1) && ("0123456789".indexOf(paramString.charAt(0)) == -1))
/* 174 */       return false;
/* 175 */     if ("eE.+-0123456789".indexOf(paramString.charAt(0)) == -1) return false;
/* 176 */     for (int i = 1; i < paramString.length(); i++)
/* 177 */       if ("eE.0123456789".indexOf(paramString.charAt(i)) == -1) return false;
/* 178 */     return true;
/*     */   }
/*     */   
/*     */   static Object getValue(Symbol paramSymbol, LContext paramLContext) {
/*     */     Object localObject;
/* 183 */     if ((localObject = paramSymbol.value) != null) return localObject;
/* 184 */     error(paramSymbol + " has no value", paramLContext);
/* 185 */     return null;
/*     */   }
/*     */   
/* 188 */   static void setValue(Symbol paramSymbol, Object paramObject, LContext paramLContext) { paramSymbol.value = paramObject; }
/*     */   
/*     */   static double aDouble(Object paramObject, LContext paramLContext) {
/* 191 */     if ((paramObject instanceof Double)) return ((Double)paramObject).doubleValue();
/* 192 */     String str = prs(paramObject);
/* 193 */     if ((str.length() > 0) && (aValidNumber(str))) return Double.valueOf(str).doubleValue();
/* 194 */     error(paramLContext.cfun + " doesn't like " + prs(paramObject) + " as input", paramLContext);
/* 195 */     return 0.0D;
/*     */   }
/*     */   
/*     */   static int anInt(Object paramObject, LContext paramLContext) {
/* 199 */     if ((paramObject instanceof Double)) return ((Double)paramObject).intValue();
/* 200 */     String str = prs(paramObject);
/*     */     
/* 202 */     if (aValidNumber(str)) return Double.valueOf(str).intValue();
/* 203 */     error(paramLContext.cfun + " doesn't like " + str + " as input", paramLContext);
/* 204 */     return 0;
/*     */   }
/*     */   
/*     */   static long aLong(Object paramObject, LContext paramLContext) {
/* 208 */     if ((paramObject instanceof Double)) return ((Double)paramObject).longValue();
/* 209 */     String str = prs(paramObject);
/* 210 */     if (aValidNumber(str)) return Double.valueOf(str).longValue();
/* 211 */     error(paramLContext.cfun + " doesn't like " + str + " as input", paramLContext);
/* 212 */     return 0L;
/*     */   }
/*     */   
/*     */   static boolean aBoolean(Object paramObject, LContext paramLContext) {
/* 216 */     if ((paramObject instanceof Boolean)) return ((Boolean)paramObject).booleanValue();
/* 217 */     if ((paramObject instanceof Symbol)) return ((Symbol)paramObject).pname.equals("true");
/* 218 */     error(paramLContext.cfun + " doesn't like " + prs(paramObject) + " as input", paramLContext);
/* 219 */     return false;
/*     */   }
/*     */   
/*     */   static Object[] aList2Double(Object paramObject, LContext paramLContext) {
/* 223 */     if ((paramObject instanceof Object[])) {
/* 224 */       if ((((Object[])paramObject).length == 2) && 
/* 225 */         ((((Object[])paramObject)[0] instanceof Double)) && ((((Object[])paramObject)[1] instanceof Double)))
/*     */       {
/* 227 */         return (Object[])paramObject; }
/* 228 */       error(paramLContext.cfun + " doesn't like " + prs(paramObject) + " as input", paramLContext);
/*     */     }
/* 230 */     return null;
/*     */   }
/*     */   
/*     */   static Object[] aList(Object paramObject, LContext paramLContext) {
/* 234 */     if ((paramObject instanceof Object[])) return (Object[])paramObject;
/* 235 */     error(paramLContext.cfun + " doesn't like " + prs(paramObject) + " as input", paramLContext);
/* 236 */     return null;
/*     */   }
/*     */   
/*     */   static Symbol aSymbol(Object paramObject, LContext paramLContext) {
/* 240 */     if ((paramObject instanceof Symbol)) return (Symbol)paramObject;
/* 241 */     if ((paramObject instanceof String)) return intern((String)paramObject, paramLContext);
/* 242 */     if ((paramObject instanceof Number)) {
/* 243 */       String str = String.valueOf(((Number)paramObject).longValue());
/* 244 */       return intern(str, paramLContext);
/*     */     }
/* 246 */     error(paramLContext.cfun + " doesn't like " + prs(paramObject) + " as input", paramLContext);
/* 247 */     return null;
/*     */   }
/*     */   
/*     */   static String aString(Object paramObject, LContext paramLContext) {
/* 251 */     if ((paramObject instanceof String)) return (String)paramObject;
/* 252 */     if ((paramObject instanceof Symbol)) return ((Symbol)paramObject).toString();
/* 253 */     error(paramLContext.cfun + " doesn't like " + prs(paramObject) + " as input", paramLContext);
/* 254 */     return null;
/*     */   }
/*     */   
/*     */   static void setupPrims(String[] paramArrayOfString, LContext paramLContext) {
/* 258 */     for (int i = 0; i < paramArrayOfString.length; i++) setupPrims(paramArrayOfString[i], paramLContext);
/*     */   }
/*     */   
/*     */   static void setupPrims(String paramString, LContext paramLContext)
/*     */   {
/*     */     try {
/* 264 */       Class localClass = Class.forName(paramString);
/* 265 */       Primitives localPrimitives = (Primitives)localClass.newInstance();
/* 266 */       String[] arrayOfString = localPrimitives.primlist();
/* 267 */       for (int i = 0; i < arrayOfString.length; i += 2) {
/* 268 */         String str = arrayOfString[(i + 1)];
/* 269 */         boolean bool = str.startsWith("i");
/* 270 */         if (bool) str = str.substring(1);
/* 271 */         Symbol localSymbol = intern(arrayOfString[i], paramLContext);
/* 272 */         localSymbol.fcn = new Function(localPrimitives, Integer.parseInt(str), i / 2, bool);
/*     */       }
/*     */     } catch (Exception localException) {
/* 275 */       System.out.println(localException.toString());
/*     */     }
/*     */   }
/*     */   
/* 279 */   static void checkListEmpty(MapList paramMapList, LContext paramLContext) { if ((!paramMapList.eof()) && (paramLContext.ufunresult == null)) error("You don't say what to do with " + prs(paramMapList.next()), paramLContext);
/*     */   }
/*     */   
/*     */   static void errorHandler(Symbol paramSymbol, Object[] paramArrayOfObject, RuntimeException paramRuntimeException, LContext paramLContext) {
/* 283 */     if (((paramRuntimeException instanceof ArrayIndexOutOfBoundsException)) || ((paramRuntimeException instanceof StringIndexOutOfBoundsException)) || ((paramRuntimeException instanceof NegativeArraySizeException)))
/*     */     {
/*     */ 
/* 286 */       error(paramSymbol + " doesn't like " + prs(paramArrayOfObject[0]) + " as input", paramLContext); } else
/* 287 */       throw paramRuntimeException;
/*     */   }
/*     */   
/*     */   static void error(String paramString, LContext paramLContext) {
/* 291 */     if (paramString.equals("")) throw new LogoError(null);
/* 292 */     paramString = paramString + (paramLContext.ufun == null ? "" : new StringBuffer().append(" in ").append(paramLContext.ufun).toString());
/* 293 */     throw new LogoError(paramString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void readAllFunctions(String paramString, LContext paramLContext)
/*     */   {
/* 303 */     TokenStream localTokenStream = new TokenStream(paramString);
/*     */     for (;;) {
/* 305 */       switch (findKeyWord(localTokenStream)) {
/* 306 */       case 0:  return;
/* 307 */       case 1:  doDefine(localTokenStream, paramLContext); break;
/* 308 */       case 2:  doTo(localTokenStream, paramLContext);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static int findKeyWord(TokenStream paramTokenStream) {
/*     */     for (;;) {
/* 315 */       if (paramTokenStream.eof()) return 0;
/* 316 */       if (paramTokenStream.startsWith("define ")) return 1;
/* 317 */       if (paramTokenStream.startsWith("to ")) return 2;
/* 318 */       paramTokenStream.skipToNextLine();
/*     */     }
/*     */   }
/*     */   
/*     */   static void doDefine(TokenStream paramTokenStream, LContext paramLContext) {
/* 323 */     paramTokenStream.readToken(paramLContext);
/* 324 */     Symbol localSymbol = aSymbol(paramTokenStream.readToken(paramLContext), paramLContext);
/* 325 */     Object[] arrayOfObject1 = aList(paramTokenStream.readToken(paramLContext), paramLContext);
/* 326 */     Object[] arrayOfObject2 = aList(paramTokenStream.readToken(paramLContext), paramLContext);
/* 327 */     Ufun localUfun = new Ufun(arrayOfObject1, arrayOfObject2);
/* 328 */     localSymbol.fcn = new Function(localUfun, arrayOfObject1.length, 0);
/*     */   }
/*     */   
/*     */   static void doTo(TokenStream paramTokenStream, LContext paramLContext) {
/* 332 */     Object[] arrayOfObject1 = parse(paramTokenStream.nextLine(), paramLContext);
/* 333 */     Object[] arrayOfObject2 = parse(readBody(paramTokenStream, paramLContext), paramLContext);
/* 334 */     Object[] arrayOfObject3 = getArglistFromTitle(arrayOfObject1);
/* 335 */     Symbol localSymbol = aSymbol(arrayOfObject1[1], paramLContext);
/* 336 */     Ufun localUfun = new Ufun(arrayOfObject3, arrayOfObject2);
/* 337 */     localSymbol.fcn = new Function(localUfun, arrayOfObject3.length, 0);
/*     */   }
/*     */   
/*     */   static String readBody(TokenStream paramTokenStream, LContext paramLContext) {
/* 341 */     String str1 = "";
/*     */     for (;;) {
/* 343 */       if (paramTokenStream.eof()) return str1;
/* 344 */       String str2 = paramTokenStream.nextLine();
/* 345 */       if ((str2.startsWith("end")) && ("end".equals(((Symbol)parse(str2, paramLContext)[0]).pname)))
/* 346 */         return str1;
/* 347 */       str1 = str1 + " " + str2;
/*     */     }
/*     */   }
/*     */   
/*     */   static Object[] getArglistFromTitle(Object[] paramArrayOfObject) {
/* 352 */     Object[] arrayOfObject = new Object[paramArrayOfObject.length - 2];
/* 353 */     for (int i = 0; i < arrayOfObject.length; i++)
/* 354 */       arrayOfObject[i] = ((DottedSymbol)paramArrayOfObject[(i + 2)]).sym;
/* 355 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\Logo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */