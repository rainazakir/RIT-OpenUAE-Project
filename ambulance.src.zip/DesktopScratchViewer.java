/*     */ import java.awt.Insets;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.UIManager.LookAndFeelInfo;
/*     */ 
/*     */ public class DesktopScratchViewer
/*     */ {
/*     */   static JFrame parent;
/*     */   
/*     */   public static void main(String[] args) throws java.io.IOException
/*     */   {
/*     */     try
/*     */     {
/*  19 */       setFinalStatic(PlayerPrims.class.getDeclaredField("primclasses"), new String[] { "SystemPrims", "MathPrims", "ControlPrims", "DefiningPrims", "WordListPrims", "FilePrims", "PlayerPrims", "SpritePrims", "PantherPrims" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  31 */       javax.swing.JOptionPane.showMessageDialog(null, "Error: can't set final field 'primclasses'!\nNo Panther support.", "Error", 0);
/*     */     }
/*     */     
/*  34 */     Properties p = new Properties();
/*  35 */     p.loadFromXML(DesktopScratchViewer.class.getResourceAsStream("config.xml"));
/*  36 */     String[] params = new String[p.size() * 2];
/*  37 */     Enumeration keys = p.keys();
/*  38 */     int i = 0;
/*  39 */     while (keys.hasMoreElements()) {
/*  40 */       String key = (String)keys.nextElement();
/*  41 */       System.out.println(key + "=" + p.getProperty(key));
/*  42 */       params[i] = key;
/*  43 */       params[(i + 1)] = p.getProperty(key);
/*  44 */       i += 2;
/*     */     }
/*     */     try
/*     */     {
/*  48 */       UIManager.LookAndFeelInfo[] info = javax.swing.UIManager.getInstalledLookAndFeels();
/*  49 */       for (UIManager.LookAndFeelInfo laf : info) {
/*  50 */         if (laf.getName().equals("Nimbus")) {
/*  51 */           javax.swing.UIManager.setLookAndFeel(laf.getClassName());
/*  52 */           break;
/*     */         }
/*     */       }
/*     */     } catch (Throwable ex) {
/*  56 */       ex.printStackTrace();
/*     */     }
/*     */     
/*  59 */     final JFrame frm = new JFrame(getParam(params, "title"));
/*  60 */     DesktopScratchViewer.DesktopScratchApplet app = new DesktopScratchViewer.DesktopScratchApplet(params);
/*  61 */     final DesktopScratchViewer.LoadingPanel load = new DesktopScratchViewer.LoadingPanel();
/*     */     
/*  63 */     parent = frm;
/*     */     
/*  65 */     frm.setLocationByPlatform(true);
/*  66 */     frm.setDefaultCloseOperation(3);
/*     */     
/*  68 */     frm.setLayout(null);
/*  69 */     frm.add(load);
/*  70 */     frm.add(app);
/*  71 */     app.setBounds(0, -25, 482, 387);
/*  72 */     load.setBounds(0, 0, 482, 387);
/*  73 */     frm.validate();
/*     */     
/*     */ 
/*  76 */     frm.setResizable(false);
/*  77 */     frm.setVisible(true);
/*  78 */     Insets iset = frm.getInsets();
/*  79 */     frm.setSize(482 + iset.left + iset.right, 387 + iset.top + iset.bottom - 25);
/*     */     
/*     */ 
/*  82 */     app.init();
/*     */     
/*  84 */     new Thread()
/*     */     {
/*     */       public void run() {
/*  87 */         while (this.val$app.lc.canvas.isLoading) {
/*  88 */           load.Progress.setValue((int)(this.val$app.lc.canvas.loadingFraction * 100.0D));
/*     */           try {
/*  90 */             Thread.sleep(10L);
/*     */           } catch (InterruptedException e) {
/*  92 */             e.printStackTrace();
/*     */           }
/*     */         }
/*  95 */         frm.remove(load);
/*  96 */         frm.validate();
/*     */       }
/*     */     }.start();
/*     */   }
/*     */   
/*     */   private static String getParam(String[] params, String name) {
/* 102 */     for (int i = 0; i < params.length; i += 2) {
/* 103 */       if (params[i].equals(name)) {
/* 104 */         return params[(i + 1)];
/*     */       }
/*     */     }
/* 107 */     return null;
/*     */   }
/*     */   
/*     */   private static class LoadingPanel extends javax.swing.JPanel {
/*     */     public javax.swing.JProgressBar Progress;
/*     */     
/* 113 */     public LoadingPanel() { initComponents(); }
/*     */     
/*     */ 
/*     */     private void initComponents()
/*     */     {
/* 118 */       this.Progress = new javax.swing.JProgressBar();
/*     */       
/* 120 */       GroupLayout layout = new GroupLayout(this);
/* 121 */       setLayout(layout);
/* 122 */       layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.Progress, -1, 430, 32767).addContainerGap()));
/*     */       
/* 124 */       layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addContainerGap(155, 32767).addComponent(this.Progress, -2, 57, -2).addGap(118, 118, 118)));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class DesktopScratchApplet
/*     */     extends ScratchApplet
/*     */   {
/*     */     private String[] param;
/*     */     
/*     */     public DesktopScratchApplet(String[] params)
/*     */     {
/* 135 */       this.param = params;
/*     */     }
/*     */     
/*     */     public String getParameter(String name)
/*     */     {
/* 140 */       for (int i = 0; i < this.param.length; i += 2) {
/* 141 */         if (this.param[i].equals(name)) {
/* 142 */           return this.param[(i + 1)];
/*     */         }
/*     */       }
/* 145 */       return null;
/*     */     }
/*     */     
/*     */     public java.net.URL getCodeBase()
/*     */     {
/*     */       try {
/* 151 */         return new java.net.URL(DesktopScratchViewer.class.getResource("project.dat").toExternalForm().replace("project.dat", ""));
/*     */       } catch (java.net.MalformedURLException ex) {
/* 153 */         throw new RuntimeException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static void setFinalStatic(Field field, Object newValue) throws Exception {
/* 159 */     field.setAccessible(true);
/*     */     
/* 161 */     Field modifiersField = Field.class.getDeclaredField("modifiers");
/* 162 */     modifiersField.setAccessible(true);
/* 163 */     modifiersField.setInt(field, field.getModifiers() & 0xFFFFFFEF);
/*     */     
/* 165 */     field.set(null, newValue);
/*     */   }
/*     */ }


/* Location:              T:\p1\ambulance.jar!\DesktopScratchViewer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */